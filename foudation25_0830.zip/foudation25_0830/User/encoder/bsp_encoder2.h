#ifndef __BSP_ENCOEDER2_H
#define	__BSP_ENCOEDER2_H

#include "stm32h7xx.h"
#include "stm32h7xx_hal.h"
#include "./exti/bsp_exti.h"
#include "./stepper/bsp_stepper_init.h"

// ÿ��encoder����һ���ṹ��
typedef struct {
  uint16_t      A_pin;                     //
  uint16_t      B_pin;                     //
  uint16_t      Z_pin;                      //
  GPIO_TypeDef  *A_port;               //
  GPIO_TypeDef  *B_port;               //
  GPIO_TypeDef  *C_port;                //
  uint8_t       A_Alternate;
  uint8_t       B_Alternate;
  uint8_t       Z_Alternate;
  uint32_t      resolution_physical;                 //
  uint32_t      resolution_total;                 //
  uint32_t      reduction_ratio;                 //
  uint32_t      currentValue;
  uint32_t      permenantValue;
}Encoder_TypeDef;//

/* ��ʱ��ѡ�� */
#define ENCODER_TIM                            TIM3
#define ENCODER_TIM_CLK_ENABLE()  				     __HAL_RCC_TIM3_CLK_ENABLE()

/* ��ʱ�����ֵ */		
#define ENCODER_TIM_PERIOD                     65535
/* ��ʱ��Ԥ��Ƶֵ */
#define ENCODER_TIM_PRESCALER                  0      

/* ��ʱ���ж� */
#define ENCODER_TIM_IRQn                       TIM3_IRQn
#define ENCODER_TIM_IRQHandler                 TIM3_IRQHandler

/* �������ӿ����� */
#define ENCODER_TIM_CH1_GPIO_CLK_ENABLE()      __HAL_RCC_GPIOC_CLK_ENABLE()
#define ENCODER_TIM_CH1_GPIO_PORT              GPIOC
#define ENCODER_TIM_CH1_PIN                    GPIO_PIN_6
#define ENCODER_TIM_CH1_GPIO_AF                GPIO_AF2_TIM3

#define ENCODER_TIM_CH2_GPIO_CLK_ENABLE()      __HAL_RCC_GPIOC_CLK_ENABLE()
#define ENCODER_TIM_CH2_GPIO_PORT              GPIOC
#define ENCODER_TIM_CH2_PIN                    GPIO_PIN_7
#define ENCODER_TIM_CH2_GPIO_AF                GPIO_AF2_TIM3

#define ENCODER_TIM_CH3_GPIO_CLK_ENABLE()      __HAL_RCC_GPIOC_CLK_ENABLE()
#define ENCODER_TIM_CH3_GPIO_PORT              GPIOC
#define ENCODER_TIM_CH3_PIN                    GPIO_PIN_8
#define ENCODER_TIM_CH3_GPIO_AF                GPIO_AF2_TIM3

/* �������ӿڱ�Ƶ�� */
#define ENCODER_MODE                           TIM_ENCODERMODE_TI12

/* �������ӿ����벶��ͨ����λ���� */
#define ENCODER_IC1_POLARITY                   TIM_ICPOLARITY_FALLING
#define ENCODER_IC2_POLARITY                   TIM_ICPOLARITY_RISING

/* �����������ֱ��� */
#define ENCODER_RESOLUTION                     500

/* ������Ƶ֮����ֱܷ��� */
#if ((ENCODER_MODE == TIM_ENCODERMODE_TI1) || (ENCODER_MODE == TIM_ENCODERMODE_TI2))
  #define ENCODER_TOTAL_RESOLUTION             (ENCODER_RESOLUTION * 2)  /* 2��Ƶ����ֱܷ��� */
#else
  #define ENCODER_TOTAL_RESOLUTION             (ENCODER_RESOLUTION * 4)  /* 4��Ƶ����ֱܷ��� */
#endif

/* ���ٵ�����ٱ� */
#define REDUCTION_RATIO                        34


/////////////////////////////////Encoder2///////////////////////////////////////////////

/* ��ʱ��ѡ�� */
#define ENCODER2_TIM                            TIM5
#define ENCODER2_TIM_CLK_ENABLE()  				     __HAL_RCC_TIM5_CLK_ENABLE()

/* ��ʱ�����ֵ */		
#define ENCODER2_TIM_PERIOD                     65535
/* ��ʱ��Ԥ��Ƶֵ */
#define ENCODER2_TIM_PRESCALER                  0      

/* ��ʱ���ж� */
#define ENCODER2_TIM_IRQn                       TIM5_IRQn
#define ENCODER2_TIM_IRQHandler                 TIM5_IRQHandler

/* �������ӿ����� */
#define ENCODER2_TIM_CH1_GPIO_CLK_ENABLE()      __HAL_RCC_GPIOH_CLK_ENABLE()
#define ENCODER2_TIM_CH1_GPIO_PORT              GPIOH
#define ENCODER2_TIM_CH1_PIN                    GPIO_PIN_10
#define ENCODER2_TIM_CH1_GPIO_AF                GPIO_AF2_TIM3

#define ENCODER2_TIM_CH2_GPIO_CLK_ENABLE()      __HAL_RCC_GPIOH_CLK_ENABLE()
#define ENCODER2_TIM_CH2_GPIO_PORT              GPIOH
#define ENCODER2_TIM_CH2_PIN                    GPIO_PIN_11
#define ENCODER2_TIM_CH2_GPIO_AF                GPIO_AF2_TIM3

#define ENCODER2_TIM_CH3_GPIO_CLK_ENABLE()      __HAL_RCC_GPIOH_CLK_ENABLE()
#define ENCODER2_TIM_CH3_GPIO_PORT              GPIOH
#define ENCODER2_TIM_CH3_PIN                    GPIO_PIN_12
#define ENCODER2_TIM_CH3_GPIO_AF                GPIO_AF2_TIM3

/* �������ӿڱ�Ƶ�� */
#define ENCODER2_MODE                           TIM_ENCODERMODE_TI12

/* �������ӿ����벶��ͨ����λ���� */
#define ENCODER2_IC1_POLARITY                   TIM_ICPOLARITY_FALLING
#define ENCODER2_IC2_POLARITY                   TIM_ICPOLARITY_RISING

/* �����������ֱ��� */
#define ENCODER2_RESOLUTION                     500

/* ������Ƶ֮����ֱܷ��� */
#if ((ENCODER2_MODE == TIM_ENCODERMODE_TI1) || (ENCODER2_MODE == TIM_ENCODERMODE_TI2))
  #define ENCODER2_TOTAL_RESOLUTION             (ENCODER2_RESOLUTION * 2)  /* 2��Ƶ����ֱܷ��� */
#else
  #define ENCODER2_TOTAL_RESOLUTION             (ENCODER2_RESOLUTION * 4)  /* 4��Ƶ����ֱܷ��� */
#endif

/* ���ٵ�����ٱ� */
#define REDUCTION2_RATIO                        34

/////////////////////////////////End of Encoder2///////////////////////////////////////////////

/////////////////////////////////Encoder3///////////////////////////////////////////////

/* ��ʱ��ѡ�� */
#define ENCODER3_TIM                            TIM1
#define ENCODER3_TIM_CLK_ENABLE()  				     __HAL_RCC_TIM1_CLK_ENABLE()


/* ��ʱ�����ֵ */		
#define ENCODER3_TIM_PERIOD                     65535
/* ��ʱ��Ԥ��Ƶֵ */
#define ENCODER3_TIM_PRESCALER                  0      

/* ��ʱ���ж� */



//#define ENCODER3_TIM_IRQn                       TIM1_CC_IRQn
//#define ENCODER3_TIM_IRQHandler                 TIM1_CC_IRQHandler

//#define ENCODER3_TIM_IRQn                       TIM1_BRK_IRQn
//#define ENCODER3_TIM_IRQHandler                 TIM1_BRK_IRQHandler
//#define ENCODER3_TIM_IRQn                       TIM1_TRG_COM_IRQn
//#define ENCODER3_TIM_IRQHandler                 TIM1_TRG_COM_IRQHandler 
/* �������ӿ����� */



#define ENCODER3_TIM_IRQn                       TIM1_UP_IRQn
#define ENCODER3_TIM_IRQHandler                 TIM1_UP_IRQHandler 


#define ENCODER3_TIM_CH1_GPIO_CLK_ENABLE()      __HAL_RCC_GPIOA_CLK_ENABLE()
#define ENCODER3_TIM_CH1_GPIO_PORT              GPIOA
#define ENCODER3_TIM_CH1_PIN                    GPIO_PIN_8
#define ENCODER3_TIM_CH1_GPIO_AF                GPIO_AF1_TIM1

#define ENCODER3_TIM_CH2_GPIO_CLK_ENABLE()      __HAL_RCC_GPIOA_CLK_ENABLE()
#define ENCODER3_TIM_CH2_GPIO_PORT              GPIOA
#define ENCODER3_TIM_CH2_PIN                    GPIO_PIN_9
#define ENCODER3_TIM_CH2_GPIO_AF                GPIO_AF1_TIM1

#define ENCODER3_TIM_CH3_GPIO_CLK_ENABLE()      __HAL_RCC_GPIOA_CLK_ENABLE()
#define ENCODER3_TIM_CH3_GPIO_PORT              GPIOA
#define ENCODER3_TIM_CH3_PIN                    GPIO_PIN_10
#define ENCODER3_TIM_CH3_GPIO_AF                GPIO_AF1_TIM1


/*
#define ENCODER3_TIM                            TIM4
#define ENCODER3_TIM_CLK_ENABLE()  				     __HAL_RCC_TIM4_CLK_ENABLE()


#define ENCODER3_TIM_IRQn                       TIM4_IRQn
#define ENCODER3_TIM_IRQHandler                 TIM4_IRQHandler

#define ENCODER3_TIM_CH1_GPIO_CLK_ENABLE()      __HAL_RCC_GPIOD_CLK_ENABLE()
#define ENCODER3_TIM_CH1_GPIO_PORT              GPIOD
#define ENCODER3_TIM_CH1_PIN                    GPIO_PIN_12
#define ENCODER3_TIM_CH1_GPIO_AF                GPIO_AF2_TIM4

#define ENCODER3_TIM_CH2_GPIO_CLK_ENABLE()      __HAL_RCC_GPIOD_CLK_ENABLE()
#define ENCODER3_TIM_CH2_GPIO_PORT              GPIOD
#define ENCODER3_TIM_CH2_PIN                    GPIO_PIN_13
#define ENCODER3_TIM_CH2_GPIO_AF                GPIO_AF2_TIM4

#define ENCODER3_TIM_CH3_GPIO_CLK_ENABLE()      __HAL_RCC_GPIOD_CLK_ENABLE()
#define ENCODER3_TIM_CH3_GPIO_PORT              GPIOD
#define ENCODER3_TIM_CH3_PIN                    GPIO_PIN_14
#define ENCODER3_TIM_CH3_GPIO_AF                GPIO_AF2_TIM4
*/

/* �������ӿڱ�Ƶ�� */
#define ENCODER3_MODE                           TIM_ENCODERMODE_TI12

/* �������ӿ����벶��ͨ����λ���� */
#define ENCODER3_IC1_POLARITY                   TIM_ICPOLARITY_FALLING
#define ENCODER3_IC2_POLARITY                   TIM_ICPOLARITY_RISING

/* �����������ֱ��� */
#define ENCODER3_RESOLUTION                     500

/* ������Ƶ֮����ֱܷ��� */
#if ((ENCODER3_MODE == TIM_ENCODERMODE_TI1) || (ENCODER3_MODE == TIM_ENCODERMODE_TI2))
  #define ENCODER3_TOTAL_RESOLUTION             (ENCODER3_RESOLUTION * 2)  /* 2��Ƶ����ֱܷ��� */
#else
  #define ENCODER3_TOTAL_RESOLUTION             (ENCODER3_RESOLUTION * 4)  /* 4��Ƶ����ֱܷ��� */
#endif

/* ���ٵ�����ٱ� */
#define REDUCTION3_RATIO                        34
/////////////////////////////////End of Encoder3///////////////////////////////////////////////

extern __IO int16_t Encoder_Overflow_Count[MOTOR_IN_USE];
extern TIM_HandleTypeDef TIM_EncoderHandle[MOTOR_IN_USE];

void Encoder_Init(void);
#endif   /* __BSP_ENCODER_H */

