/**
  ******************************************************************************
  * @file    bsp_exti.c
  * @author  fire
  * @version V1.0
  * @date    2016-xx-xx
  * @brief   I/O���ж�Ӧ��bsp
  ******************************************************************************
  * @attention
  *
  * ʵ��ƽ̨:Ұ�� STM32 H743 ������ 
  * ��̳    :http://www.firebbs.cn
  * �Ա�    :http://firestm32.taobao.com
  *
  ******************************************************************************
  */
  
#include "./exti/bsp_exti.h"
#include "./stepper/bsp_stepper_init.h"
#include "./usart/bsp_debug_usart.h"
#include "./i2c_io/bsp_i2c_ee.h"
extern _EEPROM_CONF_STEP ee_conFile[MOTOR_IN_USE];

 /**
  * @brief  ���� PA0 Ϊ���жϿڣ��������ж����ȼ�
  * @param  ��
  * @retval ��
  */
void EXTI_Key_Config(void)
{
    GPIO_InitTypeDef GPIO_InitStructure; 

    /*��������GPIO�ڵ�ʱ��*/
    KEY1_INT_GPIO_CLK_ENABLE();
    KEY2_INT_GPIO_CLK_ENABLE();

    /* ѡ�񰴼�1������ */ 
    GPIO_InitStructure.Pin = KEY1_INT_GPIO_PIN;
    /* ��������Ϊ����ģʽ */ 
    GPIO_InitStructure.Mode = GPIO_MODE_IT_RISING;	    		
    /* �������Ų�����Ҳ������ */
    GPIO_InitStructure.Pull = GPIO_PULLDOWN;
    /* ʹ������Ľṹ���ʼ������ */
    HAL_GPIO_Init(KEY1_INT_GPIO_PORT, &GPIO_InitStructure); 
    /* ���� EXTI �ж�Դ ��key1 ���š������ж����ȼ�*/
   // HAL_NVIC_SetPriority(KEY1_INT_EXTI_IRQ, 7, 0);
    HAL_NVIC_SetPriority(KEY1_INT_EXTI_IRQ, 0, 0);
	/* ʹ���ж� */
    HAL_NVIC_EnableIRQ(KEY1_INT_EXTI_IRQ);

    /* ѡ�񰴼�2������ */ 
    GPIO_InitStructure.Pin = KEY2_INT_GPIO_PIN;  
    /* ����������������ͬ */
    HAL_GPIO_Init(KEY2_INT_GPIO_PORT, &GPIO_InitStructure);      
    /* ���� EXTI �ж�Դ ��key1 ���š������ж����ȼ�*/
    //HAL_NVIC_SetPriority(KEY2_INT_EXTI_IRQ, 7, 0);
    HAL_NVIC_SetPriority(KEY2_INT_EXTI_IRQ, 0, 0);
   /* ʹ���ж� */
    HAL_NVIC_EnableIRQ(KEY2_INT_EXTI_IRQ);
}

//����3�������IO�������жϣ�ʵ������20220322
//�Ż��˺����������жϣ���������ļ��в����ڴ��źţ���ʹ�ܴ��źŵ��жϡ�20220913
void EXTI_STP_Config(void)
{
    GPIO_InitTypeDef GPIO_InitStructure; 

    /*��������GPIO�ڵ�ʱ��*/
    MOTOR_PUL1_GPIO_CLK_ENABLE();
    MOTOR_POS1_GPIO_CLK_ENABLE();
    MOTOR_NEG1_GPIO_CLK_ENABLE();	
    MOTOR_INDEX1_GPIO_CLK_ENABLE();	
    MOTOR_HOME1_GPIO_CLK_ENABLE();	
    MOTOR_COLLISION1_GPIO_CLK_ENABLE();	

    MOTOR_PUL2_GPIO_CLK_ENABLE();
    MOTOR_POS2_GPIO_CLK_ENABLE();
    MOTOR_NEG2_GPIO_CLK_ENABLE();	
    MOTOR_INDEX2_GPIO_CLK_ENABLE();	
    MOTOR_HOME2_GPIO_CLK_ENABLE();	
    MOTOR_COLLISION2_GPIO_CLK_ENABLE();

    MOTOR_PUL3_GPIO_CLK_ENABLE();
    MOTOR_POS3_GPIO_CLK_ENABLE();
    MOTOR_NEG3_GPIO_CLK_ENABLE();	
    MOTOR_INDEX3_GPIO_CLK_ENABLE();	
    MOTOR_HOME3_GPIO_CLK_ENABLE();	
    MOTOR_COLLISION3_GPIO_CLK_ENABLE();

////////////////////////MOTOR1/////////////////////////////////

    GPIO_InitStructure.Pull = GPIO_NOPULL;

    if(UPLIM_AVAILABLE_HCONF1 == (ee_conFile[0].this_HCONF.hconf1 & UPLIM_AVAILABLE_HCONF1) ){
      if(LIMITATION_DIRECTION_HCONF2 == (ee_conFile[0].this_HCONF.hconf2 & LIMITATION_DIRECTION_HCONF2) ){
        GPIO_InitStructure.Pin = MOTOR_NEG1_PIN;  
        if(UP_LIMITIATION_HCONF2 == (ee_conFile[0].this_HCONF.hconf2 & UP_LIMITIATION_HCONF2) ){
          GPIO_InitStructure.Mode = GPIO_MODE_IT_RISING;	    		
        }else{
          GPIO_InitStructure.Mode = GPIO_MODE_IT_FALLING;
        }
        HAL_GPIO_Init(MOTOR_NEG1_PORT, &GPIO_InitStructure);      
        HAL_NVIC_SetPriority(MOTOR_NEG1_INT_EXTI_IRQ, 7, 0); 
        HAL_NVIC_EnableIRQ(MOTOR_NEG1_INT_EXTI_IRQ);      
      }else{
        GPIO_InitStructure.Pin  = MOTOR_POS1_PIN;
        if(UP_LIMITIATION_HCONF2 == (ee_conFile[0].this_HCONF.hconf2 & UP_LIMITIATION_HCONF2) ){
          GPIO_InitStructure.Mode = GPIO_MODE_IT_RISING;	    		
        }else{
          GPIO_InitStructure.Mode = GPIO_MODE_IT_FALLING;
        }
        HAL_GPIO_Init(MOTOR_POS1_PORT, &GPIO_InitStructure); 
        HAL_NVIC_SetPriority(MOTOR_POS1_INT_EXTI_IRQ, 7, 0); 
        HAL_NVIC_EnableIRQ(MOTOR_POS1_INT_EXTI_IRQ);
      }

      #ifdef UART_DEBUG_STP
          printf("uplimt_1 exsit!\r\n");	
      #endif 
    }else{
      #ifdef UART_DEBUG_STP
          printf("NO uplimt_1 !\r\n");	
      #endif       
    }

    if(LOWLIM_AVAILABLE_HCONF1 == (ee_conFile[0].this_HCONF.hconf1 & LOWLIM_AVAILABLE_HCONF1) ){
      if(LIMITATION_DIRECTION_HCONF2 == (ee_conFile[0].this_HCONF.hconf2 & LIMITATION_DIRECTION_HCONF2) ){
        GPIO_InitStructure.Pin  = MOTOR_POS1_PIN;
        if(LOW_LIMITIATION_HCONF2 == (ee_conFile[0].this_HCONF.hconf2 & LOW_LIMITIATION_HCONF2) ){
          GPIO_InitStructure.Mode = GPIO_MODE_IT_RISING;	    		
        }else{
          GPIO_InitStructure.Mode = GPIO_MODE_IT_FALLING;
        }
        HAL_GPIO_Init(MOTOR_POS1_PORT, &GPIO_InitStructure); 
        HAL_NVIC_SetPriority(MOTOR_POS1_INT_EXTI_IRQ, 7, 0); 
        HAL_NVIC_EnableIRQ(MOTOR_POS1_INT_EXTI_IRQ);
      }else{
        GPIO_InitStructure.Pin = MOTOR_NEG1_PIN;  
        if(LOW_LIMITIATION_HCONF2 == (ee_conFile[0].this_HCONF.hconf2 & LOW_LIMITIATION_HCONF2) ){
          GPIO_InitStructure.Mode = GPIO_MODE_IT_RISING;	    		
        }else{
          GPIO_InitStructure.Mode = GPIO_MODE_IT_FALLING;
        }
        HAL_GPIO_Init(MOTOR_NEG1_PORT, &GPIO_InitStructure);      
        HAL_NVIC_SetPriority(MOTOR_NEG1_INT_EXTI_IRQ, 7, 0); 
        HAL_NVIC_EnableIRQ(MOTOR_NEG1_INT_EXTI_IRQ);
      }

      #ifdef UART_DEBUG_STP
        printf("lowlimt_1 exsit!\r\n");	
      #endif 
    }else{
      #ifdef UART_DEBUG_STP
        printf("NO lowlimt_1 !\r\n");	
      #endif       
    }


    if(INDEX_AVAILABLE_HCONF1 == (ee_conFile[0].this_HCONF.hconf1 & INDEX_AVAILABLE_HCONF1) ){
      if(INDEX_HIGH_HCONF2 == (ee_conFile[0].this_HCONF.hconf2 & INDEX_HIGH_HCONF2) ){
        GPIO_InitStructure.Mode = GPIO_MODE_IT_RISING;	    		
      }else{
        GPIO_InitStructure.Mode = GPIO_MODE_IT_FALLING;
      }
      GPIO_InitStructure.Pin = MOTOR_INDEX1_PIN;  
      HAL_GPIO_Init(MOTOR_INDEX1_PORT, &GPIO_InitStructure);      
      HAL_NVIC_SetPriority(MOTOR_INDEX1_INT_EXTI_IRQ, 7, 0); 
      HAL_NVIC_EnableIRQ(MOTOR_INDEX1_INT_EXTI_IRQ);
      #ifdef UART_DEBUG_STP
        printf("index_1 exsit!\r\n");	
      #endif 
    }else{
      #ifdef UART_DEBUG_STP
        printf("NO index_1 !\r\n");	
      #endif       
    }

    if(0 != ( ee_conFile[0].this_HCONF.hconf1 & (BIT1_HOME_AVAILABLE_HCONF1|BIT2_HOME_AVAILABLE_HCONF1|BIT3_HOME_AVAILABLE_HCONF1|BIT4_HOME_AVAILABLE_HCONF1 )) ){
      GPIO_InitStructure.Pin = MOTOR_HOME1_PIN;  
      if(HOME_HIGH_HCONF2 == (ee_conFile[0].this_HCONF.hconf2 & HOME_HIGH_HCONF2) ){
        GPIO_InitStructure.Mode = GPIO_MODE_IT_RISING;	    		
      }else{
        GPIO_InitStructure.Mode = GPIO_MODE_IT_FALLING;
      } 
      HAL_GPIO_Init(MOTOR_HOME1_PORT, &GPIO_InitStructure);      
      HAL_NVIC_SetPriority(MOTOR_HOME1_INT_EXTI_IRQ, 0, 0);
      HAL_NVIC_EnableIRQ(MOTOR_HOME1_INT_EXTI_IRQ);
      #ifdef UART_DEBUG_STP
        printf("home_1 exsit!\r\n");	
      #endif 
    }else{
        #ifdef UART_DEBUG_STP
              printf("NO home_1 !\r\n");	
        #endif       
    }

    if(COLLLIM_AVAILABLE_HCONF1 == (ee_conFile[0].this_HCONF.hconf1 & COLLLIM_AVAILABLE_HCONF1) ){
      GPIO_InitStructure.Pin = MOTOR_COLLISION1_PIN;  
      if(COLLISION_HIGH_HCONF2 == (ee_conFile[0].this_HCONF.hconf2 & COLLISION_HIGH_HCONF2) ){
        GPIO_InitStructure.Mode = GPIO_MODE_IT_RISING;	    		
      }else{
        GPIO_InitStructure.Mode = GPIO_MODE_IT_FALLING;
      }
      HAL_GPIO_Init(MOTOR_COLLISION1_PORT, &GPIO_InitStructure);      
      HAL_NVIC_SetPriority(MOTOR_COLLISION1_INT_EXTI_IRQ, 7, 0);
      HAL_NVIC_EnableIRQ(MOTOR_COLLISION1_INT_EXTI_IRQ);
      #ifdef UART_DEBUG_STP
        printf("col_1 exsit!\r\n");	
      #endif 
    }else{
        #ifdef UART_DEBUG_STP
              printf("NO col_1 !\r\n");	
        #endif       
    }

////////////////////////MOTOR2/////////////////////////////////
  if(UPLIM_AVAILABLE_HCONF1 == (ee_conFile[1].this_HCONF.hconf1 & UPLIM_AVAILABLE_HCONF1) ){
    if(LIMITATION_DIRECTION_HCONF2 == (ee_conFile[1].this_HCONF.hconf2 & LIMITATION_DIRECTION_HCONF2) ){
      // if limts are exchanged
      GPIO_InitStructure.Pin = MOTOR_NEG2_PIN;  
      if(UP_LIMITIATION_HCONF2 == (ee_conFile[1].this_HCONF.hconf2 & UP_LIMITIATION_HCONF2) ){
        GPIO_InitStructure.Mode = GPIO_MODE_IT_RISING;	    		
      }else{
        GPIO_InitStructure.Mode = GPIO_MODE_IT_FALLING;
      }
      HAL_GPIO_Init(MOTOR_NEG2_PORT, &GPIO_InitStructure);      
      HAL_NVIC_SetPriority(MOTOR_NEG2_INT_EXTI_IRQ, 7, 0);
      HAL_NVIC_EnableIRQ(MOTOR_NEG2_INT_EXTI_IRQ);
    }else{
      GPIO_InitStructure.Pin = MOTOR_POS2_PIN;
      if(UP_LIMITIATION_HCONF2 == (ee_conFile[1].this_HCONF.hconf2 & UP_LIMITIATION_HCONF2) ){
        GPIO_InitStructure.Mode = GPIO_MODE_IT_RISING;	    		
      }else{
        GPIO_InitStructure.Mode = GPIO_MODE_IT_FALLING;
      }
      HAL_GPIO_Init(MOTOR_POS2_PORT, &GPIO_InitStructure); 
      HAL_NVIC_SetPriority(MOTOR_POS2_INT_EXTI_IRQ, 7, 0);
      HAL_NVIC_EnableIRQ(MOTOR_POS2_INT_EXTI_IRQ); 
    }


    #ifdef UART_DEBUG_STP
      printf("uplimt_2 exsit!\r\n");	
    #endif  
  }else{
        #ifdef UART_DEBUG_STP
              printf("NO uplimt_2 !\r\n");	
        #endif       
  }
 
  if(LOWLIM_AVAILABLE_HCONF1 == (ee_conFile[1].this_HCONF.hconf1 & LOWLIM_AVAILABLE_HCONF1) ){
    if(LIMITATION_DIRECTION_HCONF2 == (ee_conFile[1].this_HCONF.hconf2 & LIMITATION_DIRECTION_HCONF2) ){
      GPIO_InitStructure.Pin = MOTOR_POS2_PIN;
      if(LOW_LIMITIATION_HCONF2 == (ee_conFile[1].this_HCONF.hconf2 & LOW_LIMITIATION_HCONF2) ){
        GPIO_InitStructure.Mode = GPIO_MODE_IT_RISING;	    		
      }else{
        GPIO_InitStructure.Mode = GPIO_MODE_IT_FALLING;
      }
      HAL_GPIO_Init(MOTOR_POS2_PORT, &GPIO_InitStructure); 
      HAL_NVIC_SetPriority(MOTOR_POS2_INT_EXTI_IRQ, 7, 0);
      HAL_NVIC_EnableIRQ(MOTOR_POS2_INT_EXTI_IRQ); 
    }else{
      GPIO_InitStructure.Pin = MOTOR_NEG2_PIN;  
      if(LOW_LIMITIATION_HCONF2 == (ee_conFile[1].this_HCONF.hconf2 & LOW_LIMITIATION_HCONF2) ){
        GPIO_InitStructure.Mode = GPIO_MODE_IT_RISING;	    		
      }else{
        GPIO_InitStructure.Mode = GPIO_MODE_IT_FALLING;
      }
      HAL_GPIO_Init(MOTOR_NEG2_PORT, &GPIO_InitStructure);      
      HAL_NVIC_SetPriority(MOTOR_NEG2_INT_EXTI_IRQ, 7, 0);
      HAL_NVIC_EnableIRQ(MOTOR_NEG2_INT_EXTI_IRQ);
    }
      #ifdef UART_DEBUG_STP
        printf("lowlimt_2 exsit!\r\n");	
      #endif 
  }else{
      #ifdef UART_DEBUG_STP
        printf("NO lowlimt_2 !\r\n");	
      #endif       
  }

  if(INDEX_AVAILABLE_HCONF1 == (ee_conFile[1].this_HCONF.hconf1 & INDEX_AVAILABLE_HCONF1) ){
    GPIO_InitStructure.Pin = MOTOR_INDEX2_PIN;  
    if(INDEX_HIGH_HCONF2 == (ee_conFile[1].this_HCONF.hconf2 & INDEX_HIGH_HCONF2) ){
      GPIO_InitStructure.Mode = GPIO_MODE_IT_RISING;	    		
    }else{
      GPIO_InitStructure.Mode = GPIO_MODE_IT_FALLING;
    }
    HAL_GPIO_Init(MOTOR_INDEX2_PORT, &GPIO_InitStructure);      
    HAL_NVIC_SetPriority(MOTOR_INDEX2_INT_EXTI_IRQ, 7, 0);
    HAL_NVIC_EnableIRQ(MOTOR_INDEX2_INT_EXTI_IRQ);
    #ifdef UART_DEBUG_STP
        printf("index_2 exsit!\r\n");	
    #endif 
  }else{
    #ifdef UART_DEBUG_STP
        printf("NO index_2 !\r\n");	
    #endif       
  }


  if(0 != ( ee_conFile[1].this_HCONF.hconf1 & (BIT1_HOME_AVAILABLE_HCONF1|BIT2_HOME_AVAILABLE_HCONF1|BIT3_HOME_AVAILABLE_HCONF1|BIT4_HOME_AVAILABLE_HCONF1 )) ){
    GPIO_InitStructure.Pin = MOTOR_HOME2_PIN;  
    if(HOME_HIGH_HCONF2 == (ee_conFile[1].this_HCONF.hconf2 & HOME_HIGH_HCONF2) ){
      GPIO_InitStructure.Mode = GPIO_MODE_IT_RISING;	    		
    }else{
      GPIO_InitStructure.Mode = GPIO_MODE_IT_FALLING;
    } 
    HAL_GPIO_Init(MOTOR_HOME2_PORT, &GPIO_InitStructure);      
    HAL_NVIC_SetPriority(MOTOR_HOME2_INT_EXTI_IRQ, 7, 0);
    HAL_NVIC_EnableIRQ(MOTOR_HOME2_INT_EXTI_IRQ);
        #ifdef UART_DEBUG_STP
              printf("home_2 exsit!\r\n");	
        #endif 
    }else{
        #ifdef UART_DEBUG_STP
              printf("NO home_2 !\r\n");	
        #endif       
    }

  if(COLLLIM_AVAILABLE_HCONF1 == (ee_conFile[1].this_HCONF.hconf1 & COLLLIM_AVAILABLE_HCONF1) ){
    GPIO_InitStructure.Pin = MOTOR_COLLISION2_PIN;  
    if(COLLISION_HIGH_HCONF2 == (ee_conFile[1].this_HCONF.hconf2 & COLLISION_HIGH_HCONF2) ){
      GPIO_InitStructure.Mode = GPIO_MODE_IT_RISING;	    		
    }else{
      GPIO_InitStructure.Mode = GPIO_MODE_IT_FALLING;
    }
    HAL_GPIO_Init(MOTOR_COLLISION2_PORT, &GPIO_InitStructure);      
    HAL_NVIC_SetPriority(MOTOR_COLLISION2_INT_EXTI_IRQ, 7, 0);
    HAL_NVIC_EnableIRQ(MOTOR_COLLISION2_INT_EXTI_IRQ);
    #ifdef UART_DEBUG_STP
      printf("col_2 exsit!\r\n");	
    #endif 
  }else{
    #ifdef UART_DEBUG_STP
      printf("NO col_2 !\r\n");	
    #endif       
  }   
    ////////////////////////MOTOR3/////////////////////////////////
  if(UPLIM_AVAILABLE_HCONF1 == (ee_conFile[2].this_HCONF.hconf1 & UPLIM_AVAILABLE_HCONF1) ){ 
    if(LIMITATION_DIRECTION_HCONF2 == (ee_conFile[2].this_HCONF.hconf2 & LIMITATION_DIRECTION_HCONF2) ){
      GPIO_InitStructure.Pin = MOTOR_NEG3_PIN;  
      if(UP_LIMITIATION_HCONF2 == (ee_conFile[2].this_HCONF.hconf2 & UP_LIMITIATION_HCONF2) ){
        GPIO_InitStructure.Mode = GPIO_MODE_IT_RISING;	    		
      }else{
        GPIO_InitStructure.Mode = GPIO_MODE_IT_FALLING;
      }
      HAL_GPIO_Init(MOTOR_NEG3_PORT, &GPIO_InitStructure);      
      HAL_NVIC_SetPriority(MOTOR_NEG3_INT_EXTI_IRQ, 7, 0);
      HAL_NVIC_EnableIRQ(MOTOR_NEG3_INT_EXTI_IRQ);
    }else{
      GPIO_InitStructure.Pin = MOTOR_POS3_PIN;
      if(UP_LIMITIATION_HCONF2 == (ee_conFile[2].this_HCONF.hconf2 & UP_LIMITIATION_HCONF2) ){
        GPIO_InitStructure.Mode = GPIO_MODE_IT_RISING;	    		
      }else{
        GPIO_InitStructure.Mode = GPIO_MODE_IT_FALLING;
      }
      HAL_GPIO_Init(MOTOR_POS3_PORT, &GPIO_InitStructure); 
      HAL_NVIC_SetPriority(MOTOR_POS3_INT_EXTI_IRQ, 7, 0);
      HAL_NVIC_EnableIRQ(MOTOR_POS3_INT_EXTI_IRQ);   
    }    

 
    #ifdef UART_DEBUG_STP
      printf("uplimt_3 exsit!\r\n");	
    #endif  
  }else{
        #ifdef UART_DEBUG_STP
              printf("NO uplimt_3 !\r\n");	
        #endif       
  }

  if(LOWLIM_AVAILABLE_HCONF1 == (ee_conFile[2].this_HCONF.hconf1 & LOWLIM_AVAILABLE_HCONF1) ){
    if(LIMITATION_DIRECTION_HCONF2 == (ee_conFile[2].this_HCONF.hconf2 & LIMITATION_DIRECTION_HCONF2) ){
    //if channle 0 lims exchange:
      GPIO_InitStructure.Pin = MOTOR_POS3_PIN;
      if(LOW_LIMITIATION_HCONF2 == (ee_conFile[2].this_HCONF.hconf2 & LOW_LIMITIATION_HCONF2) ){
        GPIO_InitStructure.Mode = GPIO_MODE_IT_RISING;	    		
      }else{
        GPIO_InitStructure.Mode = GPIO_MODE_IT_FALLING;
      }
      HAL_GPIO_Init(MOTOR_POS3_PORT, &GPIO_InitStructure); 
      HAL_NVIC_SetPriority(MOTOR_POS3_INT_EXTI_IRQ, 7, 0);
      HAL_NVIC_EnableIRQ(MOTOR_POS3_INT_EXTI_IRQ);       
    }else{
      GPIO_InitStructure.Pin = MOTOR_NEG3_PIN;  
      if(LOW_LIMITIATION_HCONF2 == (ee_conFile[2].this_HCONF.hconf2 & LOW_LIMITIATION_HCONF2) ){
        GPIO_InitStructure.Mode = GPIO_MODE_IT_RISING;	    		
      }else{
        GPIO_InitStructure.Mode = GPIO_MODE_IT_FALLING;
      }
      HAL_GPIO_Init(MOTOR_NEG3_PORT, &GPIO_InitStructure);      
      HAL_NVIC_SetPriority(MOTOR_NEG3_INT_EXTI_IRQ, 7, 0);
      HAL_NVIC_EnableIRQ(MOTOR_NEG3_INT_EXTI_IRQ);
    } 
    #ifdef UART_DEBUG_STP
        printf("lowlimt_3 exsit!\r\n");	
    #endif 
  }else{
      #ifdef UART_DEBUG_STP
        printf("NO lowlimt_3 !\r\n");	
      #endif       
  }

  if(INDEX_AVAILABLE_HCONF1 == (ee_conFile[2].this_HCONF.hconf1 & INDEX_AVAILABLE_HCONF1) ){
    GPIO_InitStructure.Pin = MOTOR_INDEX3_PIN;  
    if(INDEX_HIGH_HCONF2 == (ee_conFile[2].this_HCONF.hconf2 & INDEX_HIGH_HCONF2) ){
      GPIO_InitStructure.Mode = GPIO_MODE_IT_RISING;	    		
    }else{
      GPIO_InitStructure.Mode = GPIO_MODE_IT_FALLING;
    }
    HAL_GPIO_Init(MOTOR_INDEX3_PORT, &GPIO_InitStructure);      
    HAL_NVIC_SetPriority(MOTOR_INDEX3_INT_EXTI_IRQ, 7, 0);
    HAL_NVIC_EnableIRQ(MOTOR_INDEX3_INT_EXTI_IRQ);
    #ifdef UART_DEBUG_STP
        printf("index_3 exsit!\r\n");	
    #endif 
  }else{
    #ifdef UART_DEBUG_STP
        printf("NO index_3 !\r\n");	
    #endif       
  }
  if(0 != ( ee_conFile[2].this_HCONF.hconf1 & (BIT1_HOME_AVAILABLE_HCONF1|BIT2_HOME_AVAILABLE_HCONF1|BIT3_HOME_AVAILABLE_HCONF1|BIT4_HOME_AVAILABLE_HCONF1 )) ){
    GPIO_InitStructure.Pin = MOTOR_HOME3_PIN;  
    if(HOME_HIGH_HCONF2 == (ee_conFile[2].this_HCONF.hconf2 & HOME_HIGH_HCONF2) ){
      GPIO_InitStructure.Mode = GPIO_MODE_IT_RISING;	    		
    }else{
      GPIO_InitStructure.Mode = GPIO_MODE_IT_FALLING;
    } 
    HAL_GPIO_Init(MOTOR_HOME3_PORT, &GPIO_InitStructure);      
    HAL_NVIC_SetPriority(MOTOR_HOME3_INT_EXTI_IRQ, 7, 0);
    HAL_NVIC_EnableIRQ(MOTOR_HOME3_INT_EXTI_IRQ);
      #ifdef UART_DEBUG_STP
        printf("home_3 exsit!\r\n");	
      #endif 
  }else{
      #ifdef UART_DEBUG_STP
        printf("NO home_3 !\r\n");	
       #endif       
  }
  if(COLLLIM_AVAILABLE_HCONF1 == (ee_conFile[2].this_HCONF.hconf1 & COLLLIM_AVAILABLE_HCONF1) ){
    GPIO_InitStructure.Pin = MOTOR_COLLISION3_PIN;  
    if(COLLISION_HIGH_HCONF2 == (ee_conFile[2].this_HCONF.hconf2 & COLLISION_HIGH_HCONF2) ){
      GPIO_InitStructure.Mode = GPIO_MODE_IT_RISING;	    		
    }else{
      GPIO_InitStructure.Mode = GPIO_MODE_IT_FALLING;
    }
    HAL_GPIO_Init(MOTOR_COLLISION3_PORT, &GPIO_InitStructure);      
    HAL_NVIC_SetPriority(MOTOR_COLLISION3_INT_EXTI_IRQ, 7, 0);
    HAL_NVIC_EnableIRQ(MOTOR_COLLISION3_INT_EXTI_IRQ);
    #ifdef UART_DEBUG_STP
      printf("col_3 exsit!\r\n");	
    #endif 
  }else{
    #ifdef UART_DEBUG_STP
      printf("NO col_3 !\r\n");	
    #endif       
  }       
}
void limSignalExchangeHandler(void)
{
  if(LIMITATION_DIRECTION_HCONF2 == (ee_conFile[0].this_HCONF.hconf2 & LIMITATION_DIRECTION_HCONF2) ){
    //if channle 0 lims exchange:
    step_motor[0].limN_port = MOTOR_POS1_PORT;
    step_motor[0].limP_port = MOTOR_NEG1_PORT;
    step_motor[0].limP_pin  = MOTOR_NEG1_PIN;
    step_motor[0].limN_pin  = MOTOR_POS1_PIN;
  }
  if(LIMITATION_DIRECTION_HCONF2 == (ee_conFile[1].this_HCONF.hconf2 & LIMITATION_DIRECTION_HCONF2) ){
    //if channle 0 lims exchange:
    step_motor[1].limN_port = MOTOR_POS2_PORT;
    step_motor[1].limP_port = MOTOR_NEG2_PORT;
    step_motor[1].limP_pin  = MOTOR_NEG2_PIN;
    step_motor[1].limN_pin  = MOTOR_POS2_PIN;
  }
  if(LIMITATION_DIRECTION_HCONF2 == (ee_conFile[2].this_HCONF.hconf2 & LIMITATION_DIRECTION_HCONF2) ){
    //if channle 0 lims exchange:
    step_motor[2].limN_port = MOTOR_POS3_PORT;
    step_motor[2].limP_port = MOTOR_NEG3_PORT;
    step_motor[2].limP_pin  = MOTOR_NEG3_PIN;
    step_motor[2].limN_pin  = MOTOR_POS3_PIN;
  } 
}
/*********************************************END OF FILE**********************/
