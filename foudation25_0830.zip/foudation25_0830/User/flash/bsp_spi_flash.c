 /**
  ******************************************************************************
  * @file    bsp_spi_flash.c
  * @author  fire
  * @version V1.0
  * @date    2015-xx-xx
  * @brief   spi flash �ײ�Ӧ�ú���bsp 
  ******************************************************************************
  * @attention
  *
  * ʵ��ƽ̨:Ұ��STM32 F429 ������
  * ��̳    :http://www.firebbs.cn
  * �Ա�    :https://fire-stm32.taobao.com
  *
  ******************************************************************************
  */
#include "./flash/bsp_spi_flash.h"
#include "stm32h7xx.h"

#include "./stepper/bsp_scan.h"
#include "./Encoder/bsp_encoder2.h"
#include "./usart/bsp_debug_usart.h"
#include "./stepper/bsp_stepper_init.h"
#include "./control/bsp_ctrl.h"
#include "./pid/bsp_pid.h"
#include "./internalFlash/bsp_internalFlash.h"   

#include "./i2c_io/bsp_i2c_ee.h"
#include "./i2c_io/bsp_i2c_gpio.h"

#include <string.h>
#include  <math.h>
/* ��ȡ�������ĳ��� */
#define TxBufferSize1   (countof(TxBuffer1) - 1)
#define RxBufferSize1   (countof(TxBuffer1) - 1)
#define countof(a)      (sizeof(a) / sizeof(*(a)))
#define  BufferSize (countof(Tx_Buffer)-1)

#define  FLASH_WriteAddress     0x00000
#define  FLASH_ReadAddress      FLASH_WriteAddress
#define  FLASH_SectorToErase    FLASH_WriteAddress

uint16_t U16SectorIndex = 0;
/* ���ͻ�������ʼ�� */
uint8_t Tx_Buffer[] = "��л��ѡ��Ұ��stm32������\r\nhttp://firestm32.taobao.com";
uint8_t Rx_Buffer[BufferSize];

//��ȡ��ID�洢λ��
__IO uint32_t DeviceID = 0;
__IO uint32_t FlashID = 0;
__IO TestStatus TransferStatus1 = FAILED;



SPI_HandleTypeDef SpiHandle;

static __IO uint32_t  SPITimeout = SPIT_LONG_TIMEOUT;   

static uint16_t SPI_TIMEOUT_UserCallback(uint8_t errorCode);

ALIGN_32BYTES(uint8_t mainBuffer[MAINBUFFER_SIZES_BYTES]);
ALIGN_32BYTES(uint8_t subBuffer[MAINBUFFER_SIZES_BYTES]);

uint8_t flag_entireFlashEraser = 0;
uint32_t timeForFlashErase     = 40*1000;//ms

extern _EEPROM_STATE_STEP state_motor_struct[MOTOR_IN_USE];
extern uint16_t index_innerFlash ;
extern InnerFlash_info_Struct flashInfoStruct;

/**
  * @brief SPI MSP Initialization 
  *        This function configures the hardware resources used in this example: 
  *           - Peripheral's clock enable
  *           - Peripheral's GPIO Configuration  
  * @param hspi: SPI handle pointer
  * @retval None
  */
void HAL_SPI_MspInit(SPI_HandleTypeDef *hspi)
{
  GPIO_InitTypeDef  GPIO_InitStruct;
  
  /*##-1- Enable peripherals and GPIO Clocks #################################*/
  /* Enable GPIO TX/RX clock */
  SPIx_SCK_GPIO_CLK_ENABLE();
  SPIx_MISO_GPIO_CLK_ENABLE();
  SPIx_MOSI_GPIO_CLK_ENABLE();
  SPIx_CS_GPIO_CLK_ENABLE();
  /* Enable SPI clock */
  SPIx_CLK_ENABLE(); 
  
  /*##-2- Configure peripheral GPIO ##########################################*/  
  /* SPI SCK GPIO pin configuration  */
  GPIO_InitStruct.Pin       = SPIx_SCK_PIN;
  GPIO_InitStruct.Mode      = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull      = GPIO_PULLUP;
  GPIO_InitStruct.Speed     = GPIO_SPEED_FREQ_HIGH;
  GPIO_InitStruct.Alternate = SPIx_SCK_AF;
  
  HAL_GPIO_Init(SPIx_SCK_GPIO_PORT, &GPIO_InitStruct);
    
  /* SPI MISO GPIO pin configuration  */
  GPIO_InitStruct.Pin = SPIx_MISO_PIN;
  GPIO_InitStruct.Alternate = SPIx_MISO_AF;
  
  HAL_GPIO_Init(SPIx_MISO_GPIO_PORT, &GPIO_InitStruct);
  
  /* SPI MOSI GPIO pin configuration  */
  GPIO_InitStruct.Pin = SPIx_MOSI_PIN;
  GPIO_InitStruct.Alternate = SPIx_MOSI_AF;  
  HAL_GPIO_Init(SPIx_MOSI_GPIO_PORT, &GPIO_InitStruct);   

  GPIO_InitStruct.Pin = FLASH_CS_PIN ;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  HAL_GPIO_Init(FLASH_CS_GPIO_PORT, &GPIO_InitStruct); 
}

void SPI_FLASH_Init(void)
{
   /*##-1- Configure the SPI peripheral #######################################*/
  /* Set the SPI parameters */
  SpiHandle.Instance               = SPIx;
  SpiHandle.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_4;
  SpiHandle.Init.Direction         = SPI_DIRECTION_2LINES;
  SpiHandle.Init.CLKPhase          = SPI_PHASE_2EDGE;
  SpiHandle.Init.CLKPolarity       = SPI_POLARITY_HIGH;
  SpiHandle.Init.CRCCalculation    = SPI_CRCCALCULATION_DISABLE;
  SpiHandle.Init.CRCPolynomial     = 7;
  SpiHandle.Init.DataSize          = SPI_DATASIZE_8BIT;
  SpiHandle.Init.FirstBit          = SPI_FIRSTBIT_MSB;
  SpiHandle.Init.NSS               = SPI_NSS_SOFT;
  SpiHandle.Init.TIMode            = SPI_TIMODE_DISABLE;
  
  SpiHandle.Init.Mode = SPI_MODE_MASTER;

  HAL_SPI_Init(&SpiHandle); 
  
  __HAL_SPI_ENABLE(&SpiHandle); 
	
//	SPI_FLASH_Mode_Init();
}


 /**
  * @brief  ����FLASH����
  * @param  SectorAddr��Ҫ������������ַ
  * @retval ��
  */
void SPI_FLASH_SectorErase(uint32_t SectorAddr)
{
  /* ����FLASHдʹ������ */
  SPI_FLASH_WriteEnable();
  SPI_FLASH_WaitForWriteEnd();
  /* �������� */
  /* ѡ��FLASH: CS�͵�ƽ */
  SPI_FLASH_CS_LOW();
  /* ������������ָ��*/
  SPI_FLASH_SendByte(W25X_SectorErase);
  /*���Ͳ���������ַ�ĸ�8λ*/
//  SPI_FLASH_SendByte((SectorAddr & 0xFF000000) >> 24);
  /*���Ͳ���������ַ����ǰ8λ*/
  SPI_FLASH_SendByte((SectorAddr & 0xFF0000) >> 16);
  /* ���Ͳ���������ַ���к�8λ */
  SPI_FLASH_SendByte((SectorAddr & 0xFF00) >> 8);
  /* ���Ͳ���������ַ�ĵ�8λ */
  SPI_FLASH_SendByte(SectorAddr & 0xFF);
  /* ֹͣ�ź� FLASH: CS �ߵ�ƽ */
  SPI_FLASH_CS_HIGH();
  /* �ȴ��������*/
  vTaskDelay(5);
  SPI_FLASH_WaitForWriteEnd();
		

}


 /**
  * @brief  ����FLASH��������Ƭ����
  * @param  ��
  * @retval ��
  */
void SPI_FLASH_BulkErase(void)
{
  /* ����FLASHдʹ������ */
  SPI_FLASH_WriteEnable();

  /* ���� Erase */
  /* ѡ��FLASH: CS�͵�ƽ */
  SPI_FLASH_CS_LOW();
  /* �����������ָ��*/
  SPI_FLASH_SendByte(W25X_ChipErase);
  /* ֹͣ�ź� FLASH: CS �ߵ�ƽ */
  SPI_FLASH_CS_HIGH();

  /* �ȴ��������*/
//  SPI_FLASH_WaitForWriteEnd();
   flag_entireFlashEraser = 1;
   timeForFlashErase      = FLASH_ERASE_TIME_60S;//ms
}

 /**
  * @brief  ��FLASH��ҳд�����ݣ����ñ�����д������ǰ��Ҫ�Ȳ�������
  * @param	pBuffer��Ҫд�����ݵ�ָ��
  * @param WriteAddr��д���ַ
  * @param  NumByteToWrite��д�����ݳ��ȣ�����С�ڵ���SPI_FLASH_PerWritePageSize
  * @retval ��
  */
void SPI_FLASH_PageWrite(uint8_t* pBuffer, uint32_t WriteAddr, uint32_t NumByteToWrite)
{
  /* ����FLASHдʹ������ */
  SPI_FLASH_WriteEnable();

  /* ѡ��FLASH: CS�͵�ƽ */
  SPI_FLASH_CS_LOW();
  /* дҳдָ��*/
  SPI_FLASH_SendByte(W25X_PageProgram);

  /*����д��ַ�ĸ�8λ*/
//  SPI_FLASH_SendByte((WriteAddr & 0xFF000000) >> 24);
  /*����д��ַ����ǰ8λ*/
  SPI_FLASH_SendByte((WriteAddr & 0xFF0000) >> 16);
  /*����д��ַ���к�8λ*/
  SPI_FLASH_SendByte((WriteAddr & 0xFF00) >> 8);
  /*����д��ַ�ĵ�8λ*/
  SPI_FLASH_SendByte(WriteAddr & 0xFF);

  if(NumByteToWrite > SPI_FLASH_PerWritePageSize)
  {
     NumByteToWrite = SPI_FLASH_PerWritePageSize;
     FLASH_ERROR("SPI_FLASH_PageWrite too large!");
  }

  /* д������*/
  while (NumByteToWrite--)
  {
    /* ���͵�ǰҪд����ֽ����� */
    SPI_FLASH_SendByte(*pBuffer);
    /* ָ����һ�ֽ����� */
    pBuffer++;
  }

  /* ֹͣ�ź� FLASH: CS �ߵ�ƽ */
  SPI_FLASH_CS_HIGH();

  /* �ȴ�д�����*/
  SPI_FLASH_WaitForWriteEnd();
}


 /**
  * @brief  ��FLASHд�����ݣ����ñ�����д������ǰ��Ҫ�Ȳ�������
  * @param	pBuffer��Ҫд�����ݵ�ָ��
  * @param  WriteAddr��д���ַ
  * @param  NumByteToWrite��д�����ݳ���
  * @retval ��
  */
void SPI_FLASH_BufferWrite(uint8_t* pBuffer, uint32_t WriteAddr, uint32_t NumByteToWrite)
{
  uint8_t NumOfPage = 0, NumOfSingle = 0, Addr = 0, count = 0, temp = 0;
	
	/*mod�������࣬��writeAddr��SPI_FLASH_PageSize��������������AddrֵΪ0*/
  Addr = WriteAddr % SPI_FLASH_PageSize;
	
	/*��count������ֵ���պÿ��Զ��뵽ҳ��ַ*/
  count = SPI_FLASH_PageSize - Addr;	
	/*�����Ҫд��������ҳ*/
  NumOfPage =  NumByteToWrite / SPI_FLASH_PageSize;
	/*mod�������࣬�����ʣ�಻��һҳ���ֽ���*/
  NumOfSingle = NumByteToWrite % SPI_FLASH_PageSize;

	 /* Addr=0,��WriteAddr �պð�ҳ���� aligned  */
  if (Addr == 0) 
  {
		/* NumByteToWrite < SPI_FLASH_PageSize */
    if (NumOfPage == 0) 
    {
      SPI_FLASH_PageWrite(pBuffer, WriteAddr, NumByteToWrite);
    }
    else /* NumByteToWrite > SPI_FLASH_PageSize */
    {
			/*�Ȱ�����ҳ��д��*/
      while (NumOfPage--)
      {
        SPI_FLASH_PageWrite(pBuffer, WriteAddr, SPI_FLASH_PageSize);
        WriteAddr +=  SPI_FLASH_PageSize;
        pBuffer += SPI_FLASH_PageSize;
      }
			
			/*���ж���Ĳ���һҳ�����ݣ�����д��*/
      SPI_FLASH_PageWrite(pBuffer, WriteAddr, NumOfSingle);
    }
  }
	/* ����ַ�� SPI_FLASH_PageSize ������  */
  else 
  {
		/* NumByteToWrite < SPI_FLASH_PageSize */
    if (NumOfPage == 0) 
    {
			/*��ǰҳʣ���count��λ�ñ�NumOfSingleС��д����*/
      if (NumOfSingle > count) 
      {
        temp = NumOfSingle - count;
				
				/*��д����ǰҳ*/
        SPI_FLASH_PageWrite(pBuffer, WriteAddr, count);
        WriteAddr +=  count;
        pBuffer += count;
				
				/*��дʣ�������*/
        SPI_FLASH_PageWrite(pBuffer, WriteAddr, temp);
      }
      else /*��ǰҳʣ���count��λ����д��NumOfSingle������*/
      {				
        SPI_FLASH_PageWrite(pBuffer, WriteAddr, NumByteToWrite);
      }
    }
    else /* NumByteToWrite > SPI_FLASH_PageSize */
    {
			/*��ַ����������count�ֿ��������������������*/
      NumByteToWrite -= count;
      NumOfPage =  NumByteToWrite / SPI_FLASH_PageSize;
      NumOfSingle = NumByteToWrite % SPI_FLASH_PageSize;

      SPI_FLASH_PageWrite(pBuffer, WriteAddr, count);
      WriteAddr +=  count;
      pBuffer += count;
			
			/*������ҳ��д��*/
      while (NumOfPage--)
      {
        SPI_FLASH_PageWrite(pBuffer, WriteAddr, SPI_FLASH_PageSize);
        WriteAddr +=  SPI_FLASH_PageSize;
        pBuffer += SPI_FLASH_PageSize;
      }
			/*���ж���Ĳ���һҳ�����ݣ�����д��*/
      if (NumOfSingle != 0)
      {
        SPI_FLASH_PageWrite(pBuffer, WriteAddr, NumOfSingle);
      }
    }
  }
}

 /**
  * @brief  ��ȡFLASH����
  * @param 	pBuffer���洢�������ݵ�ָ��
  * @param   ReadAddr����ȡ��ַ
  * @param   NumByteToRead����ȡ���ݳ���
  * @retval ��
  */
void SPI_FLASH_BufferRead(uint8_t* pBuffer, uint32_t ReadAddr, uint32_t NumByteToRead)
{
  /* ѡ��FLASH: CS�͵�ƽ */
  SPI_FLASH_CS_LOW();

  /* ���� �� ָ�� */
  SPI_FLASH_SendByte(W25X_ReadData);

  /* ���� �� ��ַ��8λ */
//  SPI_FLASH_SendByte((ReadAddr & 0xFF000000) >> 24);
  /* ���� �� ��ַ��ǰ8λ */
  SPI_FLASH_SendByte((ReadAddr & 0xFF0000) >> 16);
  /* ���� �� ��ַ�к�8λ */
  SPI_FLASH_SendByte((ReadAddr& 0xFF00) >> 8);
  /* ���� �� ��ַ��8λ */
  SPI_FLASH_SendByte(ReadAddr & 0xFF);
  
	/* ��ȡ���� */
  while (NumByteToRead--)
  {
    /* ��ȡһ���ֽ�*/
    *pBuffer = SPI_FLASH_SendByte(Dummy_Byte);
    /* ָ����һ���ֽڻ����� */
    pBuffer++;
  }

  /* ֹͣ�ź� FLASH: CS �ߵ�ƽ */
  SPI_FLASH_CS_HIGH();
}


 /**
  * @brief  ��ȡFLASH ID
  * @param 	��
  * @retval FLASH ID
  */
uint32_t SPI_FLASH_ReadID(void)
{
  uint32_t Temp = 0, Temp0 = 0, Temp1 = 0, Temp2 = 0;

  /* ��ʼͨѶ��CS�͵�ƽ */
  SPI_FLASH_CS_LOW();

  /* ����JEDECָ���ȡID */
  SPI_FLASH_SendByte(W25X_JedecDeviceID);

  /* ��ȡһ���ֽ����� */
  Temp0 = SPI_FLASH_SendByte(Dummy_Byte);

  /* ��ȡһ���ֽ����� */
  Temp1 = SPI_FLASH_SendByte(Dummy_Byte);

  /* ��ȡһ���ֽ����� */
  Temp2 = SPI_FLASH_SendByte(Dummy_Byte);

  /* ֹͣͨѶ��CS�ߵ�ƽ */
  SPI_FLASH_CS_HIGH();

	/*�����������������Ϊ�����ķ���ֵ*/
  Temp = (Temp0 << 16) | (Temp1 << 8) | Temp2;

  return Temp;
}

 /**
  * @brief  ��ȡFLASH Device ID
  * @param 	��
  * @retval FLASH Device ID
  */
uint32_t SPI_FLASH_ReadDeviceID(void)
{
  uint32_t Temp = 0;

  /* Select the FLASH: Chip Select low */
  SPI_FLASH_CS_LOW();

  /* Send "RDID " instruction */
  SPI_FLASH_SendByte(W25X_DeviceID);
  SPI_FLASH_SendByte(Dummy_Byte);
  SPI_FLASH_SendByte(Dummy_Byte);
  SPI_FLASH_SendByte(Dummy_Byte);
  
  /* Read a byte from the FLASH */
  Temp = SPI_FLASH_SendByte(Dummy_Byte);

  /* Deselect the FLASH: Chip Select high */
  SPI_FLASH_CS_HIGH();

  return Temp;
}
/*******************************************************************************
* Function Name  : SPI_FLASH_StartReadSequence
* Description    : Initiates a read data byte (READ) sequence from the Flash.
*                  This is done by driving the /CS line low to select the device,
*                  then the READ instruction is transmitted followed by 3 bytes
*                  address. This function exit and keep the /CS line low, so the
*                  Flash still being selected. With this technique the whole
*                  content of the Flash is read with a single READ instruction.
* Input          : - ReadAddr : FLASH's internal address to read from.
* Output         : None
* Return         : None
*******************************************************************************/
void SPI_FLASH_StartReadSequence(uint32_t ReadAddr)
{
  /* Select the FLASH: Chip Select low */
  SPI_FLASH_CS_LOW();

  /* Send "Read from Memory " instruction */
  SPI_FLASH_SendByte(W25X_ReadData);

  /* Send the 24-bit address of the address to read from -----------------------*/
  /* Send ReadAddr high nibble address byte */
  SPI_FLASH_SendByte((ReadAddr & 0xFF0000) >> 16);
  /* Send ReadAddr medium nibble address byte */
  SPI_FLASH_SendByte((ReadAddr& 0xFF00) >> 8);
  /* Send ReadAddr low nibble address byte */
  SPI_FLASH_SendByte(ReadAddr & 0xFF);
}


 /**
  * @brief  ʹ��SPI��ȡһ���ֽڵ�����
  * @param  ��
  * @retval ���ؽ��յ�������
  */
uint8_t SPI_FLASH_ReadByte(void)
{
  uint8_t r_byre = 0;
  
  HAL_SPI_Receive(&SpiHandle, &r_byre, 1, 1000);
  return r_byre;
}


 /**
  * @brief  ʹ��SPI����һ���ֽڵ�����
  * @param  byte��Ҫ���͵�����
  * @retval ���ؽ��յ�������
  */
uint8_t SPI_FLASH_SendByte(uint8_t byte)
{
  uint8_t r_byre = 0;
  
  if( HAL_SPI_TransmitReceive(&SpiHandle, &byte, &r_byre, 1, 10000) != HAL_OK)
	{
	//	printf("HAL_SPI_TransmitReceive Error In:%s ,line :%d\r\n",__FILE__,__LINE__);
	}

  return r_byre;
}

/*******************************************************************************
* Function Name  : SPI_FLASH_SendHalfWord
* Description    : Sends a Half Word through the SPI interface and return the
*                  Half Word received from the SPI bus.
* Input          : Half Word : Half Word to send.
* Output         : None
* Return         : The value of the received Half Word.
*******************************************************************************/
uint16_t SPI_FLASH_SendHalfWord(uint16_t HalfWord)
{
  uint16_t r_hbyre = 0;
  
  HAL_SPI_TransmitReceive(&SpiHandle, (uint8_t *)&HalfWord, (uint8_t *)&r_hbyre, 2, 1000);

  return r_hbyre;
}


 /**
  * @brief  ��FLASH���� дʹ�� ����
  * @param  none
  * @retval none
  */
void SPI_FLASH_WriteEnable(void)
{
  /* ͨѶ��ʼ��CS�� */
  SPI_FLASH_CS_LOW();

  /* ����дʹ������*/
  SPI_FLASH_SendByte(W25X_WriteEnable);

  /*ͨѶ������CS�� */
  SPI_FLASH_CS_HIGH();
}

 /**
  * @brief  �ȴ�WIP(BUSY)��־����0�����ȴ���FLASH�ڲ�����д�����
  * @param  none
  * @retval none
  */
void SPI_FLASH_WaitForWriteEnd(void)
{
  uint8_t FLASH_Status = 0;

  /* ѡ�� FLASH: CS �� */
  SPI_FLASH_CS_LOW();

  /* ���� ��״̬�Ĵ��� ���� */
  SPI_FLASH_SendByte(W25X_ReadStatusReg);

  SPITimeout = SPIT_FLAG_TIMEOUT;
  /* ��FLASHæµ����ȴ� */
  do
  {
    /* ��ȡFLASHоƬ��״̬�Ĵ��� */
    FLASH_Status = SPI_FLASH_SendByte(Dummy_Byte);	 

    {
      if((SPITimeout--) == 0) 
      {
				/* ��ʱ������,��Ƭ����ʱ���ܳ�ʱ,��ʾһ�¾Ϳ��� */
        SPI_TIMEOUT_UserCallback(4);
//        return;
      }
    } 
  }
  while ((FLASH_Status & WIP_Flag) == SET); /* ����д���־ */
  /* ֹͣ�ź�  FLASH: CS �� */
  SPI_FLASH_CS_HIGH();
}

//return 0: busy
//return 1: done
uint8_t SPI_FLASH_readEnd(void)
{
    uint8_t FLASH_Status = 0;
    uint8_t  returnValue = 0;
    SPI_FLASH_CS_LOW(); 

    SPI_FLASH_SendByte(W25X_ReadStatusReg);
    FLASH_Status = SPI_FLASH_SendByte(Dummy_Byte);	 
    if((FLASH_Status & WIP_Flag) == SET){
      returnValue = 0;
    }else{
      returnValue = 1;
    }

    SPI_FLASH_CS_HIGH();
     return returnValue;
}
//�������ģʽ
void SPI_Flash_PowerDown(void)   
{ 
  /* ѡ�� FLASH: CS �� */
  SPI_FLASH_CS_LOW();

  /* ���� ���� ���� */
  SPI_FLASH_SendByte(W25X_PowerDown);

  /* ֹͣ�ź�  FLASH: CS �� */
  SPI_FLASH_CS_HIGH();
}   

//����
void SPI_Flash_WAKEUP(void)   
{
  /*ѡ�� FLASH: CS �� */
  SPI_FLASH_CS_LOW();

  /* ���� �ϵ� ���� */
  SPI_FLASH_SendByte(W25X_ReleasePowerDown);

  /* ֹͣ�ź� FLASH: CS �� */
  SPI_FLASH_CS_HIGH();                   //�ȴ�TRES1
}   

 /**
  * @brief  ʹ SPI_FLASH ���� 4 �ֽڵ�ַģʽ
  * @param  none
  * @retval none
  */
void SPI_FLASH_Mode_Init(void)
{
	uint8_t Temp;
	
	/*ѡ�� FLASH: CS �� */
	SPI_FLASH_CS_LOW();
	
	/* ����״̬�Ĵ��� 3 ���� */
	SPI_FLASH_SendByte(W25X_ReadStatusRegister3); 
	
	Temp = SPI_FLASH_SendByte(Dummy_Byte);
	
	/* ֹͣ�ź� FLASH: CS �� */
	SPI_FLASH_CS_HIGH();
	
	if((Temp&0x01) == 0)
	{
		/*ѡ�� FLASH: CS �� */
		SPI_FLASH_CS_LOW();
		
		/* ����4�ֽ�ģʽ */
		SPI_FLASH_SendByte(W25X_Enter4ByteMode);
		
		/* ֹͣ�ź� FLASH: CS �� */
		SPI_FLASH_CS_HIGH();
	}
}


/**
  * @brief  �ȴ���ʱ�ص�����
  * @param  None.
  * @retval None.
  */
static  uint16_t SPI_TIMEOUT_UserCallback(uint8_t errorCode)
{
  /* �ȴ���ʱ��Ĵ���,���������Ϣ */
//  FLASH_ERROR("SPI �ȴ���ʱ!errorCode = %d",errorCode);
  return 0;
}
 void SPI_Test(void)
{
	/* ��ȡ Flash Device ID */
	DeviceID = SPI_FLASH_ReadDeviceID();
    SPI_FLASH_CS_HIGH();
////	vTaskDelay(200);
	/* ��ȡ SPI Flash ID */
///	FlashID = SPI_FLASH_ReadID();
	//printf("\r\nFlashID is 0x%X,  Manufacturer Device ID is 0x%X\r\n", FlashID, DeviceID);
	/* ���� SPI Flash ID */
//	if (FlashID == sFLASH_ID){	
		  __disable_irq();
    SPI_FLASH_SectorErase(U16SectorIndex*4096);	 	 
		SPI_FLASH_BufferWrite(Tx_Buffer, U16SectorIndex*4096, BufferSize);
		//printf("\r\nд�������Ϊ��\r\n%s", Tx_Buffer);
		  __enable_irq();
		/* ���ո�д������ݶ������ŵ����ջ������� */
		SPI_FLASH_BufferRead(Rx_Buffer, U16SectorIndex*4096, BufferSize);
		//printf("\r\n����������Ϊ��\r\n%s", Rx_Buffer);
		
		/* ���д�������������������Ƿ���� */
		TransferStatus1 = Buffercmp(Tx_Buffer, Rx_Buffer, BufferSize);
		
		if( PASSED == TransferStatus1 ){    
			LED_ALLON;
			printf("\r%d\n\r",U16SectorIndex);
      U16SectorIndex ++; 
		}
		else{        
			LED2_ON;
			printf("\r\nerrorat: %d!\n\r",U16SectorIndex);
		}
//	}// if (FlashID == sFLASH_ID)
/*	else
	{    
		LED2_ON;
		printf("\r\n��ȡ���� W25Q128 ID!\n\r");
	}
*/	
	SPI_Flash_PowerDown(); 

}   
 /** ��������Buffercmp
 * ����  ���Ƚ������������е������Ƿ����
 * ����  ��-pBuffer1     src������ָ��
 *         -pBuffer2     dst������ָ��
 *         -BufferLength ����������
 * ���  ����
 * ����  ��-PASSED pBuffer1 ����   pBuffer2
 *         -FAILED pBuffer1 ��ͬ�� pBuffer2
 */
TestStatus Buffercmp(uint8_t* pBuffer1, uint8_t* pBuffer2, uint16_t BufferLength)
{
  while(BufferLength--)
  {
    if(*pBuffer1 != *pBuffer2)
    {
      return FAILED;
    }

    pBuffer1++;
    pBuffer2++;
  }
  return PASSED;
}

void jointMotorStatus2Memory(uint8_t* mainBuffer)
{
  uint8_t SigleLen = (uint16_t)( sizeof(State_mini_paras_STEP) + 1 );

  memcpy( (void*)&mainBuffer[ 0         ],(void*)&state_motor_struct[0], SigleLen);
  memcpy( (void*)&mainBuffer[ SigleLen  ],(void*)&state_motor_struct[1], SigleLen);
  memcpy( (void*)&mainBuffer[ 2*SigleLen],(void*)&state_motor_struct[2], SigleLen);
}
void writeStatusFlash(void)
{
    uint8_t subBuffer[128];
	  uint8_t errorTime=0;
    uint16_t byte2Write = 3* (uint16_t)( sizeof(State_mini_paras_STEP) + 1 );
    uint16_t tempSectorIndex;
    jointMotorStatus2Memory(mainBuffer);
    if (U16SectorIndex == (MAX_SECTOR ) ) {
      U16SectorIndex        = 0;     
      flag_entireFlashEraser = 1;// it's time to erase the entire Flash.
      #ifdef UART_DEBUG_STP
          printf("Erasing!\n");  
      #endif      
      SPI_FLASH_BulkErase();//
      #ifdef UART_DEBUG_STP
          printf("Done!\n");  
      #endif      
      return ;
    }
    if(flag_entireFlashEraser == 2){
       tempSectorIndex =  0;
			flag_entireFlashEraser = 0;
     // printf("\r\n after erase!\n\r");      
    }
    else{
       tempSectorIndex =  U16SectorIndex +1 ;
    }
    if(0 == flag_entireFlashEraser){
      //  __disable_irq();
        SPI_FLASH_ReadDeviceID();
	      vTaskDelay(1);		
        SPI_FLASH_BufferWrite(mainBuffer,  BASE_STATE_FLASH_ADDRESS_MOTOR + tempSectorIndex*SPI_FLASH_PerSectorSize, byte2Write);
      //  __enable_irq();
	      //vTaskDelay(1);				
		    SPI_FLASH_BufferRead(subBuffer, BASE_STATE_FLASH_ADDRESS_MOTOR + tempSectorIndex*SPI_FLASH_PerSectorSize, byte2Write);
		    TransferStatus1 = Buffercmp(subBuffer, mainBuffer, byte2Write);
        //printf("\r\n 1st write!\n\r");             
        while(PASSED != TransferStatus1){
           // __disable_irq();
            SPI_FLASH_ReadDeviceID();
        	  vTaskDelay(1);		
            SPI_FLASH_SectorErase( BASE_STATE_FLASH_ADDRESS_MOTOR + U16SectorIndex*STATUS_FLASH_Per_VOLUME);
            SPI_FLASH_BufferWrite(mainBuffer,  BASE_STATE_FLASH_ADDRESS_MOTOR + tempSectorIndex*STATUS_FLASH_Per_VOLUME, byte2Write);
           // __enable_irq(); 
        		SPI_FLASH_BufferRead(subBuffer, BASE_STATE_FLASH_ADDRESS_MOTOR + tempSectorIndex*STATUS_FLASH_Per_VOLUME, byte2Write);
        
        	  TransferStatus1 = Buffercmp(subBuffer, mainBuffer, byte2Write);
            printf("\r\n errorTime: %d!\n\r",errorTime++);
        }
        #ifdef UART_DEBUG_STP
	          if( PASSED == TransferStatus1 ){    
	          	if(tempSectorIndex == MAX_SECTOR)
              printf("\r SPI write to:%d\n\r",tempSectorIndex);
	          }
	          else{        
	         // 	printf("\r\n errorat: %d!\n\r",tempSectorIndex);
	          }
        #endif 
        U16SectorIndex = tempSectorIndex;      
    }

}
void readStatusFlash(void)
{
    uint16_t byte2Write = 3* (uint16_t)( sizeof(State_mini_paras_STEP) + 1 );
    uint8_t SigleLen = (uint16_t)( sizeof(State_mini_paras_STEP) + 1 );
	  DeviceID = SPI_FLASH_ReadDeviceID();
	  //vTaskDelay(1);
	 // __disable_irq();
    SPI_FLASH_BufferRead(mainBuffer, BASE_STATE_FLASH_ADDRESS_MOTOR + (U16SectorIndex)*SPI_FLASH_PerSectorSize, byte2Write);
   // __enable_irq();
	  memcpy( (void*)&state_motor_struct[0],(void*)&mainBuffer[ 0         ], SigleLen);
    memcpy( (void*)&state_motor_struct[1],(void*)&mainBuffer[ SigleLen  ], SigleLen);
    memcpy( (void*)&state_motor_struct[2],(void*)&mainBuffer[ 2*SigleLen], SigleLen);
}

uint8_t FLASH_find_sector_offset_state(uint16_t* pU16SectorIndex)
{
  uint16_t u16_tempOffset = 0;
  uint8_t u8_temp         = 0;
  uint8_t u8_occupied     = (uint8_t)HEAD_IN_EEPROM;
  u16_tempOffset          =  divide2Advance(pU16SectorIndex, FLASH_STATE_SECTOR ,MAX_SECTOR);

  SPI_FLASH_BufferRead(mainBuffer, BASE_STATE_FLASH_ADDRESS_MOTOR + u16_tempOffset*SPI_FLASH_PerSectorSize, 1);          
	u8_temp         = mainBuffer[0];//read memory			
  if(u8_temp != u8_occupied){// all empty;
    printf("FLASH EMPTY!\n");
    return 0;
  }	
  #ifdef UART_DEBUG_STP
  printf("pU16SectorIndex is %d !\n",*pU16SectorIndex);  
  #endif

  return 1;       
}
uint8_t initial_state_motor_struct_Flash(void)
{
    uint8_t u8_temp = 0;
    uint8_t i       = 0;
  
    divide2Advance_innerFlash(&index_innerFlash, 0, INNER_FLASH_MAX_INDEX);
    if(1 ==FLASH_find_sector_offset_state(&U16SectorIndex)){// successful
       readStatusFlash();
       for(i = 0; i < MOTOR_IN_USE; i ++){
          state_motor_struct[i].state_struct.stateMachine                 = STEP_STOP;
          state_motor_struct[i].state_struct.scanMode_Shadow              = 0;
          state_motor_struct[i].state_struct.scanTime_2_wait_ms_shadow    = 0;    
       }
    }else{//empty. Or the flash was erasing when the system powered down.
        readStatusFlash(); 
        u8_temp = state_motor_struct[i].head;
      if(u8_temp ==(uint8_t)HEAD_IN_EEPROM ){    // that is ,in the 0 offset , the data is available
             return 0;
      }else{// ,need to check the inner flash
          //find the offset in innerFlash
            divide2Advance_innerFlash(&index_innerFlash, 0, INNER_FLASH_MAX_INDEX);
        		innerFlash_Read_state_back_for_FLASH();
            u8_temp = state_motor_struct[2].head;         
          if(u8_temp ==(uint8_t)HEAD_IN_EEPROM ){// inner Flash is not empy           
             if(OUT_FLASH_NOT_FINISH == flashInfoStruct.u32_flag_tail_erasering){// the inner flash is available ,meanwihle the outer flash is not finished with erasing 
             // USE the INNER flash stateSturct, already read.
             //erasing the outer flash again
                U16SectorIndex         = 0;     
                flag_entireFlashEraser = 1;
                SPI_FLASH_BulkErase();//
 	              printf( "continuing erasing\n");
	              printf( "\n" );               
             }else{// the inner flash is available, meanwihle the outer flash is not finished with erasing 
             // this is a very special case, if the outer flash just finished erasring, and there is no time for the system to write 
             // the very fisrt state to outer FLASH, so  no need to erase the outer FLASH, just use the inner flash content.
             // make sure the inner and the out FLASH are not earing at the same time!
             }
          }else{// both the inner and the outer flash are all emptpy
          // erase the inner and the outer flash for safty.
          //load the default state              
						for(i = 0; i < MOTOR_IN_USE; i ++){
                //the miniState content
                 state_motor_struct[i].head = (uint8_t)HEAD_IN_EEPROM;
                 state_motor_struct[i].state_struct.miniState.state                = 0x0000;
                 state_motor_struct[i].state_struct.miniState.valueSet             = 0.0;
                 state_motor_struct[i].state_struct.miniState.valueActual          = 0.0;
                 state_motor_struct[i].state_struct.miniState.valueEncoder         = 0x00000000;
                 state_motor_struct[i].state_struct.miniState.speedSet             = 0.0;
                 state_motor_struct[i].state_struct.miniState.speedActual          = 0.0;
                 state_motor_struct[i].state_struct.miniState.homeDistance         = 0.0;
                 state_motor_struct[i].state_struct.miniState.homeValueApproximate = 0;
                 //the paras used in system, no need to upload
                 state_motor_struct[i].state_struct.valueTriggeredorNot       = 0;
                 state_motor_struct[i].state_struct.slaveChanel               = 0;
                 state_motor_struct[i].state_struct.countInPWM_IRQ            = 0;
                 state_motor_struct[i].state_struct.scanMode                  = 0;
                 state_motor_struct[i].state_struct.scanTime_2_wait_ms        = 0; 
                 state_motor_struct[i].state_struct.wait_or_not               = 0;
                 state_motor_struct[i].state_struct.enable_or_not             = 0;
                 state_motor_struct[i].state_struct.pulse_out_or_not          = 0;
                 state_motor_struct[i].state_struct.scan_start                = 0;
                 state_motor_struct[i].state_struct.scan_stop                 = 0;
                 state_motor_struct[i].state_struct.scan_step                 = 0;
                 state_motor_struct[i].state_struct.scan_velosity             = 0;
                 state_motor_struct[i].state_struct.stateMachine              = STEP_STOP;
                 state_motor_struct[i].state_struct.scanMode_Shadow           = 0;
                 state_motor_struct[i].state_struct.scanTime_2_wait_ms_shadow = 0;
                 state_motor_struct[i].state_struct.enable_triggered          = 0;
                 state_motor_struct[i].state_struct.homeUsed                  = 0;
                 state_motor_struct[i].state_struct.f_Start_homedistance      = 0;
                 state_motor_struct[i].state_struct.u8_direction_down         = 0;
                 state_motor_struct[i].state_struct.u8_direction_up           = 0;
                 state_motor_struct[i].state_struct.f_valueActual_test        = 0;
              }
						// 
							  U16SectorIndex         = 0;     
                flag_entireFlashEraser = 1;
                SPI_FLASH_BulkErase();//
 	              printf( "continuing erasing\n");
	              printf( "\n" );  
              //writeStatusFlash();
          }
      }//  end of // ,need to check the inner flash

    }// end of else //empty. Or the flash was erasing when the system powered down.
		return 0;
}

uint16_t divide2(uint16_t*u16_offset, uint16_t startIndex, uint16_t endIndex)
{
    uint8_t u8_temp;
    uint8_t u8_target   = (uint8_t)HEAD_IN_EEPROM;
    uint8_t u8_occupied = 0x00;
    uint8_t u8_newArea  = 0xff;
    uint16_t currentPosition = (unsigned short)((startIndex + endIndex)>>1);
    
    SPI_FLASH_BufferRead(mainBuffer, BASE_STATE_FLASH_ADDRESS_MOTOR + currentPosition*SPI_FLASH_PerSectorSize, 1);
    u8_temp = mainBuffer[0];//read memory

    while(u8_temp != u8_target)	{
		// up direction
        if(currentPosition == endIndex - 1){
			*u16_offset = endIndex;
			return endIndex;
		}	
		if(currentPosition == startIndex + 1){
			*u16_offset = startIndex;
			return startIndex;
		}	
		if(u8_occupied == mainBuffer[0]){
		  startIndex      = currentPosition;
      currentPosition = (unsigned short)((startIndex +endIndex)>>1);
      SPI_FLASH_BufferRead(mainBuffer, BASE_STATE_FLASH_ADDRESS_MOTOR + currentPosition*SPI_FLASH_PerSectorSize, 1);
      u8_temp = mainBuffer[0];//read memory
		}
		if(u8_newArea == mainBuffer[currentPosition]){
		  endIndex        = currentPosition;
      currentPosition = (unsigned short)((startIndex +endIndex)>>1);
		  u8_temp         = mainBuffer[currentPosition];//read memory			
		}
	}
	*u16_offset = currentPosition;
	return currentPosition;
}
// finding current postion where the newest status stored
uint16_t divide2Advance(unsigned short *u16_offset, uint16_t startIndex, uint16_t  endIndex)
{
  uint8_t  u8_temp;  
  uint8_t u8_occupied      = (uint8_t)HEAD_IN_EEPROM;
	uint16_t currentPosition = (unsigned short)((startIndex + endIndex)>>1);
  uint16_t u16_searchTimes = 0;  
  float    f_tempFloat     = 0.0;
  SPI_FLASH_BufferRead(mainBuffer, BASE_STATE_FLASH_ADDRESS_MOTOR + currentPosition*STATUS_FLASH_Per_VOLUME, 1);          
  u8_temp    = (uint8_t)mainBuffer[0];

  if(currentPosition == startIndex){
    *u16_offset = startIndex;
	  return startIndex;
  }

  if(currentPosition == endIndex ){
    *u16_offset = endIndex;
	  return endIndex;
  }
  #ifdef UART_DEBUG_STP   
      printf( "u16_searchTimes:%d\n",u16_searchTimes );
	    printf( "currentPosition:%d\n",currentPosition );
	    printf( "\n" );
	#endif  
	u16_searchTimes ++;
  while((currentPosition != startIndex)&&(currentPosition != endIndex)){
	  if(u8_occupied == u8_temp ){// up finding new u8_newArea
		  startIndex      = currentPosition;
      currentPosition = (unsigned short)((startIndex +endIndex)>>1);
      SPI_FLASH_BufferRead(mainBuffer, BASE_STATE_FLASH_ADDRESS_MOTOR + currentPosition*STATUS_FLASH_Per_VOLUME, 1);          
		  u8_temp         = mainBuffer[0];//read memory
      }
	  else{
    if(u8_occupied != u8_temp){
		  endIndex        = currentPosition;
      currentPosition = (unsigned short)((startIndex +endIndex)>>1);
      SPI_FLASH_BufferRead(mainBuffer, BASE_STATE_FLASH_ADDRESS_MOTOR + currentPosition*STATUS_FLASH_Per_VOLUME, 1);          
		  u8_temp         = mainBuffer[0];//read memory					
		}
	  }
	
		f_tempFloat = 0.5F*(float)(startIndex +endIndex);
    #ifdef UART_DEBUG_STP   
        printf( "u16_searchTimes:%d\n",u16_searchTimes );
	      printf( "currentPosition:%d\n",currentPosition );
	      printf( "\n" );
	  #endif  
	  u16_searchTimes ++;
  } // end of while

	*u16_offset = currentPosition;		
  if(currentPosition == (MAX_SECTOR - 1) ){
        if(f_tempFloat > (float)(currentPosition)){
	    	  currentPosition++;
	         *u16_offset = currentPosition;
	    }
	    else{
	         *u16_offset = currentPosition;		
	    }
	}

    #ifdef UART_DEBUG_STP   
	      printf( "f_tempFloat:%f\n",f_tempFloat );
        printf( "u16_offset:%d\n",*u16_offset );
	  #endif   
	return currentPosition;
}
// write 4095 times,  the actual value i*1.00001 ,setValue is actualValue*2
void writeStatusFlash_TEST(void)
{
    uint8_t subBuffer[128];
    uint16_t byte2Write      = 3* (uint16_t)( sizeof(State_mini_paras_STEP) + 1 );
    uint16_t tempSectorIndex = 0;
    uint8_t errorTime = 0;
   /* for(i = 0; i < MOTOR_IN_USE; i ++){
      state_motor_struct[i].state_struct.miniState.valueSet    = 111111;
      state_motor_struct[i].state_struct.miniState.valueActual = tempSectorIndex *0.0001;
    }*/
    jointMotorStatus2Memory(mainBuffer);
    if (U16SectorIndex == (MAX_SECTOR ) ) {
      flag_entireFlashEraser = 1;// it's time to erase the entire Flash.
      #ifdef UART_DEBUG_STP
          printf("Erasing!\n");  
      #endif      
      SPI_FLASH_BulkErase();//
      #ifdef UART_DEBUG_STP
          printf("Done!\n");  
      #endif      
      tempSectorIndex        = 0;
      //return ;
    }else{
       tempSectorIndex =  U16SectorIndex + 1;
    }
 //
    __disable_irq();
   // vTaskDelay(100);
    SPI_FLASH_ReadDeviceID();
	  vTaskDelay(1);		
    SPI_FLASH_SectorErase( BASE_STATE_FLASH_ADDRESS_MOTOR + tempSectorIndex*SPI_FLASH_PerSectorSize);	 	 
    SPI_FLASH_BufferWrite(mainBuffer,  BASE_STATE_FLASH_ADDRESS_MOTOR + tempSectorIndex*STATUS_FLASH_Per_VOLUME, byte2Write);
    __enable_irq(); 
		SPI_FLASH_BufferRead(subBuffer, BASE_STATE_FLASH_ADDRESS_MOTOR + tempSectorIndex*STATUS_FLASH_Per_VOLUME, byte2Write);

	  TransferStatus1 = Buffercmp(subBuffer, mainBuffer, byte2Write);
    while(PASSED != TransferStatus1){
        __disable_irq();
       // vTaskDelay(100);
        SPI_FLASH_ReadDeviceID();
    	  vTaskDelay(1);		
       // SPI_FLASH_SectorErase( BASE_STATE_FLASH_ADDRESS_MOTOR + U16SectorIndex*STATUS_FLASH_Per_VOLUME);	 	 
        SPI_FLASH_BufferWrite(mainBuffer,  BASE_STATE_FLASH_ADDRESS_MOTOR + tempSectorIndex*STATUS_FLASH_Per_VOLUME, byte2Write);
        __enable_irq(); 
    		SPI_FLASH_BufferRead(subBuffer, BASE_STATE_FLASH_ADDRESS_MOTOR + tempSectorIndex*STATUS_FLASH_Per_VOLUME, byte2Write);
    
    	  TransferStatus1 = Buffercmp(subBuffer, mainBuffer, byte2Write);
        printf("\r\n errorTime: %d!\n\r",errorTime++);
    }
		if( PASSED == TransferStatus1 ){   
      if(FLAH_TEST_LEN > 400){
			  if((U16SectorIndex % 10 )== 0)
        printf("\r%d\n\r",U16SectorIndex);     
      }else{
 			  printf("\r%d\n\r",U16SectorIndex);       
      }
		}
		else{        
			printf("\r\n errorat: %d!\n\r",U16SectorIndex);
		} 
    U16SectorIndex = tempSectorIndex;
		//������Ч����ʵ��ִ��ʱ�� 500us
}
void Flash_readStatus_Test(uint16_t index)
{
  uint8_t subBuffer[128];
  int i;

  uint16_t byte2Write = 3* (uint16_t)( sizeof(State_mini_paras_STEP) + 1 );
  uint8_t SigleLen    = (uint16_t)( sizeof(State_mini_paras_STEP) + 1 );
	
  for(i = 0; i <=index; i ++){
    //SPI_FLASH_ReadDeviceID();
	  //vTaskDelay(100);	
		SPI_FLASH_BufferRead(subBuffer, BASE_STATE_FLASH_ADDRESS_MOTOR + i*STATUS_FLASH_Per_VOLUME, byte2Write);
	  memcpy( (void*)&state_motor_struct[0],(void*)&subBuffer[ 0         ], SigleLen);
    memcpy( (void*)&state_motor_struct[1],(void*)&subBuffer[ SigleLen  ], SigleLen);
    memcpy( (void*)&state_motor_struct[2],(void*)&subBuffer[ 2*SigleLen], SigleLen);
    if(index > 400){
			  if((i % 10 )== 0){
             #ifdef UART_DEBUG_STP   
             	  printf( "%d:\n",i );
                 /*printf( "set0:%f\n",    state_motor_struct[0].state_struct.miniState.valueSet );
	               printf( "actual0:%f\n", state_motor_struct[0].state_struct.miniState.valueActual );        
                 printf( "set1:%f\n",    state_motor_struct[1].state_struct.miniState.valueSet );
	               printf( "actual1:%f\n", state_motor_struct[1].state_struct.miniState.valueActual );
	               printf( "\n" );*/
                 printf( "set2:%f\n",    state_motor_struct[2].state_struct.miniState.valueSet );
	               printf( "actual2:%f\n", state_motor_struct[2].state_struct.miniState.valueActual );
	               printf( "\n" );
	           #endif               
        }

    }
    else{
    #ifdef UART_DEBUG_STP   
    	  printf( "%d:\n",i );
        /*printf( "set0:%f\n",    state_motor_struct[0].state_struct.miniState.valueSet );
	      printf( "actual0:%f\n", state_motor_struct[0].state_struct.miniState.valueActual );

        printf( "set1:%f\n",    state_motor_struct[1].state_struct.miniState.valueSet );
	      printf( "actual1:%f\n", state_motor_struct[1].state_struct.miniState.valueActual );
	      printf( "\n" );*/
        printf( "set2:%f\n",    state_motor_struct[2].state_struct.miniState.valueSet );
	      printf( "actual2:%f\n", state_motor_struct[2].state_struct.miniState.valueActual );
	      printf( "\n" );
	  #endif     
    }



 
  }

}
void SetallMotorStatusDefault(void)
{ int i;
  for(i = 0; i < MOTOR_IN_USE; i ++){
    //the miniState content
    state_motor_struct[i].head = (uint8_t)HEAD_IN_EEPROM;
    state_motor_struct[i].state_struct.miniState.state                = 0x0000;
    state_motor_struct[i].state_struct.miniState.valueSet             = 0.0;
    state_motor_struct[i].state_struct.miniState.valueActual          = 0.0;
    state_motor_struct[i].state_struct.miniState.valueEncoder         = 0x00000000;
    state_motor_struct[i].state_struct.miniState.speedSet             = 0.0;
    state_motor_struct[i].state_struct.miniState.speedActual          = 0.0;
    state_motor_struct[i].state_struct.miniState.homeDistance         = 0.0;
    state_motor_struct[i].state_struct.miniState.homeValueApproximate = 0;
    //the paras used in system, no need to upload
    state_motor_struct[i].state_struct.valueTriggeredorNot       = 0;
    state_motor_struct[i].state_struct.slaveChanel               = 0;
    state_motor_struct[i].state_struct.countInPWM_IRQ            = 0;
    state_motor_struct[i].state_struct.scanMode                  = 0;
    state_motor_struct[i].state_struct.scanTime_2_wait_ms        = 0; 
    state_motor_struct[i].state_struct.wait_or_not               = 0;
    state_motor_struct[i].state_struct.enable_or_not             = 0;
    state_motor_struct[i].state_struct.pulse_out_or_not          = 0;
    state_motor_struct[i].state_struct.scan_start                = 0;
    state_motor_struct[i].state_struct.scan_stop                 = 0;
    state_motor_struct[i].state_struct.scan_step                 = 0;
    state_motor_struct[i].state_struct.scan_velosity             = 0;
    state_motor_struct[i].state_struct.stateMachine              = STEP_STOP;
    state_motor_struct[i].state_struct.scanMode_Shadow           = 0;
    state_motor_struct[i].state_struct.scanTime_2_wait_ms_shadow = 0;
    state_motor_struct[i].state_struct.enable_triggered          = 0;
    state_motor_struct[i].state_struct.homeUsed                  = 0;
    state_motor_struct[i].state_struct.f_Start_homedistance      = 0;
    state_motor_struct[i].state_struct.u8_direction_down         = 0;
    state_motor_struct[i].state_struct.u8_direction_up           = 0;
    state_motor_struct[i].state_struct.f_valueActual_test        = 0;
 }
}
/*********************************************END OF FILE**********************/
