#ifndef __SPI_FLASH_H
#define __SPI_FLASH_H

#include "stm32h7xx.h"
#include <stdio.h>
#include "./led/bsp_led.h"  

/* Private typedef -----------------------------------------------------------*/
//#define  sFLASH_ID                       0xEF3015     //W25X16
//#define  sFLASH_ID                       0xEF4015	    //W25Q16
//#define  sFLASH_ID                        0XEF4017     //W25Q64
#define  sFLASH_ID                       0XEF4018     //W25Q128
//#define  sFLASH_ID                       0XEF4019     //W25Q256


//#define SPI_FLASH_PageSize            4096
#define SPI_FLASH_PageSize              256
#define SPI_FLASH_PerWritePageSize      256
#define SPI_FLASH_PerSectorSize         4096
/* Private define ------------------------------------------------------------*/
/*�����-��ͷ*******************************/
#define W25X_WriteEnable		      0x06 
#define W25X_WriteDisable		      0x04 
#define W25X_ReadStatusReg		    0x05 
#define W25X_WriteStatusReg		  0x01 
#define W25X_ReadData			        0x03 
#define W25X_FastReadData		      0x0B 
#define W25X_FastReadDual		      0x3B 
#define W25X_PageProgram		      0x02 
#define W25X_BlockErase			      0xD8 
#define W25X_SectorErase		      0x20 
#define W25X_ChipErase			      0xC7 
#define W25X_PowerDown			      0xB9 
#define W25X_ReleasePowerDown	  0xAB 
#define W25X_DeviceID			        0xAB 
#define W25X_ManufactDeviceID   	0x90 
#define W25X_JedecDeviceID		    0x9F 
#define W25X_Enter4ByteMode		    0xB7
#define W25X_ReadStatusRegister3      0x15

#define WIP_Flag                  0x01  /* Write In Progress (WIP) flag */
#define Dummy_Byte                0xFF
/*�����-��β*******************************/
#define SPIx                             SPI1
#define SPIx_CLK_ENABLE()                __HAL_RCC_SPI1_CLK_ENABLE()
#define SPIx_SCK_GPIO_CLK_ENABLE()       __HAL_RCC_GPIOB_CLK_ENABLE()
#define SPIx_MISO_GPIO_CLK_ENABLE()      __HAL_RCC_GPIOB_CLK_ENABLE() 
#define SPIx_MOSI_GPIO_CLK_ENABLE()      __HAL_RCC_GPIOB_CLK_ENABLE() 
#define SPIx_CS_GPIO_CLK_ENABLE()        __HAL_RCC_GPIOG_CLK_ENABLE() 

#define SPIx_FORCE_RESET()               __HAL_RCC_SPI1_FORCE_RESET()
#define SPIx_RELEASE_RESET()             __HAL_RCC_SPI1_RELEASE_RESET()

//SCK����
#define SPIx_SCK_PIN                     GPIO_PIN_3
#define SPIx_SCK_GPIO_PORT               GPIOB
#define SPIx_SCK_AF                      GPIO_AF5_SPI1
//MISO����
#define SPIx_MISO_PIN                    GPIO_PIN_4
#define SPIx_MISO_GPIO_PORT              GPIOB
#define SPIx_MISO_AF                     GPIO_AF5_SPI1
//MOSI����
#define SPIx_MOSI_PIN                    GPIO_PIN_5
#define SPIx_MOSI_GPIO_PORT              GPIOB
#define SPIx_MOSI_AF                     GPIO_AF5_SPI1
//CS(NSS)����
#define FLASH_CS_PIN                     GPIO_PIN_6               
#define FLASH_CS_GPIO_PORT               GPIOG                     
//����Ϊ�ߵ�ƽ	
//#define	digitalHi(p,i)			    {p->BSRRH=i;}		
////����͵�ƽ
//#define digitalLo(p,i)			    {p->BSRRL=i;}				
#define SPI_FLASH_CS_LOW()      digitalLo(FLASH_CS_GPIO_PORT,FLASH_CS_PIN )
#define SPI_FLASH_CS_HIGH()     digitalHi(FLASH_CS_GPIO_PORT,FLASH_CS_PIN )
/*SPI�ӿڶ���-��β****************************/

/*�ȴ���ʱʱ��*/
#define SPIT_FLAG_TIMEOUT         ((uint32_t)0x8000)
#define SPIT_LONG_TIMEOUT         ((uint32_t)(10 * SPIT_FLAG_TIMEOUT))

/*��Ϣ���*/
#define FLASH_DEBUG_ON         1

#define FLASH_INFO(fmt,arg...)           printf("<<-FLASH-INFO->> "fmt"\n",##arg)
#define FLASH_ERROR(fmt,arg...)          printf("<<-FLASH-ERROR->> "fmt"\n",##arg)
#define FLASH_DEBUG(fmt,arg...)          do{\
                                          if(FLASH_DEBUG_ON)\
                                          printf("<<-FLASH-DEBUG->> [%d]"fmt"\n",__LINE__, ##arg);\
                                          }while(0)

// 4096 Setors 
// Sector 0~2  for confile0~2, each 4096 Bytes, but 256 bytes per page
#define STATUS_FLASH_Per_VOLUME           (4096)
#define BASE_FLASH_ADDRESS_CONFILE0       (0X00)
#define BASE_FLASH_ADDRESS_CONFILE1       (BASE_FLASH_ADDRESS_CONFILE0 + SPI_FLASH_PerSectorSize)
#define BASE_FLASH_ADDRESS_CONFILE2       (BASE_FLASH_ADDRESS_CONFILE1 + SPI_FLASH_PerSectorSize)


//Secter3~4095
#define FLASH_STATE_SECTOR                0
// #define BASE_STATE_FLASH_ADDRESS_MOTOR    (BASE_FLASH_ADDRESS_CONFILE0 + FLASH_STATE_SECTOR*SPI_FLASH_PerSectorSize)
#define BASE_STATE_FLASH_ADDRESS_MOTOR    (0 )
#define MAX_SECTOR                        4095
#define FLAH_TEST_LEN                     4000

#define FLASH_ERASE_TIME_60S               (60*1000)

#define MAINBUFFER_SIZES_BYTES             (256)


typedef enum { FAILED = 0, PASSED = !FAILED} TestStatus;
void SPI_FLASH_Init(void);
void SPI_FLASH_SectorErase(uint32_t SectorAddr);
void SPI_FLASH_BulkErase(void);
void SPI_FLASH_PageWrite(uint8_t* pBuffer, uint32_t WriteAddr, uint32_t NumByteToWrite);
void SPI_FLASH_BufferWrite(uint8_t* pBuffer, uint32_t WriteAddr, uint32_t NumByteToWrite);
void SPI_FLASH_BufferRead(uint8_t* pBuffer, uint32_t ReadAddr, uint32_t NumByteToRead);
uint32_t SPI_FLASH_ReadID(void);
uint32_t SPI_FLASH_ReadDeviceID(void);
void SPI_FLASH_StartReadSequence(uint32_t ReadAddr);
void SPI_Flash_PowerDown(void);
void SPI_Flash_WAKEUP(void);
void SPI_FLASH_Mode_Init(void);


uint8_t SPI_FLASH_ReadByte(void);
uint8_t SPI_FLASH_SendByte(uint8_t byte);
uint16_t SPI_FLASH_SendHalfWord(uint16_t HalfWord);
void SPI_FLASH_WriteEnable(void);
void SPI_FLASH_WaitForWriteEnd(void);
void SPI_Test(void);
TestStatus Buffercmp(uint8_t* pBuffer1, uint8_t* pBuffer2, uint16_t BufferLength);
void jointMotorStatus2Memory(uint8_t* mainBuffer);
void writeStatusFlash(void);
void readStatusFlash(void);
uint8_t FLASH_find_sector_offset_state(uint16_t* U16SectorIndex);
uint16_t divide2Advance(unsigned short *u16_offset, uint16_t startIndex, uint16_t  endIndex);

void writeStatusFlash_TEST(void);
void Flash_readStatus_Test(uint16_t index);



uint8_t SPI_FLASH_readEnd(void);
void SetallMotorStatusDefault(void);

#endif /* __SPI_FLASH_H */

