/**
  ******************************************************************************
  * @file    bsp_i2c_ee.c
  * @version V1.0
  * @date    2020-xx-xx
  * @brief   i2c EEPROM(AT24C02)Ӧ�ú���bsp
  ******************************************************************************
  * @attention
  *
  * ʵ��ƽ̨:Ұ��  STM32 F407 ������ 
  * ��̳    :http://www.firebbs.cn
  * �Ա�    :https://fire-stm32.taobao.com
  *
  ******************************************************************************
  */ 

#include "./i2c_io/bsp_i2c_ee.h"
#include "./i2c_io/bsp_i2c_gpio.h"
#include "./usart/bsp_debug_usart.h"
#include "stm32h7xx.h"
#include "./usart/bsp_debug_usart.h"
#include "./stepper/bsp_stepper_init.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define  DATA_Size			128
_EEPROM_CONF_STEP ee_conFile[MOTOR_IN_USE];
HCONF motor_hconf[MOTOR_IN_USE];
ALIGN_32BYTES(_EEPROM_STATE_STEP state_motor_struct[MOTOR_IN_USE]);
uint16_t pageOffSet_StateInEEPROM = 0; 
static	uint8_t  tempArray[64] ;
uint16_t succsessfulTime = 0;
static uint8_t I2c_Buf_Read[DATA_Size];
HOME_SIGNALS_STRUCT motor_Home_Sig_Sturct[MOTOR_IN_USE];

/*
*********************************************************************************************************
*	�� �� ��: ee_CheckOk
*	����˵��: �жϴ���EERPOM�Ƿ�����
*	��    �Σ���
*	�� �� ֵ: 1 ��ʾ������ 0 ��ʾ������
*********************************************************************************************************
*/
uint8_t ee_CheckOk(void)
{
	if (i2c_CheckDevice(EEPROM_DEV_ADDR) == 0)
	{
		return 1;
	}
	else
	{
		/* ʧ�ܺ��мǷ���I2C����ֹͣ�ź� */
		i2c_Stop();		
		return 0;
	}
}

/*
*********************************************************************************************************
*	�� �� ��: ee_ReadBytes
*	����˵��: �Ӵ���EEPROMָ����ַ����ʼ��ȡ��������
*	��    �Σ�_usAddress : ��ʼ��ַ
*			 _usSize : ���ݳ��ȣ���λΪ�ֽ�
*			 _pReadBuf : ��Ŷ��������ݵĻ�����ָ��
*	�� �� ֵ: 0 ��ʾʧ�ܣ�1��ʾ�ɹ�
*********************************************************************************************************
*/
uint8_t ee_ReadBytes(uint8_t *_pReadBuf, uint16_t _usAddress, uint16_t _usSize)
{
	uint16_t i;
	
	/* ���ô���EEPROM�漴��ȡָ�����У�������ȡ�����ֽ� */
	
	/* ��1��������I2C���������ź� */
	i2c_Start();
	
	/* ��2������������ֽڣ���7bit�ǵ�ַ��bit0�Ƕ�д����λ��0��ʾд��1��ʾ�� */
	i2c_SendByte(EEPROM_DEV_ADDR | EEPROM_I2C_WR);	/* �˴���дָ�� */
	 
	/* ��3�����ȴ�ACK */
	if (i2c_WaitAck() != 0)
	{
		goto cmd_fail;	/* EEPROM������Ӧ�� */
	}

	/* ��4���������ֽڵ�ַ��24C02ֻ��256�ֽڣ����1���ֽھ͹��ˣ������24C04���ϣ���ô�˴���Ҫ���������ַ */
	i2c_SendByte((uint8_t)(_usAddress>>8));
	if (i2c_WaitAck() != 0)
	{
		goto cmd_fail;	/* EEPROM������Ӧ�� */
	}		
	i2c_SendByte((uint8_t)_usAddress);
	
	/* ��5�����ȴ�ACK */
	if (i2c_WaitAck() != 0)
	{
		goto cmd_fail;	/* EEPROM������Ӧ�� */
	}
	
	/* ��6������������I2C���ߡ�ǰ��Ĵ����Ŀ����EEPROM���͵�ַ�����濪ʼ��ȡ���� */
	i2c_Start();
	
	/* ��7������������ֽڣ���7bit�ǵ�ַ��bit0�Ƕ�д����λ��0��ʾд��1��ʾ�� */
	i2c_SendByte(EEPROM_DEV_ADDR | EEPROM_I2C_RD);	/* �˴��Ƕ�ָ�� */
	
	/* ��8��������ACK */
	if (i2c_WaitAck() != 0)
	{
		goto cmd_fail;	/* EEPROM������Ӧ�� */
	}	
	
	/* ��9����ѭ����ȡ���� */
	for (i = 0; i < _usSize; i++)
	{
		_pReadBuf[i] = i2c_ReadByte();	/* ��1���ֽ� */
		
		/* ÿ����1���ֽں���Ҫ����Ack�� ���һ���ֽڲ���ҪAck����Nack */
		if (i != _usSize - 1)
		{
			i2c_Ack();	/* �м��ֽڶ����CPU����ACK�ź�(����SDA = 0) */
		}
		else
		{
			i2c_NAck();	/* ���1���ֽڶ����CPU����NACK�ź�(����SDA = 1) */
		}
	}
	/* ����I2C����ֹͣ�ź� */
	i2c_Stop();
	return 1;	/* ִ�гɹ� */

cmd_fail: /* ����ִ��ʧ�ܺ��мǷ���ֹͣ�źţ�����Ӱ��I2C�����������豸 */
	/* ����I2C����ֹͣ�ź� */
	i2c_Stop();
	return 0;
}

/*
*********************************************************************************************************
*	�� �� ��: ee_WriteBytes
*	����˵��: ����EEPROMָ����ַд���������ݣ�����ҳд�������д��Ч��
*	��    �Σ�_usAddress : ��ʼ��ַ
*			 _usSize : ���ݳ��ȣ���λΪ�ֽ�
*			 _pWriteBuf : ��Ŷ��������ݵĻ�����ָ��
*	�� �� ֵ: 0 ��ʾʧ�ܣ�1��ʾ�ɹ�
*********************************************************************************************************
*/
uint8_t ee_WriteBytes(uint8_t *_pWriteBuf, uint16_t _usAddress, uint16_t _usSize)
{
	uint16_t i,m;
	uint16_t usAddr;
	
	/* 
		д����EEPROM�������������������ȡ�ܶ��ֽڣ�ÿ��д����ֻ����ͬһ��page��
		����24xx02��page size = 8
		�򵥵Ĵ�������Ϊ�����ֽ�д����ģʽ��ûд1���ֽڣ������͵�ַ
		Ϊ���������д��Ч��: ����������page wirte������
	*/

	usAddr = _usAddress;	
	for (i = 0; i < _usSize; i++)
	{
		/* �����͵�1���ֽڻ���ҳ���׵�ַʱ����Ҫ���·��������źź͵�ַ */
		if ((i == 0) || (usAddr & (EEPROM_PAGE_SIZE - 1)) == 0)
		{
			/*���ڣ�������ֹͣ�źţ������ڲ�д������*/
			i2c_Stop();
			
			/* ͨ���������Ӧ��ķ�ʽ���ж��ڲ�д�����Ƿ����, һ��С�� 10ms 			
				CLKƵ��Ϊ200KHzʱ����ѯ����Ϊ30������
			*/
			for (m = 0; m < 1000; m++)
			{				
				/* ��1��������I2C���������ź� */
				i2c_Start();
				
				/* ��2������������ֽڣ���7bit�ǵ�ַ��bit0�Ƕ�д����λ��0��ʾд��1��ʾ�� */
				i2c_SendByte(EEPROM_DEV_ADDR | EEPROM_I2C_WR);	/* �˴���дָ�� */
				
				/* ��3��������һ��ʱ�ӣ��ж������Ƿ���ȷӦ�� */
				if (i2c_WaitAck() == 0)
				{
					break;
				}
			}
			if (m  == 1000)
			{
				goto cmd_fail;	/* EEPROM����д��ʱ */
			}
		
			/* ��4.1���������ֽڵ�ַ��24C02ֻ��256�ֽڣ����1���ֽھ͹��ˣ������24C04���ϣ���ô�˴���Ҫ���������ַ */
			// 24c128 16λ��ַ

			i2c_SendByte((uint8_t)(usAddr>>8));
			if (i2c_WaitAck() != 0)
			{
				goto cmd_fail;	/* EEPROM������Ӧ�� */
			}			
			i2c_SendByte((uint8_t)(usAddr&0x00ff));
			
			/* ��5�����ȴ�ACK */
			if (i2c_WaitAck() != 0)
			{
				goto cmd_fail;	/* EEPROM������Ӧ�� */
			}
		}
	
		/* ��6������ʼд������ */
		i2c_SendByte(_pWriteBuf[i]);
	
		/* ��7��������ACK */
		if (i2c_WaitAck() != 0)
		{
			goto cmd_fail;	/* EEPROM������Ӧ�� */
		}

		usAddr++;	/* ��ַ��1 */		
	}
	
	/* ����ִ�гɹ�������I2C����ֹͣ�ź� */
	i2c_Stop();
	return 1;

cmd_fail: /* ����ִ��ʧ�ܺ��мǷ���ֹͣ�źţ�����Ӱ��I2C�����������豸 */
	/* ����I2C����ֹͣ�ź� */
	i2c_Stop();
	return 0;
}


void ee_Erase(void)
{
	uint16_t i;
	uint8_t buf[EEPROM_SIZE];
	
	/* ��仺���� */
	for (i = 0; i < EEPROM_SIZE; i++)
	{
		buf[i] = 0xFF;
	}
	
	/* дEEPROM, ��ʼ��ַ = 0�����ݳ���Ϊ 256 */
	if (ee_WriteBytes(buf, 0, EEPROM_SIZE) == 0)
	{
		printf("����eeprom������\r\n");
		return;
	}
	else
	{
		printf("����eeprom�ɹ���\r\n");
	}
}


/*--------------------------------------------------------------------------------------------------*/
static void ee_Delay(__IO uint32_t nCount)	 //�򵥵���ʱ����
{
	for(; nCount != 0; nCount--);
}


/*
 * eeprom AT24C02 ��д����
 * ��������1���쳣����0
 */
uint8_t ee_Test(void) 
{
  uint16_t i;
	uint8_t write_buf[EEPROM_SIZE];
  uint8_t read_buf[EEPROM_SIZE];
	static int time = 0;
  
/*-----------------------------------------------------------------------------------*/  
  if (ee_CheckOk() == 0)
	{
		// û�м�⵽EEPROM 
		printf("û�м�⵽����EEPROM!\r\n");
				
		return 0;
	}
/*------------------------------------------------------------------------------------*/  
  /* �����Ի����� */
	for (i = 0; i < EEPROM_SIZE; i++)
	{		
		write_buf[i] = i;
	}
/*------------------------------------------------------------------------------------*/  
  if (ee_WriteBytes(write_buf, time*EEPROM_SIZE, EEPROM_SIZE) == 0)
	{
//		printf("дeeprom������\r\n");
		return 0;
	}
	else
	{		
	//	printf("дeeprom�ɹ���\r\n");
	}
  
  /*д��֮����Ҫ�ʵ�����ʱ��ȥ������Ȼ�����*/
  ee_Delay(0x0FFFFF);
/*-----------------------------------------------------------------------------------*/
  if (ee_ReadBytes(read_buf, time*EEPROM_SIZE, EEPROM_SIZE) == 0)
	{
	//	printf("��eeprom������\r\n");
		return 0;
	}
	else
	{		
	//	printf("��eeprom�ɹ����������£�\r\n");
	}
/*-----------------------------------------------------------------------------------*/  
  for (i = 0; i < EEPROM_SIZE; i++)
	{
		if(read_buf[i] != write_buf[i])
		{
	//		printf("0x%02X ", read_buf[i]);
		//	printf("����:EEPROM������д������ݲ�һ��");
			return 0;
		}
  //  printf(" %02X", read_buf[i]);
		
		if ((i & 15) == 15)
		{
		//	printf("\r\n");	
		}		
	}
   printf("eeprom��д���Գɹ� %d\r\n",time);
	time ++;
  return 1;
}


uint32_t I2C_EE_WriteConfigFiles(uint8_t MotorChannel,  _EEPROM_CONF_STEP* pEE_conf)
{
  uint16_t WritePageStartAdd = 0;
  HAL_StatusTypeDef status = HAL_OK;
  
  uint16_t NumByteToWrite = (uint16_t)(sizeof(_EEPROM_CONF_STEP));
  // uint16_t NumByteToWrite = 128;
  uint8_t* pBuffer = (uint8_t*)pEE_conf;

  switch (MotorChannel)
  {
  case 0x00:
      WritePageStartAdd = (uint16_t) BASE_EEPROM_ADDRESS_MOTOR1;
    break;
  case 0x01:
      WritePageStartAdd = (uint16_t) BASE_EEPROM_ADDRESS_MOTOR2;
    break;
  case 0x02:
      WritePageStartAdd =  (uint16_t) BASE_EEPROM_ADDRESS_MOTOR3;
    break;  
  default:
    break;
  }
  ee_WriteBytes(pBuffer, WritePageStartAdd,  NumByteToWrite);
  return status;
}

uint32_t I2C_EE_ReadConfigFiles(uint8_t MotorChannel,  _EEPROM_CONF_STEP* pEE_conf)
{
  uint16_t ReadPageStartAdd = 0;
  HAL_StatusTypeDef status = HAL_OK;
  
  uint16_t NumByteToRead = sizeof(_EEPROM_CONF_STEP);
  uint8_t* pBuffer = (uint8_t*)pEE_conf;

  #ifdef UART_DEBUG_STP
  printf("sizeof(_EEPROM_CONF_STEP) is %d !\n",NumByteToRead);  
  #endif 
  switch (MotorChannel)
  {
  case 0x00:
      ReadPageStartAdd =  (uint16_t) BASE_EEPROM_ADDRESS_MOTOR1;
    break;
  case 0x01:
      ReadPageStartAdd =  (uint16_t) BASE_EEPROM_ADDRESS_MOTOR2;
    break;
  case 0x02:
      ReadPageStartAdd =  (uint16_t) BASE_EEPROM_ADDRESS_MOTOR3;
    break;  
  default:
    break;
  }
  status =  ee_ReadBytes(pBuffer, ReadPageStartAdd,  NumByteToRead);
  return status;
}
uint8_t initial_confile_motor_struct(void)
{
  uint8_t i = 0, j = 0;
  uint8_t checkState = 0;
  char c_tempMotorName[MOTORNAME_LEN]= {'m','o','t','o','r','1'};
  for(i = 0; i < MOTOR_IN_USE; i ++) {  
    I2C_EE_ReadConfigFiles(i, &ee_conFile[i]);
    if( HEAD_IN_EEPROM != ee_conFile[i].head){ 
      checkState = 1;
      break;
    }
  }
  //���ͨ��У�飬�����溯���岻ִ��
  if( 1 == checkState ){
    #ifdef UART_DEBUG_STP
    printf("Confile are ALL EMPTY! \n");  
    #endif
    for(i = 0; i < MOTOR_IN_USE; i ++){
      //��д��Ĭ��ֵ
      ee_conFile[i].head              = HEAD_IN_EEPROM;
      ee_conFile[i].motorindex        = i;
     for(j = 0; j < 5; j++){
      ee_conFile[i].motorName[j]      = c_tempMotorName[j];
     }
      ee_conFile[i].motorName[j]      = 0x30 + i;	 
      ee_conFile[i].this_HCONF.hconf1 = 0;
      ee_conFile[i].this_HCONF.hconf2 = 0;
      ee_conFile[i].this_HCONF.hconf2 = 0;
      ee_conFile[i].motorType         = 0x01;
      ee_conFile[i].current           = 1.0;
      ee_conFile[i].currentBias       = 50;
      ee_conFile[i].fullStep          = 200;
      ee_conFile[i].gearRatio         = 1;
      ee_conFile[i].home              = 0.0;
      ee_conFile[i].upperLimitation   = 0.0;
      ee_conFile[i].lowerLimitation   = 0.0;
      ee_conFile[i].resolution        = 0.001;
      ee_conFile[i].maxSpeedFast      = 0.0;
      ee_conFile[i].minSpeedSlow      = 0.0;
      ee_conFile[i].accelerationTime  = 0.0;
      ee_conFile[i].encoderCounts     = 2000;
      ee_conFile[i].backlash          = 0.0;
      ee_conFile[i].positionError     = 0.0;
      ee_conFile[i].DCBiasCurrent     = 0.0;
      ee_conFile[i].DCOpenCurrentHigh = 0.0;
      ee_conFile[i].DCOpenCurrentLow  = 0.0;
      ee_conFile[i].rotationAvailable = 0;
      ee_conFile[i].posKp             = 0.0;
      ee_conFile[i].posKi             = 0.0;
      ee_conFile[i].velForwardFeed    = 0.0;
      ee_conFile[i].posKiLimit        = 0.0;
      ee_conFile[i].microStep         = 256;
      I2C_EE_WriteConfigFiles( i, &ee_conFile[i]);
    }
  }
  return 1;
}
uint8_t print_ee_MOTOR_ConfigFileIntial(void);
uint8_t print_ee_MOTOR_ConfigFileIntial(void)
{
  	uint8_t i,j;
    for(i = 0; i < MOTOR_IN_USE; i ++)
    { 
      printf("-----------------------------------\n");
      printf(" this is the motor %d \n",i);
      printf(" motorindex is %d \n", ee_conFile[i].motorindex);
      printf(" name is : \n");
      for(j = 0; j < MOTORNAME_LEN; j ++)
        { 
          if(ee_conFile[i].motorName[j] != 0x00){
            printf("%c",ee_conFile[i].motorName[j]);
        }
         else{
           printf("\n");
          break;
        }

      }
      printf(" motorindex is %x \n", ee_conFile[i].this_HCONF.hconf1);
      printf(" motorindex is %x \n", ee_conFile[i].this_HCONF.hconf2);
      printf(" motorindex is %x \n", ee_conFile[i].this_HCONF.hconf3);
      //��һ��ϸ��3��hconf
      print_ee_Hconf1( (HCONF*) &ee_conFile[i].this_HCONF );
      print_ee_Hconf2( (HCONF*) &ee_conFile[i].this_HCONF );

      printf(" motorType is %d \n", ee_conFile[i].motorType);

      printf(" Current is %f \n", ee_conFile[i].current);

      printf(" currentBias is %d \n", ee_conFile[i].currentBias);
      printf(" fullStep is %d \n", ee_conFile[i].fullStep);
      printf(" gearRatio is %d \n", ee_conFile[i].gearRatio);

      printf(" home is %f \n", ee_conFile[i].home);

      printf(" upperLimitation is %f \n", ee_conFile[i].upperLimitation);
      printf(" lowerLimitation is %f \n", ee_conFile[i].lowerLimitation);
      printf(" resolution is %f \n",  ee_conFile[i].resolution);

      printf(" maxSpeedFast is %f \n", ee_conFile[i].maxSpeedFast);
      printf(" mimSpeedSlow is %f \n", ee_conFile[i].minSpeedSlow);
      printf(" accelerationTime is %f \n", ee_conFile[i].accelerationTime);

      printf(" encoderCounts is %d \n", ee_conFile[i].encoderCounts);
       printf(" backlash is %f \n", ee_conFile[i].backlash);

      printf(" positionError is %f \n", ee_conFile[i].positionError);
      printf(" DCBiasCurrent is %f \n", ee_conFile[i].DCBiasCurrent);
      printf(" DCOpenCurrentHigh is %f \n", ee_conFile[i].DCOpenCurrentHigh);
      printf(" DCOpenCurrentLow is %f \n", ee_conFile[i].DCOpenCurrentLow);

      printf(" rotationAvailable is %d \n", ee_conFile[i].rotationAvailable);

      printf(" posKp is %f \n", ee_conFile[i].posKp);
      printf(" posKi is %f \n", ee_conFile[i].posKi);
      printf(" posKd is %f \n", ee_conFile[i].posKd);

      printf(" velForwardFeed is %f \n", ee_conFile[i].velForwardFeed);
      printf(" posKiLimit is %f \n", ee_conFile[i].posKiLimit);
      printf(" microStep is  %d \n", ee_conFile[i].microStep);
      }

	  return 1;
}
void print_ee_Hconf1(HCONF* phconf)
{
  if ( (phconf->hconf1 & ENCODER_AVAILABLE_HCONF1) == ENCODER_AVAILABLE_HCONF1){
   printf(" ENCODER_AVAILABLE_HCONF1  \n"); 
  }
  if ( (phconf->hconf1 & INDEX_AVAILABLE_HCONF1) == INDEX_AVAILABLE_HCONF1){
   printf(" INDEX_AVAILABLE_HCONF1  \n"); 
  }
  if ( (phconf->hconf1 & LOWLIM_AVAILABLE_HCONF1) == LOWLIM_AVAILABLE_HCONF1){
   printf(" LOWLIM_AVAILABLE_HCONF1  \n"); 
  }
  if ( (phconf->hconf1 & UPLIM_AVAILABLE_HCONF1) == UPLIM_AVAILABLE_HCONF1)
  {
   printf(" UPLIM_AVAILABLE_HCONF1  \n"); 
  }
    if ( (phconf->hconf1 & COLLLIM_AVAILABLE_HCONF1) == COLLLIM_AVAILABLE_HCONF1)
  {
   printf(" COLLLIM_AVAILABLE_HCONF1  \n"); 
  }
    if ( (phconf->hconf1 & ENABLE_AVAILABLE_HCONF1) == ENABLE_AVAILABLE_HCONF1)
  {
   printf(" ENABLE_AVAILABLE_HCONF1  \n"); 
  }
    if ( (phconf->hconf1 & LOW_AS_HOME_AVAILABLE_HCONF1) == LOW_AS_HOME_AVAILABLE_HCONF1)
  {
   printf(" LOW_AS_HOME_AVAILABLE_HCONF1  \n"); 
  }
    if ( (phconf->hconf1 & UP_AS_HOME_AVAILABLE_HCONF1) == UP_AS_HOME_AVAILABLE_HCONF1)
  {
   printf(" UP_AS_HOME_AVAILABLE_HCONF1  \n"); 
  }
    if ( (phconf->hconf1 & RESERVED_AVAILABLE_HCONF1 )== RESERVED_AVAILABLE_HCONF1)
  {
   printf(" RESERVED_AVAILABLE_HCONF1  \n"); 
  }
    if ( (phconf->hconf1 & RESERVED__AVAILABLEHCONF1) == RESERVED__AVAILABLEHCONF1)
  {
   printf(" RESERVED__AVAILABLEHCONF1  \n"); 
  }
    if ( (phconf->hconf1 & BIT1_UNIT_AVAILABLE_HCONF1 )== BIT1_UNIT_AVAILABLE_HCONF1)
  {
   printf(" BIT1_UNIT_AVAILABLE_HCONF1  \n"); 
  }
    if ( (phconf->hconf1 & BIT2_UNIT_AVAILABLE_HCONF1) == BIT2_UNIT_AVAILABLE_HCONF1)
  {
   printf(" BIT2_UNIT_AVAILABLE_HCONF1  \n"); 
  }
    if ( (phconf->hconf1 & BIT1_HOME_AVAILABLE_HCONF1 )== BIT1_HOME_AVAILABLE_HCONF1)
  {
   printf(" BIT1_HOME_AVAILABLE_HCONF1  \n"); 
  }
    if ( (phconf->hconf1 & BIT2_HOME_AVAILABLE_HCONF1) == BIT2_HOME_AVAILABLE_HCONF1)
  {
   printf(" BIT2_HOME_AVAILABLE_HCONF1  \n"); 
  }
    if ( (phconf->hconf1 & BIT3_HOME_AVAILABLE_HCONF1) == BIT3_HOME_AVAILABLE_HCONF1)
  {
   printf(" BIT3_HOME_AVAILABLE_HCONF1  \n"); 
  }
    if ( (phconf->hconf1 & BIT4_HOME_AVAILABLE_HCONF1) == BIT4_HOME_AVAILABLE_HCONF1)
  {
   printf(" BIT4_HOME_AVAILABLE_HCONF1  \n"); 
  } 
  printf("phconf->hconf1 is 0x%x\n",phconf->hconf1); 
 
}
void print_ee_Hconf2(HCONF* phconf)
{
  
  if ( ( phconf->hconf2 & ENCODER_A_HIGH_HCONF2) == ENCODER_A_HIGH_HCONF2){
   printf(" ENCODER_A is high effetive \n"); 
  }
  else{
   printf(" ENCODER_A is Low effetive \n"); 
  }
  
  if ( ( phconf->hconf2 & ENCODER_B_HIGH_HCONF2) == ENCODER_B_HIGH_HCONF2){
   printf(" ENCODER_B is high effetive \n"); 
  }
  else{
   printf(" ENCODER_B is Low effetive \n"); 
  }

  if ( ( phconf->hconf2 & ENCODER_Z_HIGH_HCONF2) == ENCODER_Z_HIGH_HCONF2){
   printf(" ENCODER_Z is high effetive \n"); 
  }
  else{
   printf(" ENCODER_Z is Low effetive \n"); 
  }

  if ( ( phconf->hconf2 & HOME_HIGH_HCONF2) == HOME_HIGH_HCONF2){
   printf(" ENCODER_HOME is high effetive \n"); 
  }
  else{
   printf(" ENCODER_HOME is Low effetive \n"); 
  }

  if ( ( phconf->hconf2 & INDEX_HIGH_HCONF2) == INDEX_HIGH_HCONF2){
   printf(" ENCODER_INDEX is high effetive \n"); 
  }
  else{
   printf(" ENCODER_INDEX is Low effetive \n"); 
  }
  if ( ( phconf->hconf2 & LOW_LIMITIATION_HCONF2) == LOW_LIMITIATION_HCONF2){
   printf(" LOW_LIMITIATION is high effetive \n"); 
  }
  else{
   printf(" LOW_LIMITIATION_HCONF2 is Low effetive \n"); 
  }

  if ( ( phconf->hconf2 & UP_LIMITIATION_HCONF2) == UP_LIMITIATION_HCONF2){
   printf(" UP_LIMITIATION_HCONF2 is high effetive \n"); 
  }
  else{
   printf(" UP_LIMITIATION_HCONF2 is Low effetive \n"); 
  }

  if ( ( phconf->hconf2 & COLLISION_HIGH_HCONF2) == COLLISION_HIGH_HCONF2){
   printf(" COLLISION_HIGH_HCONF2 is high effetive \n"); 
  }
  else{
   printf(" COLLISION_HIGH_HCONF2 is Low effetive \n"); 
  }

  if ( ( phconf->hconf2 & INPUTENABLE_HIGH_HCONF2) == INPUTENABLE_HIGH_HCONF2){
   printf(" INPUTENABLE_HIGH_HCONF2 is high effetive \n"); 
  }
  else{
   printf(" INPUTENABLE_HIGH_HCONF2 is Low effetive \n"); 
  }

  if ( ( phconf->hconf2 & OUTPUTENABLE_HIGH_HCONF2 )== OUTPUTENABLE_HIGH_HCONF2){
   printf(" OUTPUTENABLE_HIGH_HCONF2 is high effetive \n"); 
  }
  else{
   printf(" OUTPUTENABLE_HIGH_HCONF2 is Low effetive \n"); 
  } 
  if ( ( phconf->hconf2 & MOTOR_DIRECTION_HIGH_HCONF2 )== MOTOR_DIRECTION_HIGH_HCONF2){
   printf(" MOTOR_DIRECTION_HIGH_HCONF2 is high effetive \n"); 
  }
  else{
   printf(" MOTOR_DIRECTION_HIGH_HCONF2 is Low effetive \n"); 
  } 
   if ( ( phconf->hconf2 & LIMITATION_DIRECTION_HCONF2 )== LIMITATION_DIRECTION_HCONF2){
   printf(" LIMITATION_DIRECTION_HCONF2 is high effetive \n"); 
  }
  else{
   printf(" LIMITATION_DIRECTION_HCONF2 is Low effetive \n"); 
  }  
   if ( ( phconf->hconf2 & INITIAL_DIRECTION_HCONF2) == INITIAL_DIRECTION_HCONF2){
   printf(" INITIAL_DIRECTION_HCONF2 is high effetive \n"); 
  }
  else{
   printf(" INITIAL_DIRECTION_HCONF2 is Low effetive \n"); 
  }  
   if ( ( phconf->hconf2 & RESERVED_HCONF2 )== RESERVED_HCONF2){
   printf(" RESERVED_HCONF2 is high effetive \n"); 
  }
  else{
   printf(" RESERVED_HCONF2 is Low effetive \n"); 
  }  
  if ( ( phconf->hconf2 & INITIAL_AUTORUN_HCONF2) == INITIAL_AUTORUN_HCONF2){
   printf(" INITIAL_AUTORUN_HCONF2 is high effetive \n"); 
  }
  else{
   printf(" INITIAL_AUTORUN_HCONF2 is Low effetive \n"); 
  } 
  printf("phconf->hconf2 is 0x%x\n",phconf->hconf2); 
}

//�ϵ�����һ�Ρ�
//���ƣ�ͬһʱ�̣���Ӧ��STATE_EEPROM_PAGES_FOR_ONE_MOTOR�У�ֻ��һҳ��Ч
//�ҵ��󣬱��Ϊ��ǰ��pageOffSet_StateInEEPROM
//�����ṫ��һ����������Ϊ���������ͬʱ��ȡ��
//��Ϊһ��Ҳ����16ҳ���Ȳ��ñ���������������������
uint8_t EEPROM_find_page_offset_state(uint16_t* pageOffSet_StateInEEPROM )
{
   uint8_t  i = 0,temp = 0;
   uint16_t ReadPageStartAdd = 0;
   uint8_t  find = 0;
   for( i = 0; i < STATE_EEPROM_PAGES_FOR_ONE_MOTOR + 1; i++) {
     //��һ�����MOTOTR,����HEAD,�ж��Ƿ�Ϊ HEAD_IN_EEPROM
     ReadPageStartAdd =  (uint16_t)(BASE_STATE_EEPROM_ADDRESS_MOTOR1 + i*EEPROM_PAGESIZE*PAGES_PER_STATE);
	 ee_ReadBytes(&temp, ReadPageStartAdd, 1); 
    if( ((uint8_t)HEAD_IN_EEPROM) == temp) {
      *pageOffSet_StateInEEPROM = i;
			find =1;		
      #ifdef UART_DEBUG_STP
      printf("pageOffSet_StateInEEPROM is %d !\n",*pageOffSet_StateInEEPROM);  
      #endif
      return 1;
    }
   }
   if(find == 0){
     *pageOffSet_StateInEEPROM = 0;
      
      #ifdef UART_DEBUG_STP
      printf("pageOffSet_StateInEEPROM is %d !\n",*pageOffSet_StateInEEPROM);  
      #endif
   }
   return 1;
}

uint8_t TEST_ONLY_EEPROM_find_page_offset_state(uint16_t* pageToWriteHead )
{
  
  uint8_t  temp = 0x00;

  ee_WriteBytes( &temp, BASE_STATE_EEPROM_ADDRESS_MOTOR1 + pageOffSet_StateInEEPROM*EEPROM_PAGESIZE*PAGES_PER_STATE,  1 );
  ee_WriteBytes( &temp, BASE_STATE_EEPROM_ADDRESS_MOTOR2 + pageOffSet_StateInEEPROM*EEPROM_PAGESIZE*PAGES_PER_STATE ,  1 );
  ee_WriteBytes( &temp, BASE_STATE_EEPROM_ADDRESS_MOTOR3 + pageOffSet_StateInEEPROM*EEPROM_PAGESIZE*PAGES_PER_STATE ,  1 );
  
  temp = HEAD_IN_EEPROM;
  ee_WriteBytes( &temp, BASE_STATE_EEPROM_ADDRESS_MOTOR1 + (*pageToWriteHead)*EEPROM_PAGESIZE*PAGES_PER_STATE ,  1 );
  ee_WriteBytes( &temp, BASE_STATE_EEPROM_ADDRESS_MOTOR2 + (*pageToWriteHead) *EEPROM_PAGESIZE*PAGES_PER_STATE,  1 );
  ee_WriteBytes( &temp, BASE_STATE_EEPROM_ADDRESS_MOTOR3 + (*pageToWriteHead) *EEPROM_PAGESIZE*PAGES_PER_STATE,  1 );
  
  #ifdef UART_DEBUG_STP
   printf("pageToWriteHead is %d !\n",*pageToWriteHead);  
  #endif

  return 1;
}
uint8_t TEST_ONLY_EEPROM_CLEAR_page_offset_state(void )
{
  
  uint8_t temp = 0x00;
	uint8_t i = 0,j = 0;
	for(i = 0; i < MOTOR_IN_USE; i ++){
		for( j = 0; j < STATE_EEPROM_PAGES_FOR_ONE_MOTOR; j ++){
		ee_WriteBytes( &temp, BASE_STATE_EEPROM_ADDRESS_MOTOR1 + j*EEPROM_PAGESIZE*PAGES_PER_STATE ,   1 );
		ee_WriteBytes( &temp, BASE_STATE_EEPROM_ADDRESS_MOTOR2 + j*EEPROM_PAGESIZE*PAGES_PER_STATE  ,  1 );
		ee_WriteBytes( &temp, BASE_STATE_EEPROM_ADDRESS_MOTOR3 + j*EEPROM_PAGESIZE*PAGES_PER_STATE  ,  1 );
	  }
	}
	pageOffSet_StateInEEPROM = 0;
  #ifdef UART_DEBUG_STP
   printf("pageToWriteHead is cleared.  %d !\n",pageOffSet_StateInEEPROM);  
  #endif

  return 1;
}
//��ȡ��ʱ�򣬵������Σ��ֱ�������ṹ��
uint16_t nBytesToWrite = (uint16_t)( sizeof(State_mini_paras_STEP) + 1 + sizeof(float) );
//uint16_t nBytesToWrite = (uint16_t)( sizeof(State_mini_paras_STEP) + 1 );


uint8_t EEPROM_Read_state(uint16_t* pageOffSet_StateInEEPROM,uint8_t MotorChannel, _EEPROM_STATE_STEP* stateStruct )
{
  uint8_t* pBuffer = (uint8_t*)stateStruct ;
  uint8_t status =0;
  uint16_t readStartAdd = 0;
  uint16_t k_forDelay = 0;
  switch (MotorChannel){
  case 0:
      readStartAdd = (uint16_t)(BASE_STATE_EEPROM_ADDRESS_MOTOR1 + (*pageOffSet_StateInEEPROM)*EEPROM_PAGESIZE*PAGES_PER_STATE) ;
    break;
  case 1:
      readStartAdd = (uint16_t)(BASE_STATE_EEPROM_ADDRESS_MOTOR2 + (*pageOffSet_StateInEEPROM)*EEPROM_PAGESIZE*PAGES_PER_STATE) ;
    break;
  case 2:
      readStartAdd = (uint16_t)(BASE_STATE_EEPROM_ADDRESS_MOTOR3 + (*pageOffSet_StateInEEPROM)*EEPROM_PAGESIZE*PAGES_PER_STATE);
    break;  
  default:
    break;
  }
  status =  ee_ReadBytes(pBuffer, readStartAdd,  nBytesToWrite );
  for(k_forDelay = 0; k_forDelay< 10000; k_forDelay++);

  return status;     
}
uint8_t EEPROM_Write_state_1(void )
{
  uint8_t   tempOffset = 0;
  uint8_t* pBuffer ;
  uint8_t  u8_temp0x00 = 0x00 ;
  uint8_t  status = 0;
  uint16_t nBytesToWrite = 0;
  uint16_t writeAddress = 0;

  int i;
  int checkStatus = 0;
  if (pageOffSet_StateInEEPROM == STATE_EEPROM_PAGES_FOR_ONE_MOTOR)
    tempOffset = 0;
  else
    tempOffset = pageOffSet_StateInEEPROM + 1;
  
  nBytesToWrite = (uint16_t)( sizeof(State_mini_paras_STEP) + 1 );
/*
  #ifdef UART_DEBUG_STP
  printf("pageOffSet_StateInEEPROM is %d \n",pageOffSet_StateInEEPROM);  
  printf("nBytesToWrite is %d \n",nBytesToWrite); 
  #endif
*/
//	__disable_irq();
  writeAddress =(uint16_t)(BASE_STATE_EEPROM_ADDRESS_MOTOR1 + tempOffset*EEPROM_PAGESIZE*PAGES_PER_STATE) ;
  memcpy( (void*)&tempArray[0],(void*)&state_motor_struct[0], nBytesToWrite);
  ee_WriteBytes(tempArray,   writeAddress, nBytesToWrite );
  //ee_Delay(0x01FFFFFFF);
 // memset(I2c_Buf_Read,0,nBytesToWrite);
  //for (i = 0; i < nBytesToWrite; i ++);//nop
  ee_Delay(0x0FF);
  ee_ReadBytes(I2c_Buf_Read, writeAddress, nBytesToWrite); 
  for (i = 0; i < nBytesToWrite; i ++){	
      if(I2c_Buf_Read[i] != tempArray[i]) {
         checkStatus = 1;
         #ifdef UART_DEBUG_STP
         printf("error at 0: %d \n",i);  
         #endif
	     break;
      }
  } 
  while( 1 == checkStatus){
       checkStatus = 0;
       memcpy( (void*)&tempArray[0],(void*)&state_motor_struct[0], nBytesToWrite);
       ee_WriteBytes(tempArray,   writeAddress, nBytesToWrite );
       for (i = 0; i < nBytesToWrite; i ++);//nop
	   memset(I2c_Buf_Read,0,nBytesToWrite);
       ee_Delay(0x0FFFFF);
	   ee_ReadBytes(I2c_Buf_Read, writeAddress, nBytesToWrite);
       for (i = 0; i < nBytesToWrite; i ++){	
               if(I2c_Buf_Read[i] != tempArray[i]) {
                  checkStatus = 1;
                  #ifdef UART_DEBUG_STP
                    printf("error at 0: %d \n",i); 
                    printf("I2c_Buf_Read[i]: %d \n",I2c_Buf_Read[i]); 
                    printf("pBuffer[i]: %d \n",pBuffer[i]);                  
                  #endif
			    break;
               }   
       }
  }

  writeAddress =(uint16_t)(BASE_STATE_EEPROM_ADDRESS_MOTOR2 + tempOffset*EEPROM_PAGESIZE*PAGES_PER_STATE);
  memcpy( (void*)&tempArray[0],(void*)&state_motor_struct[1], nBytesToWrite);
  ee_WriteBytes(tempArray ,  writeAddress, nBytesToWrite );
 // memset(I2c_Buf_Read,0,nBytesToWrite);
  for (i = 0; i < nBytesToWrite; i ++);//nop
  ee_Delay(0x0FFFFF);
  ee_ReadBytes(I2c_Buf_Read, writeAddress, nBytesToWrite); 
  for (i = 0; i < nBytesToWrite; i ++){	
      if(I2c_Buf_Read[i] != tempArray[i]) {
          checkStatus = 1;
         #ifdef UART_DEBUG_STP
         printf("error at 1: %d \n",i);  
         #endif    
         break;				
      }
} 
  while( 1 == checkStatus){
       checkStatus = 0;
       memcpy( (void*)&tempArray[0],(void*)&state_motor_struct[1], nBytesToWrite);
       ee_WriteBytes(tempArray , writeAddress,  nBytesToWrite );
       memset(I2c_Buf_Read,0,nBytesToWrite);
       for (i = 0; i < nBytesToWrite; i ++);//nop
  ee_Delay(0x0FFFFF);
	   ee_ReadBytes(I2c_Buf_Read, writeAddress, nBytesToWrite); 
       for (i = 0; i < nBytesToWrite; i ++){	
            if(I2c_Buf_Read[i] != tempArray[i]) {
              checkStatus = 1;
              #ifdef UART_DEBUG_STP
              printf("error at 1: %d \n",i);  
              #endif   
              break;						 
            }
        } 
       
  }

/*
//  writeAddress =(uint16_t)( BASE_STATE_EEPROM_ADDRESS_MOTOR3 + tempOffset*EEPROM_PAGESIZE*PAGES_PER_STATE);   
  writeAddress =(uint16_t)(BASE_STATE_EEPROM_ADDRESS_MOTOR2 + tempOffset*EEPROM_PAGESIZE*PAGES_PER_STATE);
  memcpy( (void*)&tempArray[0],(void*)&state_motor_struct[1], nBytesToWrite);
  ee_WriteBytes(tempArray , writeAddress,  nBytesToWrite );
  memset(I2c_Buf_Read,0,nBytesToWrite);
	for (i = 0; i < nBytesToWrite; i ++);//nop
  ee_ReadBytes(I2c_Buf_Read, writeAddress, nBytesToWrite); 
  for (i = 0; i < nBytesToWrite; i ++){	
      if(I2c_Buf_Read[i] != tempArray[i]) {
          checkStatus = 1;
          #ifdef UART_DEBUG_STP
				  printf("writeAddress at 2: %d \n",writeAddress);  
         printf("error at 2: %d \n",i);  
         #endif   
         break;				
      }
    } 
  while( 1 == checkStatus){
      checkStatus = 0;
      memcpy( (void*)&tempArray[0],(void*)&state_motor_struct[1], nBytesToWrite);
      ee_WriteBytes(tempArray , writeAddress,  nBytesToWrite );
      memset(I2c_Buf_Read,0,nBytesToWrite);
	  for (i = 0; i < nBytesToWrite; i ++);//nop       
	  ee_ReadBytes(I2c_Buf_Read, writeAddress, nBytesToWrite); 
           for (i = 0; i < nBytesToWrite; i ++){	
               if(I2c_Buf_Read[i] != tempArray[i]) {
                  checkStatus = 1;
             #ifdef UART_DEBUG_STP
             printf("error at 2: %d \n",i);  
             #endif         
              break;						 
               }
           } 
  }
*/
 writeAddress =(uint16_t)(BASE_STATE_EEPROM_ADDRESS_MOTOR3 + tempOffset*EEPROM_PAGESIZE*PAGES_PER_STATE) ;
  memcpy( (void*)&tempArray[0],(void*)&state_motor_struct[2], nBytesToWrite);
  ee_WriteBytes(tempArray,   writeAddress, nBytesToWrite );
  memset(I2c_Buf_Read,0,nBytesToWrite);
  for (i = 0; i < nBytesToWrite; i ++);//nop
  ee_Delay(0x0FFFFF);

  ee_ReadBytes(I2c_Buf_Read, writeAddress, nBytesToWrite); 
  for (i = 0; i < nBytesToWrite; i ++){	
      if(I2c_Buf_Read[i] != tempArray[i]) {
         checkStatus = 1;
         #ifdef UART_DEBUG_STP
         printf("error at 0: %d \n",i);  
         #endif
	     break;
      }
  } 
  while( 1 == checkStatus){
       checkStatus = 0;
       memcpy( (void*)&tempArray[0],(void*)&state_motor_struct[2], nBytesToWrite);
       ee_WriteBytes(tempArray,   writeAddress, nBytesToWrite );
       for (i = 0; i < nBytesToWrite; i ++);//nop
	   memset(I2c_Buf_Read,0,nBytesToWrite);
       ee_Delay(0x0FFFFF);

	   ee_ReadBytes(I2c_Buf_Read, writeAddress, nBytesToWrite);
       for (i = 0; i < nBytesToWrite; i ++){	
               if(I2c_Buf_Read[i] != tempArray[i]) {
                  checkStatus = 1;
                  #ifdef UART_DEBUG_STP
                    printf("error at 0: %d \n",i); 
                    printf("I2c_Buf_Read[i]: %d \n",I2c_Buf_Read[i]); 
                    printf("pBuffer[i]: %d \n",pBuffer[i]);                  
                  #endif
			    break;
        }   
       }
  }

 // __enable_irq();
   // ��HEAD���㣬��ֻ֤��һ����ǰHEAD��Ч��
  writeAddress =(uint16_t)(BASE_STATE_EEPROM_ADDRESS_MOTOR1 + pageOffSet_StateInEEPROM*EEPROM_PAGESIZE*PAGES_PER_STATE);
  ee_WriteBytes( &u8_temp0x00, writeAddress,  1 );
  
  writeAddress =(uint16_t)(BASE_STATE_EEPROM_ADDRESS_MOTOR2 + pageOffSet_StateInEEPROM*EEPROM_PAGESIZE*PAGES_PER_STATE);
  ee_WriteBytes( &u8_temp0x00, writeAddress,  1 );

  writeAddress =(uint16_t)(BASE_STATE_EEPROM_ADDRESS_MOTOR3 + pageOffSet_StateInEEPROM*EEPROM_PAGESIZE*PAGES_PER_STATE);
  ee_WriteBytes( &u8_temp0x00, writeAddress,  1 );
  // ���� pageOffSet_StateInEEPROM
  pageOffSet_StateInEEPROM = tempOffset;
  succsessfulTime++;
  /*
  #ifdef UART_DEBUG_STP
  printf("after:state_motor_struct[2].head:%x \n",state_motor_struct[2].head);  
  printf(",after write state operation now it is  %d !\n",pageOffSet_StateInEEPROM);  
  printf("pageOffSet_StateInEEPROM:%d \n",pageOffSet_StateInEEPROM);  
  printf("writeAddress: %d !\n",writeAddress);  
  #endif */
	#ifdef UART_DEBUG_STP
         printf("%d:%d\n",succsessfulTime,pageOffSet_StateInEEPROM);  
  #endif  
  return status;     
}

//�ϵ��ʼ���˺�����
uint8_t initial_state_motor_struct(void)
{
//3����
//��һ����Ѱ�ҵ�ǰpage offset
//�ڶ�������ȡ�����ݣ��������û��ͷ��������У���������д��Ĭ��ֵ��
//����������Ĭ��ֵ��������������Խṹ�壬ͬʱ��Ĭ��ֵд��EEPROM.
  uint8_t i = 0;
  uint8_t checkState = 0;
//  uint8_t u8_tryTimes ;
  //��һ��
  EEPROM_find_page_offset_state(&pageOffSet_StateInEEPROM);
  //�������ݣ����ͷ�����ԣ���ֱ����ת��������
    for( i = 0 ; i < MOTOR_IN_USE; i ++ ) {
      EEPROM_Read_state( &pageOffSet_StateInEEPROM, i , &state_motor_struct[i]);
      printf("state_motor_struct[%d].head,%x. \n", i ,state_motor_struct[i].head);     
      if( ((uint8_t)HEAD_IN_EEPROM) != state_motor_struct[i].head){ 
        checkState = 1;
      }
    }

  for(i = 0; i < MOTOR_IN_USE; i ++){
      state_motor_struct[i].state_struct.stateMachine                 = STEP_STOP;
      state_motor_struct[i].state_struct.scanMode_Shadow              = 0;
      state_motor_struct[i].state_struct.scanTime_2_wait_ms_shadow    = 0;    
  }
  //���ͨ��У�飬�����溯���岻ִ��
  if( 1== checkState ){
    #ifdef UART_DEBUG_STP
    printf("ALL EMPTY! \n");  
    #endif
    for(i = 0; i < MOTOR_IN_USE; i ++){
      //��д��Ĭ��ֵ
      state_motor_struct[i].head = (uint8_t)HEAD_IN_EEPROM;
      state_motor_struct[i].state_struct.miniState.state                = 0x0000;
      state_motor_struct[i].state_struct.miniState.valueSet             = 0.0;
      state_motor_struct[i].state_struct.miniState.valueActual          = 0.0;
      state_motor_struct[i].state_struct.miniState.valueEncoder         = 0x00000000;
      state_motor_struct[i].state_struct.miniState.speedSet             = 0.0;
      state_motor_struct[i].state_struct.miniState.speedActual          = 0.0;
      state_motor_struct[i].state_struct.miniState.homeDistance         = 0.0;
      state_motor_struct[i].state_struct.miniState.homeValueApproximate = 0;
      //�����Ǹ���״̬������Ҫ�ϴ���
      state_motor_struct[i].state_struct.valueTriggeredorNot  = 0;
      state_motor_struct[i].state_struct.slaveChanel          = 0;
      state_motor_struct[i].state_struct.countInPWM_IRQ       = 0;
      state_motor_struct[i].state_struct.scanMode             = 0;
      state_motor_struct[i].state_struct.scanTime_2_wait_ms   = 0; 
      state_motor_struct[i].state_struct.wait_or_not          = 0;
      state_motor_struct[i].state_struct.enable_or_not        = 0;
      state_motor_struct[i].state_struct.pulse_out_or_not     = 0;
      state_motor_struct[i].state_struct.scan_start           = 0;
      state_motor_struct[i].state_struct.scan_stop                 = 0;
      state_motor_struct[i].state_struct.scan_step                 = 0;
      state_motor_struct[i].state_struct.scan_velosity             = 0;
      state_motor_struct[i].state_struct.stateMachine              = 0;
      state_motor_struct[i].state_struct.scanMode_Shadow           = 0;
      state_motor_struct[i].state_struct.scanTime_2_wait_ms_shadow = 0;
      state_motor_struct[i].state_struct.enable_triggered          = 0;
      state_motor_struct[i].state_struct.homeUsed                  = 0;
      state_motor_struct[i].state_struct.f_Start_homedistance      = 0;
      state_motor_struct[i].state_struct.u8_direction_down         = 0;
      state_motor_struct[i].state_struct.u8_direction_up           = 0;
      state_motor_struct[i].state_struct.f_valueActual_test        = 0;

    }
    EEPROM_Write_state();
  }

/*  #ifdef UART_DEBUG_STP
  print_ee_state();
  #endif  */
  return 0;
}


#ifdef UART_DEBUG_STP
void print_ee_state(void)
{ 
  uint8_t i = 0;
  for(i = 0; i < MOTOR_IN_USE; i ++)
  {
   printf(" motor %d 's state.head          is  0x%x\n",i,state_motor_struct[i].head); 
   printf(" motor %d 's state               is  0x%x\n",i,state_motor_struct[i].state_struct.miniState.state); 
   printf(" motor %d 's valueSet            is  %f\n",i,state_motor_struct[i].state_struct.miniState.valueSet); 
   printf(" motor %d 's valueActual         is  %f\n",i,state_motor_struct[i].state_struct.miniState.valueActual); 
   printf(" motor %d 's valueEncoder        is  %d\n",i,state_motor_struct[i].state_struct.miniState.valueEncoder); 
   printf(" motor %d 's speedSet            is  %f\n",i,state_motor_struct[i].state_struct.miniState.speedSet); 
   printf(" motor %d 's speedActual         is  %f\n",i,state_motor_struct[i].state_struct.miniState.speedActual); 
   printf(" motor %d 's homeDistance        is  %f\n",i,state_motor_struct[i].state_struct.miniState.homeDistance); 
   printf(" motor %d 's homeValueApproximat is  %d\n",i,state_motor_struct[i].state_struct.miniState.homeValueApproximate); 
 
   printf(" motor %d 's valueTriggeredorNot is  %d\n",i,state_motor_struct[i].state_struct.valueTriggeredorNot); 
   printf(" motor %d 's slaveChanel         is  %d\n",i,state_motor_struct[i].state_struct.slaveChanel); 
   printf(" motor %d 's countInPWM_IRQ      is  %llu\n",i,state_motor_struct[i].state_struct.countInPWM_IRQ); 
   printf(" motor %d 's scanMode            is  %d\n",i,state_motor_struct[i].state_struct.scanMode); 
   printf(" motor %d 's scanTime_2_wait_ms  is  %d\n",i,state_motor_struct[i].state_struct.scanTime_2_wait_ms); 
   printf(" motor %d 's wait_or_not         is  %d\n",i,state_motor_struct[i].state_struct.wait_or_not); 
   printf(" motor %d 's enable_or_not       is  %d\n",i,state_motor_struct[i].state_struct.enable_or_not); 
   printf(" motor %d 's stateMachine        is  %d\n",i,state_motor_struct[i].state_struct.stateMachine); 
   printf(" motor %d 's homeUsed            is  %f\n",i,state_motor_struct[i].state_struct.homeUsed); 
   printf(" --------------------------------------\n"); 
  }
}
void print_ee_miniState_Motor(uint8_t port)
{ 
  uint8_t i = port;
  uint16_t state = state_motor_struct[i].state_struct.miniState.state;
  if(STATE_HOME_OR_NOT == (STATE_HOME_OR_NOT & state))
    printf("home:T \n"); 
  else
    printf("home:F \n"); 

  if(STATE_APPRO_HOME_OR_NOT == (STATE_APPRO_HOME_OR_NOT & state))
    printf("apprhome:T \n"); 
  else
    printf("apprhome:F \n"); 

  if(STATE_IDLE_OR_NOT == (STATE_IDLE_OR_NOT & state))
    printf("iddle:T \n"); 
  else
    printf("iddle:F \n"); 
  
  if(STATE_RUN_OR_NOT == (STATE_RUN_OR_NOT & state))
    printf("run:T \n"); 
  else
    printf("run:F \n"); 

  if(STATE_LOCK_OR_NOT == (STATE_LOCK_OR_NOT & state))
    printf("lock:T \n"); 
  else
    printf("lock:F \n"); 

  if(STATE_UPPER_OR_NOT == (STATE_UPPER_OR_NOT & state))
    printf("up:T \n"); 
  else
    printf("up:F \n"); 
  
  if(STATE_LOWER_OR_NOT == (STATE_LOWER_OR_NOT & state))
    printf("low:T \n"); 
  else
    printf("low:F \n"); 
  
  if(STATE_COLLISION_OR_NOT == (STATE_COLLISION_OR_NOT & state))
    printf("col:T \n"); 
  else
    printf("col:F \n"); 
  
  if(STATE_POS_WRONG_OR_NOT == (STATE_POS_WRONG_OR_NOT & state))
    printf("pos wrong:T \n"); 
  else
    printf("pos wrong:F \n"); 
  
  if(STATE_OVER_CURRENT_OR_NOT == (STATE_OVER_CURRENT_OR_NOT & state))
    printf("over C:T \n"); 
  else
    printf("over C:F \n"); 
  
  if(STATE_WAIT_OR_NOT == (STATE_WAIT_OR_NOT & state))
    printf("wait:T \n"); 
  else
    printf("wait:F \n"); 
  
  if(STATE_ENAB_OR_NOT == (STATE_ENAB_OR_NOT & state))
    printf("enab:T \n"); 
  else
    printf("enab:F \n"); 

  if(STATE_ROTATION_OR_NOT == (STATE_ROTATION_OR_NOT & state))
    printf("rotaion:T \n"); 
  else
    printf("rotaion:F \n"); 
}
#endif

uint32_t I2C_EE_ReadAllConfigFiles(void)
{
  uint8_t i = 0;
  for(i = 0; i < MOTOR_IN_USE; i++)
  I2C_EE_ReadConfigFiles(i,&ee_conFile[i]);
	
	return 0;
}
void writeDefaultConfile2EEprom(void)
{
    int i = 0, j = 0;
    char c_tempMotorName[MOTORNAME_LEN]= {'m','o','t','o','r','1'};
    for(i = 0; i < MOTOR_IN_USE; i ++)
    {
      //��д��Ĭ��ֵ
      ee_conFile[i].head              = HEAD_IN_EEPROM;
      ee_conFile[i].motorindex        = i;
     for(j = 0; j < 5; j++)
     {
      ee_conFile[i].motorName[j]      = c_tempMotorName[j];
     }
      ee_conFile[i].motorName[j]      = 0x30 + i;	 
      ee_conFile[i].this_HCONF.hconf1 = 0;
      ee_conFile[i].this_HCONF.hconf2 = 0;
      ee_conFile[i].this_HCONF.hconf2 = 0;
      ee_conFile[i].motorType         = 0x01;
      ee_conFile[i].current           = 1.0;
      ee_conFile[i].currentBias       = 50;
      ee_conFile[i].fullStep          = 200;
      ee_conFile[i].gearRatio         = 1;
      ee_conFile[i].home              = 0.0;
      ee_conFile[i].upperLimitation   = 0.0;
      ee_conFile[i].lowerLimitation   = 0.0;
      ee_conFile[i].resolution        = 0.001;
      ee_conFile[i].maxSpeedFast      = 0.0;
      ee_conFile[i].minSpeedSlow      = 0.0;
      ee_conFile[i].accelerationTime  = 0.0;
      ee_conFile[i].encoderCounts     = 2000;
      ee_conFile[i].backlash          = 0.0;
      ee_conFile[i].positionError     = 0.0;
      ee_conFile[i].DCBiasCurrent     = 0.0;
      ee_conFile[i].DCOpenCurrentHigh = 0.0;
      ee_conFile[i].DCOpenCurrentLow  = 0.0;
      ee_conFile[i].rotationAvailable = 0;
      ee_conFile[i].posKp             = 0.0;
      ee_conFile[i].posKi             = 0.0;
      ee_conFile[i].velForwardFeed    = 0.0;
      ee_conFile[i].posKiLimit        = 0.0;
      ee_conFile[i].microStep         = 256;
      I2C_EE_WriteConfigFiles( i, &ee_conFile[i]);
    }
}
uint8_t initial_step_motor(uint8_t port)
{
  float homeUsedLastOperation = 0.0;
  float f_diff =0.0;

  if(port < MOTOR_IN_USE){
    step_motor[port].this_state                            = &state_motor_struct[port].state_struct;
    step_motor[port].this_state->enable_triggered          = 0;
	  step_motor[port].this_state->scanMode_Shadow           = 0;
	  step_motor[port].this_state->scanTime_2_wait_ms_shadow = 0;
    // to check whether the homeused and ee.home are equal.That is to say before power down
    // the system may use a temporary homevalue for operating.
    homeUsedLastOperation = state_motor_struct[port].state_struct.homeUsed; 
    f_diff = ee_conFile[port].home - homeUsedLastOperation ;
    #ifdef UART_DEBUG_STP
      printf("homeUsedLastOperation %d :%f. \n",(int)port,homeUsedLastOperation);
    #endif  
    if(fabs(f_diff) >= ee_conFile[port].resolution ){
        state_motor_struct[port].state_struct.miniState.valueActual += f_diff; 
    }
    actualValue_encoderAlignment(port);

    //
    step_motor[port].this_state->homeUsed                  = ee_conFile[port].home;
     
    step_motor[port].this_state->valueTriggeredorNot  = 0;
    step_motor[port].this_state->slaveChanel          = 0;
    step_motor[port].this_state->countInPWM_IRQ       = 0;
    step_motor[port].this_state->scanMode             = 0;
    step_motor[port].this_state->scanTime_2_wait_ms   = 0; 
    step_motor[port].this_state->wait_or_not          = 0;
    step_motor[port].this_state->enable_or_not        = 0;
    step_motor[port].this_state->stateMachine         = STEP_STOP;
    step_motor[port].this_state->f_valueActual_test   = 0.0;
  
    step_motor[port].slave_state                      = NULL;

    step_motor[port].limP_pin_interrupt               = 0;
    step_motor[port].limN_pin_interrupt               = 0;
    step_motor[port].home_pin_interrupt               = 0;
    step_motor[port].index_pin_interrupt              = 0;
    step_motor[port].collision_pin_interrupt          = 0;

    stepper_Stop(step_motor[port].pul_channel); 
		
		motor_Home_Sig_Sturct[port].homeMode     = 0;
    motor_Home_Sig_Sturct[port].pu16_signal1 = NULL;
    motor_Home_Sig_Sturct[port].pu16_signal2 = NULL;
    motor_Home_Sig_Sturct[port].sig1_level   = 0;
    motor_Home_Sig_Sturct[port].sig2_level   = 0;
		motor_Home_Sig_Sturct[port].f_value_1    = 0.0;
		motor_Home_Sig_Sturct[port].f_value_2    = 0.0;
    motor_Home_Sig_Sturct[port].direction    = 0;
    stop_state(port);
    if(1 == ee_conFile[port].rotationAvailable){// if rotationAvailable==1,then upperLimitation = lowerLimitation = 0
     if( ee_conFile[port].upperLimitation == ee_conFile[port].lowerLimitation ){
        // this condition is all rgiht.
     }else{
      //this is not right.
      state_motor_struct[port].state_struct.miniState.state |= STATE_ROTATION_WRONG_bit0;
     }
    }
    getHomeMode_fill_HOME_STRUCT(port);
    #ifdef UART_DEBUG_STP
      printf("motor %d is initialed. \n",(int)port);
    #endif  
    return 1; 
  }// end of   if(port < MOTOR_IN_USE){
  else{
    return 0;
  }
}

uint8_t initial_step_motor_All(void)
{
  uint8_t i = 0;
  for(i = 0; i < MOTOR_IN_USE; i ++){
    initial_step_motor(i);
  }
  return 0;   
}

void disPlayHome_status_variables(uint8_t port)
{
  uint16_t homeAvailable = 0;
  uint16_t limit_As_Home = 0;
  homeAvailable = BIT1_HOME_AVAILABLE_HCONF1|
                  BIT2_HOME_AVAILABLE_HCONF1|
                  BIT3_HOME_AVAILABLE_HCONF1|
                  BIT4_HOME_AVAILABLE_HCONF1;
  limit_As_Home = LOW_AS_HOME_AVAILABLE_HCONF1|
                  UP_AS_HOME_AVAILABLE_HCONF1;

  #ifdef UART_DEBUG_STP
  getHomeMode_fill_HOME_STRUCT(port);
  disPlayHOME_SIGNALS_STRUCT(port);
  if((ee_conFile[port].this_HCONF.hconf1 & homeAvailable) != 0){
    printf("Home Signal Exists.");
  }
  if((ee_conFile[port].this_HCONF.hconf1 & limit_As_Home) != 0){
    if(LOW_AS_HOME_AVAILABLE_HCONF1 == (ee_conFile[port].this_HCONF.hconf1 & LOW_AS_HOME_AVAILABLE_HCONF1))
      printf("Low as Home.\n");
    if(UP_AS_HOME_AVAILABLE_HCONF1 == (ee_conFile[port].this_HCONF.hconf1 & UP_AS_HOME_AVAILABLE_HCONF1) )
      printf("up  as Home.\n");
  }
  print_ee_miniState_Motor(port);
  printf("--------------------------------------------------------------------------------------------------\n");
  #endif  
}
void actualValue_encoderAlignment(uint8_t port)
{
  //
  if( ENCODER_AVAILABLE_HCONF1 == ( ENCODER_AVAILABLE_HCONF1 & ee_conFile[port].this_HCONF.hconf1)){// if encoder exsits
    state_motor_struct[port].state_struct.miniState.valueEncoder =(int)(state_motor_struct[port].state_struct.miniState.valueActual*ee_conFile[port].encoderCounts);
  }
}

void writeStatusOneChannel(uint8_t port, uint16_t byte2Write,uint16_t tempoffset)
{
  uint8_t   tempOffset = tempoffset;
  uint8_t  u8_temp0x00 = 0x00 ;
  uint16_t nBytesToWrite = byte2Write;
  uint16_t writeAddress = 0;
  uint16_t writeAddress0x00 = 0;

  switch (port){
  case 0:
      writeAddress     = (uint16_t)(BASE_STATE_EEPROM_ADDRESS_MOTOR1 + (tempOffset)*EEPROM_PAGESIZE*PAGES_PER_STATE) ;
      writeAddress0x00 = (uint16_t)(BASE_STATE_EEPROM_ADDRESS_MOTOR1 + pageOffSet_StateInEEPROM*EEPROM_PAGESIZE*PAGES_PER_STATE);
      memcpy( (void*)&tempArray[0],(void*)&state_motor_struct[0], nBytesToWrite);
    break;
  case 1:
      writeAddress     = (uint16_t)(BASE_STATE_EEPROM_ADDRESS_MOTOR2 + (tempOffset)*EEPROM_PAGESIZE*PAGES_PER_STATE) ;
      writeAddress0x00 = (uint16_t)(BASE_STATE_EEPROM_ADDRESS_MOTOR2 + pageOffSet_StateInEEPROM*EEPROM_PAGESIZE*PAGES_PER_STATE) ;    
      memcpy( (void*)&tempArray[0],(void*)&state_motor_struct[1], nBytesToWrite);
    break;
  case 2:
      writeAddress     = (uint16_t)(BASE_STATE_EEPROM_ADDRESS_MOTOR3 + (tempOffset)*EEPROM_PAGESIZE*PAGES_PER_STATE);
      writeAddress0x00 = (uint16_t)(BASE_STATE_EEPROM_ADDRESS_MOTOR3 + pageOffSet_StateInEEPROM*EEPROM_PAGESIZE*PAGES_PER_STATE) ;     
      memcpy( (void*)&tempArray[0],(void*)&state_motor_struct[2], nBytesToWrite);
    break;  
  default:
    break;
  }

  ee_WriteBytes(tempArray, writeAddress, nBytesToWrite );
  ee_WriteBytes( &u8_temp0x00, writeAddress0x00,  1 );

}
uint8_t EEPROM_Write_state(void )
{
  uint8_t i              = 0; 
  uint16_t tempOffset    = 0;
  
  if (pageOffSet_StateInEEPROM == STATE_EEPROM_PAGES_FOR_ONE_MOTOR)
    tempOffset = 0;
  else
    tempOffset = pageOffSet_StateInEEPROM + 1;

  for( i = 0; i < MOTOR_IN_USE; i ++){
     writeStatusOneChannel(i,nBytesToWrite,tempOffset);
  }

  succsessfulTime++;
	/*#ifdef UART_DEBUG_STP
         printf("%d:%d\n",succsessfulTime,pageOffSet_StateInEEPROM);  
  #endif
  */  
  pageOffSet_StateInEEPROM = tempOffset;

  return 0;
}
/*********************************************END OF FILE**********************/



