#ifndef __I2C_EE_H
#define	__I2C_EE_H


#include "stm32h7xx.h"
#include "./stepper/bsp_scan.h"
#include "./stepper/bsp_stepper_init.h"




#define EEPROM_ADDRESS        0xA2
#define EEPROM_DEV_ADDR			  EEPROM_ADDRESS		// 24xx128���豸��ַ 
#define EEPROM_PAGE_SIZE		  64		// 24xx128��ҳ���С 
#define EEPROM_SIZE				    256*64    // 24xx128������ 


// AT24C128ÿҳ��64���ֽ� 
#define EEPROM_PAGESIZE           64
#define I2C_OWN_ADDRESS7      0X0A   // �����ַֻҪ��STM32��ҵ�I2C������ַ��һ������ 



#define MOTORNAME_LEN        16
//���������صĽṹ��
typedef struct {
  unsigned char head ;
  unsigned char motorindex;
  char          motorName[MOTORNAME_LEN];
  HCONF         this_HCONF;//����3��hconf
  unsigned char motorType : MOTORTYE_STEP;
  float          current;
  unsigned char currentBias;
  unsigned int  fullStep;
  unsigned int  gearRatio;
  float         home;
  float         upperLimitation;
  float         lowerLimitation;
  float         resolution;
  float         maxSpeedFast;
  float         minSpeedSlow;
  float         accelerationTime;
  unsigned int  encoderCounts;
  float         backlash;
  float         positionError;
  float         DCBiasCurrent;
  float         DCOpenCurrentHigh;
  float         DCOpenCurrentLow;
  unsigned char rotationAvailable;
  float         posKp;
  float         posKi;
  float         posKd;
  float         velForwardFeed;
  float         posKiLimit;
  unsigned int  microStep;
}__attribute__((packed)) _EEPROM_CONF_STEP;//�洢��EEPROM�������ṹ��

ALIGN_32BYTES(typedef struct {
  unsigned char       head;
  State_paras_STEP    state_struct;
}__attribute__((packed)) _EEPROM_STATE_STEP;)//�洢��EEPROM��state����

// pages 00~19 confile0
// pages 20~39 confile1
// pages 40~59 confile2

// pages 64~127 state0
// pages 128~191 state1
// pages 192~255 state2


#define DATA_Size_1024        1024
//AT24C128C:256 Pages*64 Bytes
//�����ļ���д�룬Ƶ����Եͺü�������������˹̶���
#define PAGES_PER_CONFILE             20
#define BASE_EEPROM_ADDRESS_MOTOR1   (0X00)
#define BASE_EEPROM_ADDRESS_MOTOR2   (BASE_EEPROM_ADDRESS_MOTOR1 + PAGES_PER_CONFILE*EEPROM_PAGESIZE)
#define BASE_EEPROM_ADDRESS_MOTOR3   (BASE_EEPROM_ADDRESS_MOTOR2 + PAGES_PER_CONFILE*EEPROM_PAGESIZE)

//����ÿ�������״̬���ݶ�ÿ�������������4ҳ��16��ѭ��������64ҳ��
// ͬʱ��16��ҳѭ��д�룬��ȫ��������ʱ����֤50+�ꡣ
#define BASE_STATE_EEPROM_ADDRESS_MOTOR    (64*EEPROM_PAGESIZE)
#define PAGES_PER_STATE              (1)
#define PAGES_PER_MOTOR              (16)

#define BASE_STATE_EEPROM_ADDRESS_MOTOR1   (BASE_STATE_EEPROM_ADDRESS_MOTOR)
#define BASE_STATE_EEPROM_ADDRESS_MOTOR2   (BASE_STATE_EEPROM_ADDRESS_MOTOR1 + PAGES_PER_MOTOR*EEPROM_PAGESIZE*PAGES_PER_STATE)
#define BASE_STATE_EEPROM_ADDRESS_MOTOR3   (BASE_STATE_EEPROM_ADDRESS_MOTOR2 + PAGES_PER_MOTOR*EEPROM_PAGESIZE*PAGES_PER_STATE)

#define STATE_EEPROM_PAGES_FOR_ONE_MOTOR        10



uint8_t ee_CheckOk(void);
uint8_t ee_ReadBytes(uint8_t *_pReadBuf, uint16_t _usAddress, uint16_t _usSize);
uint8_t ee_WriteBytes(uint8_t *_pWriteBuf, uint16_t _usAddress, uint16_t _usSize);
void ee_Erase(void);
uint8_t ee_Test(void);


uint32_t I2C_EE_WriteConfigFiles(uint8_t MotorChannel,  _EEPROM_CONF_STEP* pEE_conf);
uint32_t I2C_EE_ReadConfigFiles(uint8_t MotorChannel,  _EEPROM_CONF_STEP* pEE_conf);
uint8_t initial_confile_motor_struct(void);

uint8_t print_ee_MOTOR_ConfigFileIntial(void);
void print_ee_Hconf1(HCONF* phconf);
void print_ee_Hconf2(HCONF* phconf);

uint8_t EEPROM_find_page_offset_state(uint16_t* pageOffSet_StateInEEPROM );

uint8_t TEST_ONLY_EEPROM_find_page_offset_state(uint16_t* pageToWriteHead );
uint8_t TEST_ONLY_EEPROM_CLEAR_page_offset_state(void );

uint8_t EEPROM_Read_state(uint16_t* pageOffSet_StateInEEPROM,uint8_t MotorChannel, _EEPROM_STATE_STEP* stateStruct );


uint8_t initial_state_motor_struct(void);
void print_ee_state(void);
void print_ee_miniState_Motor(uint8_t port);
uint32_t I2C_EE_ReadAllConfigFiles(void);

void writeDefaultConfile2EEprom(void);

uint8_t initial_step_motor(uint8_t port);
uint8_t initial_step_motor_All(void);
void disPlayHome_status_variables(uint8_t port);
void actualValue_encoderAlignment(uint8_t port);
void writeStatusOneChannel(uint8_t port, uint16_t byte2Write,uint16_t tempoffset);
uint8_t EEPROM_Write_state_1(void );
uint8_t EEPROM_Write_state(void );
#endif /* __I2C_EE_H */
