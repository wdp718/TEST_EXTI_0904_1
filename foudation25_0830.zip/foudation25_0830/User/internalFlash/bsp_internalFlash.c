/**
  ******************************************************************************
  * @file    bsp_internalFlash.c
  * @author  fire
  * @version V1.0
  * @date    2017-xx-xx
  * @brief   �ڲ�FLASH��д���Է���
  ******************************************************************************
  * @attention
  *
  * ʵ��ƽ̨:Ұ�� STM32H743 ������  
  * ��̳    :http://www.firebbs.cn
  * �Ա�    :http://firestm32.taobao.com
  *
  ******************************************************************************
  */
  
#include "./internalFlash/bsp_internalFlash.h"   
#include "./usart/bsp_debug_usart.h"
#include "./stepper/bsp_stepper_init.h"
#include "stm32h7xx_hal.h"
#include "./led/bsp_led.h"   
#include "./flash/bsp_spi_flash.h"
#include "./i2c_io/bsp_i2c_ee.h"
#include "./i2c_io/bsp_i2c_gpio.h"
#include <string.h>
/*׼��д��Ĳ������ݣ�����32�ֽڶ���*/
ALIGN_32BYTES(uint32_t DATA_32 = 0xA5A5A5A5);
ALIGN_32BYTES(uint8_t  testInnerFlash[32]);
ALIGN_32BYTES(InnerFlash_info_Struct flashInfoStruct);

/* Exported types ------------------------------------------------------------*/
/* Exported constants --------------------------------------------------------*/
extern uint8_t mainBuffer[MAINBUFFER_SIZES_BYTES];

uint16_t index_innerFlash = 0;
extern _EEPROM_STATE_STEP state_motor_struct[MOTOR_IN_USE];

static uint32_t GetSector(uint32_t Address);
uint8_t flag_InderFlashEraser = 0;
extern  uint8_t flag_LowePower ;
/**
  * @brief  InternalFlash_Test,���ڲ�FLASH���ж�д����
  * @param  None
  * @retval None
  */
int InternalFlash_Test(void)
{
	/*Ҫ��������ʼ����(����)����������(������)����8-12����ʾ����8��9��10��11����*/
	uint32_t FirstSector = 0;
	uint32_t NbOfSectors = 0;
	
	uint32_t SECTORError = 0;
	
	uint32_t Address = 0;

	__IO uint32_t Data32 = 0;
	__IO uint32_t MemoryProgramStatus = 0;
	static FLASH_EraseInitTypeDef EraseInitStruct;
	int i;
	for(i = 0; i <32; i ++){
		testInnerFlash[i] = i;
	}
	/* FLASH ���� ********************************/
	/* ʹ�ܷ���FLASH���ƼĴ��� */
	HAL_FLASH_Unlock();
	printf("\r\nFLASH�ѽ���\r\n");

	FirstSector = GetSector(FLASH_USER_START_ADDR);
	NbOfSectors = GetSector(FLASH_USER_END_ADDR)- FirstSector + 1;
	printf("\r\n��ʼ�����ţ�%d����������%d\r\n", FirstSector, NbOfSectors);
	
	/* �����û����� (�û�����ָ������û��ʹ�õĿռ䣬�����Զ���)**/
	/* Fill EraseInit structure*/
	printf("\r\n��ʼ��������\r\n");
	EraseInitStruct.Banks         = FLASH_BANK_1;
	EraseInitStruct.TypeErase     = FLASH_TYPEERASE_SECTORS;
	//EraseInitStruct.VoltageRange  = FLASH_VOLTAGE_RANGE_3;/* �ԡ��֡��Ĵ�С���в��� */ 
	EraseInitStruct.VoltageRange  = FLASH_VOLTAGE_RANGE_2;/* �ԡ��֡��Ĵ�С���в��� */ 	
	EraseInitStruct.Sector        = FirstSector;
	EraseInitStruct.NbSectors     = NbOfSectors;
	/* ��ʼ�������� */
	if (HAL_FLASHEx_Erase(&EraseInitStruct, &SECTORError) != HAL_OK)
	{
		printf("\r\n��������ʧ��\r\n");
		/*�������������أ�ʵ��Ӧ���пɼ��봦�� */
		return -1;
	}
	else
		printf("\r\n���������ɹ�\r\n");
	
	/* �ԡ��֡��Ĵ�СΪ��λд������ ********************************/
	printf("\r\n��ʼд������\r\n");
	Address = FLASH_USER_START_ADDR;
	while (Address < FLASH_USER_END_ADDR)
	{
		if (HAL_FLASH_Program(FLASH_TYPEPROGRAM_FLASHWORD, Address, (uint64_t)&testInnerFlash[0]) == HAL_OK)
		{
		  Address = Address + 32;
		}
		else
		{ 
			printf("\r\n����д��ʧ��\r\n");
		  /*д����������أ�ʵ��Ӧ���пɼ��봦�� */
				return -1;
		}
	} 
	printf("\r\n����д��ɹ�\r\n");

	/* ��FLASH��������ֹ���ݱ��۸�*/
	HAL_FLASH_Lock(); 
	printf("\r\nFLASH������\r\n");

	/* ��FLASH�ж�ȡ�����ݽ���У��***************************************/
	/*  MemoryProgramStatus = 0: д���������ȷ
	  MemoryProgramStatus != 0: д������ݴ�����ֵΪ����ĸ��� */
	printf("\r\n��ʼУ������\r\n");
	Address = FLASH_USER_START_ADDR;
	MemoryProgramStatus = 0;

	while (Address < FLASH_USER_END_ADDR)
	{
		Data32 = *(__IO uint32_t*)Address;
		
		if (Data32 != DATA_32)
		{
			MemoryProgramStatus++;  
		}

		Address = Address + 32;
	}  
	/* ����У�鲻��ȷ */
	if(MemoryProgramStatus)
	{
		return -1;
	}
	else /*����У����ȷ*/
	{
		printf("\r\n����У��ɹ�\r\n");
		return 0;
	}
}
int innerFlash_erase(uint32_t startSecotr,uint32_t  endSector)
{
 	uint32_t FirstSector = startSecotr;
	uint32_t NbOfSectors = endSector;
	
	uint32_t SECTORError = 0;
	

	
    static FLASH_EraseInitTypeDef EraseInitStruct;
/*	FirstSector = GetSector(startSecotr);
	NbOfSectors = GetSector(endSector)- FirstSector + 1;

	HAL_FLASH_Unlock();
	EraseInitStruct.Banks         = FLASH_BANK_1;
	EraseInitStruct.TypeErase     = FLASH_TYPEERASE_SECTORS;
	EraseInitStruct.VoltageRange  = FLASH_VOLTAGE_RANGE_3;//�ԡ��֡��Ĵ�С���в��� 
	EraseInitStruct.Sector        = FirstSector;
	EraseInitStruct.NbSectors     = NbOfSectors;

    if (HAL_FLASHEx_Erase(&EraseInitStruct, &SECTORError) != HAL_OK){
		printf("\r\n��������ʧ��\r\n");
		return -1;
	}
	HAL_FLASH_Lock(); */
    flag_InderFlashEraser = 1;
	HAL_FLASH_Unlock();
	printf("\r\nFLASH�ѽ���\r\n");

	FirstSector = GetSector(FLASH_USER_START_ADDR);
	NbOfSectors = GetSector(FLASH_USER_END_ADDR)- FirstSector + 1;
	printf("\r\n��ʼ�����ţ�%d����������%d\r\n", FirstSector, NbOfSectors);
	
	/* �����û����� (�û�����ָ������û��ʹ�õĿռ䣬�����Զ���)**/
	/* Fill EraseInit structure*/
	printf("\r\n��ʼ��������\r\n");
	EraseInitStruct.Banks         = FLASH_BANK_1;
	EraseInitStruct.TypeErase     = FLASH_TYPEERASE_SECTORS;
	EraseInitStruct.VoltageRange  = FLASH_VOLTAGE_RANGE_3;/* �ԡ��֡��Ĵ�С���в��� */ 
	EraseInitStruct.Sector        = FirstSector;
	EraseInitStruct.NbSectors     = NbOfSectors;
	/* ��ʼ�������� */

	/*if (HAL_FLASHEx_Erase(&EraseInitStruct, &SECTORError) != HAL_OK)
	{
		printf("\r\n��������ʧ��\r\n");
		return -1;
	}*/
    while(HAL_FLASHEx_Erase(&EraseInitStruct, &SECTORError) != HAL_OK){
	    vTaskDelay(100);		
		printf("\r\n��������ʧ��\r\n");	
	}

    flag_InderFlashEraser = 2;
	printf("\r\n��������ok\r\n");
	return 0;
}
void innerFlash_Read(uint8_t* pBuffer, uint32_t ReadAddr, uint32_t Num_u32_ToRead)
{
  uint32_t len = Num_u32_ToRead;
	uint32_t u32_temp[32];
	uint32_t Address = ReadAddr;
  uint32_t i=0;
	__disable_irq();
    while ( len > 0){
		u32_temp[i] = *(__IO uint32_t*)Address;
		Address = Address + 4;
		len --;
		//printf("temp[%d]:%x\r\n",i,temp[i]);	
		i++;
	}
	__enable_irq(); 
	memcpy( (void*)pBuffer,(void*)&u32_temp[0], (unsigned int)(Num_u32_ToRead*4));
}
uint8_t innerFlash_Read_state_back_for_FLASH(void )
{
    uint16_t SigleLen = (uint16_t)( sizeof(State_mini_paras_STEP) + 1 )+1;  
    uint16_t u16_len = (uint16_t)( sizeof(InnerFlash_info_Struct));

    innerFlash_Read(mainBuffer,FLASH_USER_START_ADDR + index_innerFlash*INNER_FLASH_PERSTORAGE, 32);//32*4bytes
    memcpy( (void*)&state_motor_struct[0],(void*)&mainBuffer[ 0         ], SigleLen);
    memcpy( (void*)&state_motor_struct[1],(void*)&mainBuffer[ SigleLen  ], SigleLen);
    memcpy( (void*)&state_motor_struct[2],(void*)&mainBuffer[ 2*SigleLen], SigleLen);

    memcpy( (void*)&flashInfoStruct ,     (void*)&mainBuffer[ 3*SigleLen], u16_len);
	#ifdef UART_DEBUG_STP
     printf("time:%x\n",flashInfoStruct.timesRemainErasing_ms);  	
     printf("tail:%x\n",flashInfoStruct.u32_flag_tail_erasering);  
    #endif  
    return 0;  	
}
	
//ALIGN_32BYTES(uint32_t temp[32]);
//ALIGN_32BYTES(uint32_t temp[32]);
__align(64) uint32_t temp[32];
//void innerFlash_BufferWrite(uint8_t* pBuffer, uint32_t Num_u32_ToRead)
void innerFlash_BufferWrite(void)
{	
	int i,j;
	uint32_t WriteAddr = FLASH_USER_START_ADDR + index_innerFlash*INNER_FLASH_PERSTORAGE;
	HAL_StatusTypeDef status = HAL_OK;

    #ifdef UART_DEBUG_STP
       if(index_innerFlash == INNER_FLASH_MAX_INDEX-1)
	    printf("writing InnerFlash\n"); 
    #endif   

	__disable_irq();
	HAL_FLASH_Unlock();
	for(j = 0; j < 0xffff; j++);
     for(i = 0; i < 4; i ++){
			 status = HAL_FLASH_Program(FLASH_TYPEPROGRAM_FLASHWORD, WriteAddr, (uint64_t)&temp[i*8]); 
	    if (status == HAL_OK){					
	    	WriteAddr = WriteAddr + 32;
	    }else{
          printf("inner Flash error��%d \n",status);  			
		  }
		for(j = 0; j < 0xffff; j++);
	}
	HAL_FLASH_Lock(); 
	__enable_irq(); 
    #ifdef UART_DEBUG_STP
     //     printf("writing Done\n");  
    #endif   
}

void jointMotorStatus2Memory_innerFlash(void)
{
  /*  uint16_t SigleLen = (uint16_t)( sizeof(State_mini_paras_STEP) + 1 ) + 1;
  uint16_t u16_len  = (uint16_t)( sizeof(InnerFlash_info_Struct));
  #ifdef UART_DEBUG_STP
     printf("u16_len:%d\n",u16_len);  
	 printf("SigleLen:%d\n",SigleLen);  
  #endif   


  memcpy( (void*)&pBuffer[ 0         ],(void*)&state_motor_struct[0], SigleLen);
  memcpy( (void*)&pBuffer[ SigleLen  ],(void*)&state_motor_struct[1], SigleLen);
  memcpy( (void*)&pBuffer[ 2*SigleLen],(void*)&state_motor_struct[2], SigleLen);
  memcpy( (void*)&pBuffer[ 3*SigleLen],(void*)&flashInfoStruct, u16_len);
*/
  __disable_irq();
  memcpy( (void*)&temp[ 0  ],(void*)&state_motor_struct[0], 32);
  memcpy( (void*)&temp[ 8  ],(void*)&state_motor_struct[1], 32);
  memcpy( (void*)&temp[ 16 ],(void*)&state_motor_struct[2], 32);
  memcpy( (void*)&temp[ 24 ],(void*)&flashInfoStruct, 32);   
  __enable_irq(); 

}

void writeStatus_Inner_Flash(void)
{
   // uint8_t subBuffer[128];
	uint8_t errorTime=0;
    uint16_t byte2Write = 3* (uint16_t)( sizeof(State_mini_paras_STEP) + 1 );
    uint16_t tempSectorIndex;
    int  i;
	jointMotorStatus2Memory_innerFlash();

    if (index_innerFlash == (INNER_FLASH_MAX_INDEX ) ) {
      index_innerFlash        = 0;     
      flag_InderFlashEraser = 1;// it's time to erase the Inner Flash.
      #ifdef UART_DEBUG_STP
          printf("Inner Erasing!\n");  
      #endif      
      innerFlash_erase(FLASH_USER_START_ADDR,FLASH_USER_END_ADDR);//
      #ifdef UART_DEBUG_STP
          printf("Erasing Done!\n");  
      #endif      
     // return ;
    }
    if(flag_InderFlashEraser == 2){
       tempSectorIndex =  0;
	   flag_InderFlashEraser = 0;
     // printf("\r\n after erase!\n\r");      
    }
    else{
       tempSectorIndex =  index_innerFlash +1 ;
    }

    if(0 == flag_InderFlashEraser){
		//printf("\r\n writing to %d\n\r",tempSectorIndex);      
        //innerFlash_BufferWrite(mainBuffer,32);
		innerFlash_BufferWrite();
        index_innerFlash = tempSectorIndex;      
    }
    index_innerFlash = tempSectorIndex;
}

uint16_t divide2Advance_innerFlash(unsigned short *u16_offset, uint32_t startIndex, uint32_t  endIndex)
{
  uint8_t  u8_temp;  
  uint8_t u8_newArea       = 0xff;  
  uint8_t u8_occupied      = (uint8_t)HEAD_IN_EEPROM;
  uint32_t currentPosition = ((startIndex + endIndex)>>1);
  uint16_t u16_searchTimes = 0;  
  float    f_tempFloat     = 0.0;
  innerFlash_Read(mainBuffer,FLASH_USER_START_ADDR + currentPosition*INNER_FLASH_PERSTORAGE, 1);//1*4bytes

  u8_temp    = (uint8_t)mainBuffer[0];

  if(currentPosition == startIndex){
    *u16_offset = startIndex;
	  return startIndex;
  }

  if(currentPosition == endIndex ){
    *u16_offset = endIndex;
	  return endIndex;
  }
  #ifdef UART_DEBUG_STP   
      printf( "u16_searchTimes:%d\n",u16_searchTimes );
	    printf( "currentPosition:%d\n",currentPosition );
	    printf( "\n" );
	#endif  
	u16_searchTimes ++;
  while((currentPosition != startIndex)&&(currentPosition != endIndex)){
	  if(u8_occupied == u8_temp ){// up finding new u8_newArea
		  startIndex      = currentPosition;
          currentPosition = (unsigned short)((startIndex +endIndex)>>1);
          innerFlash_Read(mainBuffer,FLASH_USER_START_ADDR + currentPosition*INNER_FLASH_PERSTORAGE, 1);//1*4bytes
		  u8_temp         = mainBuffer[0];//read memory
      }
	  else{
        if(u8_occupied != u8_temp){
		  endIndex        = currentPosition;
          currentPosition = (unsigned short)((startIndex +endIndex)>>1);
          innerFlash_Read(mainBuffer,FLASH_USER_START_ADDR + currentPosition*INNER_FLASH_PERSTORAGE, 1);//1*4bytes
		  u8_temp         = mainBuffer[0];//read memory					
		}
    }   
		f_tempFloat = 0.5*(float)(startIndex +endIndex);
        #ifdef UART_DEBUG_STP   
          printf( "u16_searchTimes:%d\n",u16_searchTimes );
	      printf( "currentPosition:%d\n",currentPosition );
	      printf( "\n" );
	    #endif  
	  u16_searchTimes ++;

  }// end of while

	*u16_offset = currentPosition;		
  if(currentPosition == (INNER_FLASH_MAX_INDEX-1) ){
        if(f_tempFloat > (float)(currentPosition)){
	    	  currentPosition++;
	         *u16_offset = currentPosition;
	    }
	    else{
	         *u16_offset = currentPosition;		
	    }
	}

    #ifdef UART_DEBUG_STP   
	      printf( "f_tempFloat:%f\n",f_tempFloat );
           printf( "u16_offset:%d\n",*u16_offset );
	  #endif   
	return currentPosition;
}
void readInnerFlash_print_flashInfoStruct_Test(void)
{
    uint16_t len = index_innerFlash;
    uint16_t i;
    uint8_t  u8_tempArray[128];
    uint16_t SigleLen = (uint16_t)( sizeof(State_mini_paras_STEP) + 1 )+1;  
    uint16_t u16_len = (uint16_t)( sizeof(InnerFlash_info_Struct));
	InnerFlash_info_Struct tempInfo;
    uint16_t displayLen;
	/*if(len>80){
	displayLen = len-80;
	}
	else{
	displayLen = 0;
	}*/


    for(i = 0; i <= len; i ++ ){
        innerFlash_Read(u8_tempArray,FLASH_USER_START_ADDR + i*INNER_FLASH_PERSTORAGE, 32);//32*4bytes
      //  memcpy( (void*)&state_motor_struct[0],(void*)&u8_tempArray[ 0         ], SigleLen);
      //  memcpy( (void*)&state_motor_struct[1],(void*)&u8_tempArray[ SigleLen  ], SigleLen);
      //  memcpy( (void*)&state_motor_struct[2],(void*)&u8_tempArray[ 2*SigleLen], SigleLen);
         memcpy( (void*)&tempInfo ,            (void*)&u8_tempArray[ 3*SigleLen], u16_len);
		 vTaskDelay(200);
	      #ifdef UART_DEBUG_STP
         printf("%d\n",i);  		
         printf("time:%d\n",tempInfo.timesRemainErasing_ms);  	
         printf("tail:%x\n",tempInfo.u32_flag_tail_erasering);  
        #endif 
         			
	}
}
void readInnerFlash_print_flashInfoStruct_Test_ALL0XFF(void)
{
    uint16_t len = 256;
    uint16_t i;
    uint8_t  u8_tempArray[128];
    uint16_t SigleLen = (uint16_t)( sizeof(State_mini_paras_STEP) + 1 );  
    uint16_t u16_len = (uint16_t)( sizeof(InnerFlash_info_Struct));
	  InnerFlash_info_Struct tempInfo;
    uint16_t displayLen;

    for(i = 0; i < len; i ++ ){
        innerFlash_Read(u8_tempArray,FLASH_USER_START_ADDR + i*INNER_FLASH_PERSTORAGE, 32);//32*4bytes
         memcpy( (void*)&tempInfo ,            (void*)&u8_tempArray[ 3*SigleLen], u16_len);
		vTaskDelay(20);
	      #ifdef UART_DEBUG_STP
         printf("%d\n",i);  		
         printf("time:%d\n",tempInfo.timesRemainErasing_ms);  	
		 printf("time:%x\n",tempInfo.timesRemainErasing_ms);  	
         printf("tail:%x\n",tempInfo.u32_flag_tail_erasering);  
        #endif 
         			
	}
}

void readInnerFlash_print_flashInfoStruct_Test_Newest(void)
{

    uint16_t i= index_innerFlash;
    uint8_t  u8_tempArray[128];
    uint16_t SigleLen = (uint16_t)( sizeof(State_mini_paras_STEP) + 1 )+1;  
    uint16_t u16_len = (uint16_t)( sizeof(InnerFlash_info_Struct));
	InnerFlash_info_Struct tempInfo;

    innerFlash_Read(u8_tempArray,FLASH_USER_START_ADDR + i*INNER_FLASH_PERSTORAGE, 32);//32*4bytes
    memcpy( (void*)&tempInfo ,            (void*)&u8_tempArray[ 3*SigleLen], u16_len);
	vTaskDelay(200);
	#ifdef UART_DEBUG_STP
        printf("%d\n",i);  		
        printf("time:%d\n",tempInfo.timesRemainErasing_ms);  	
        printf("tail:%x\n",tempInfo.u32_flag_tail_erasering);  
    #endif 
         			
}
/*
uint8_t Inner_FLASH_find_sector_offset_state(uint16_t* pU16SectorIndex)
{
  uint16_t u16_tempOffset = 0;
  uint8_t u8_temp         = 0;
  uint8_t u8_occupied     = (uint8_t)HEAD_IN_EEPROM;
  u16_tempOffset          =  divide2Advance(pU16SectorIndex, FLASH_STATE_SECTOR ,MAX_SECTOR);

  SPI_FLASH_BufferRead(mainBuffer, BASE_STATE_FLASH_ADDRESS_MOTOR + u16_tempOffset*SPI_FLASH_PerSectorSize, 1);          
	u8_temp         = mainBuffer[0];//read memory			
  if(u8_temp != u8_occupied){// all empty;
    printf("FLASH EMPTY!\n");
    return 0;
  }	
  #ifdef UART_DEBUG_STP
  printf("pU16SectorIndex is %d !\n",*pU16SectorIndex);  
  #endif

  return 1;       
}*/
/**
  * @brief  ��������ĵ�ַ���������ڵ�sector
  *					���磺
						uwStartSector = GetSector(FLASH_USER_START_ADDR);
						uwEndSector = GetSector(FLASH_USER_END_ADDR);	
  * @param  Address����ַ
  * @retval ��ַ���ڵ�sector
  */
static uint32_t GetSector(uint32_t Address)
{
  uint32_t sector = 0;
  
  if((Address < ADDR_FLASH_SECTOR_1) && (Address >= ADDR_FLASH_SECTOR_0))
  {
    sector = FLASH_SECTOR_0;  
  }
  else if((Address < ADDR_FLASH_SECTOR_2) && (Address >= ADDR_FLASH_SECTOR_1))
  {
    sector = FLASH_SECTOR_1;  
  }
  else if((Address < ADDR_FLASH_SECTOR_3) && (Address >= ADDR_FLASH_SECTOR_2))
  {
    sector = FLASH_SECTOR_2;  
  }
  else if((Address < ADDR_FLASH_SECTOR_4) && (Address >= ADDR_FLASH_SECTOR_3))
  {
    sector = FLASH_SECTOR_3;  
  }
  else if((Address < ADDR_FLASH_SECTOR_5) && (Address >= ADDR_FLASH_SECTOR_4))
  {
    sector = FLASH_SECTOR_4;  
  }
  else if((Address < ADDR_FLASH_SECTOR_6) && (Address >= ADDR_FLASH_SECTOR_5))
  {
    sector = FLASH_SECTOR_5;  
  }
  else if((Address < ADDR_FLASH_SECTOR_7) && (Address >= ADDR_FLASH_SECTOR_6))
  {
    sector = FLASH_SECTOR_6;  
  }
  else/*(Address < FLASH_END_ADDR) && (Address >= ADDR_FLASH_SECTOR_23))*/
  {
    sector = FLASH_SECTOR_7;  
  }
  return sector;
}


