#ifndef __INTERNAL_FLASH_H
#define	__INTERNAL_FLASH_H

#include "stm32h7xx.h"



typedef struct {
    uint32_t timesRemainErasing_ms ;
    uint32_t  u32_flag_tail_erasering;
    uint32_t  NOUSE[14];
}InnerFlash_info_Struct;

/* Base address of the Flash sectors */ 
#define ADDR_FLASH_SECTOR_0     ((uint32_t)0x08000000) /* Base address of Sector 0, 128 Kbytes */
#define ADDR_FLASH_SECTOR_1     ((uint32_t)0x08020000) /* Base address of Sector 1, 128 Kbytes */
#define ADDR_FLASH_SECTOR_2     ((uint32_t)0x08040000) /* Base address of Sector 2, 128 Kbytes */
#define ADDR_FLASH_SECTOR_3     ((uint32_t)0x08068000) /* Base address of Sector 3, 128 Kbytes */
#define ADDR_FLASH_SECTOR_4     ((uint32_t)0x08080000) /* Base address of Sector 4, 128 Kbytes */
#define ADDR_FLASH_SECTOR_5     ((uint32_t)0x080A0000) /* Base address of Sector 5, 128 Kbytes */
#define ADDR_FLASH_SECTOR_6     ((uint32_t)0x080C0000) /* Base address of Sector 6, 128 Kbytes */
#define ADDR_FLASH_SECTOR_7     ((uint32_t)0x080E0000) /* Base address of Sector 7, 128 Kbytes */

/* Ҫ�����ڲ�FLASH����ʼ��ַ */
#define FLASH_USER_START_ADDR   ADDR_FLASH_SECTOR_2   
//#define FLASH_USER_START_ADDR   ADDR_FLASH_SECTOR_5   
/* Ҫ�����ڲ�FLASH�Ľ�����ַ */
#define FLASH_USER_END_ADDR     ADDR_FLASH_SECTOR_7 


#define INNER_FLASH_PERSTORAGE    (128)
//#define INNER_FLASH_PERSTORAGE    (256)

#define INNER_FLASH_MAX_INDEX    ((FLASH_USER_END_ADDR-FLASH_USER_START_ADDR)/INNER_FLASH_PERSTORAGE - 1)
//#define INNER_FLASH_MAX_INDEX    (50)

#define OUT_FLASH_FINISHING         0X5555AAAA
#define OUT_FLASH_NOT_FINISH        0XF0F0F0F0

#define THREDHOLD_ERASE_INNERFLASH  (INNER_FLASH_MAX_INDEX - 200)





int InternalFlash_Test(void);
int innerFlash_erase(uint32_t startSecotr,uint32_t  endSector);
void innerFlash_Read(uint8_t* pBuffer, uint32_t ReadAddr, uint32_t Num_u32_ToRead);
uint8_t innerFlash_Read_state_back_for_FLASH(void );

//void innerFlash_BufferWrite(uint8_t* pBuffer, uint32_t Num_u32_ToRead);
void writeStatus_Inner_Flash(void);
uint16_t divide2Advance_innerFlash(unsigned short *u16_offset, uint32_t startIndex, uint32_t  endIndex);
void jointMotorStatus2Memory_innerFlash(void);
void readInnerFlash_print_flashInfoStruct_Test(void);
void readInnerFlash_print_flashInfoStruct_Test_ALL0XFF(void);
void readInnerFlash_print_flashInfoStruct_Test_Newest(void);

void innerFlash_BufferWrite(void);


#endif /* __INTERNAL_FLASH_H */

