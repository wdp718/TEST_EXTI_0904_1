#include "./pid/bsp_pid.h"
#include "math.h"

#include "./usart/bsp_debug_usart.h"
#include<string.h>
#include "./stepper/bsp_stepper_init.h"
/* FreeRTOSͷ�ļ� */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "semphr.h"

#include "./control/bsp_ctrl.h"
/* ����ȫ�ֱ��� */
_pid speed_pid[MOTOR_IN_USE],move_pid[MOTOR_IN_USE];
float set_point = 0.0;
int pid_status  = 0;

void PID_param_init(uint8_t motorID)
{
  /* ��ʼ��λ�û�PID���� */
  move_pid[motorID].target_val = 0.0;				
  move_pid[motorID].actual_val = 0.0;
  move_pid[motorID].err        = 0.0;
  move_pid[motorID].err_last   = 0.0;
  move_pid[motorID].err_next   = 0.0;
  //move_pid[motorID].Kp         = 0.0015;
	move_pid[motorID].Kp         = 0.01;
  move_pid[motorID].Ki         = 0.0;
  move_pid[motorID].Kd         = 0.0;		
  
  #if PID_ASSISTANT_EN
  float move_pid_temp[3] = {move_pid.Kp, move_pid.Ki, move_pid.Kd};
  set_computer_value(SEED_P_I_D_CMD, CURVES_CH1, move_pid_temp, 3);// ��ͨ�� 1 ���� P I D ֵ
  #endif
  HAL_Delay(10);
  /* ��ʼ���ٶȻ�PID���� */
  speed_pid[motorID].target_val = 0.0;				
  speed_pid[motorID].actual_val = 0.0;
  speed_pid[motorID].err        = 0.0;
  speed_pid[motorID].err_last   = 0.0;
  speed_pid[motorID].err_next   = 0.0;
  speed_pid[motorID].Kp         = 0.001;
  speed_pid[motorID].Ki         = 0.02;
  speed_pid[motorID].Kd         = 0.3;

  speed_pid[motorID].last_count = 0.0;
  speed_pid[motorID].cont_val   = 0.0;

  #if PID_ASSISTANT_EN
  float speed_pid_temp[3] = {speed_pid.Kp, speed_pid.Ki, speed_pid.Kd};
  set_computer_value(SEED_P_I_D_CMD, CURVES_CH2, speed_pid_temp, 3);// ��ͨ�� 1 ���� P I D ֵ
  #endif
}

void set_pid_target(_pid *pid, float temp_val)
{
  pid->target_val = temp_val;   
}

float get_pid_actual(_pid *pid)
{
  return pid->target_val;   
}

void set_p_i_d(_pid *pid, float p, float i, float d)
{
  pid->Kp = p;     
	pid->Ki = i;     
	pid->Kd = d;    
}

float PID_realize(_pid *pid, float temp_val) 
{
    float increment_val= 0;
    pid->actual_val     = temp_val;
    pid->err            = pid->target_val - pid->actual_val;
    
    increment_val       = pid->Kp*(pid->err - pid->err_next) + pid->Ki*pid->err + pid->Kd*(pid->err - 2 * pid->err_next + pid->err_last);
    pid->err_last       = pid->err_next;
    pid->err_next       = pid->err;

    return increment_val;
}











