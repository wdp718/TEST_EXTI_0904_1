#ifndef __PVD_H
#define	__PVD_H

#include "stm32h7xx.h"
#include "stm32h7xx_hal_def.h"

void PVD_Config(void);

#endif 


