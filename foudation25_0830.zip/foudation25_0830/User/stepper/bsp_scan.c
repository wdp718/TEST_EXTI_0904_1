#include "stm32h7xx.h"
#include "./stepper/bsp_scan.h"
#include "./Encoder/bsp_encoder2.h"
#include "./usart/bsp_debug_usart.h"
#include "./stepper/bsp_stepper_init.h"
#include  <math.h>
#include "./control/bsp_ctrl.h"
#include "./pid/bsp_pid.h"
#include "./flash/bsp_spi_flash.h"
#include "./internalFlash/bsp_internalFlash.h"   
#include "./i2c_io/bsp_i2c_ee.h"
#include "./i2c_io/bsp_i2c_gpio.h"
#define UART_DEBUG_STP 1 //需要打印输出时，定义�??

extern _EEPROM_CONF_STEP ee_conFile[MOTOR_IN_USE];
extern HOME_SIGNALS_STRUCT motor_Home_Sig_Sturct[MOTOR_IN_USE];
extern _EEPROM_STATE_STEP state_motor_struct[MOTOR_IN_USE];
extern uint16_t      GPIO_signal1_pin[MOTOR_IN_USE];
extern GPIO_TypeDef* GPIO_signal1_port[MOTOR_IN_USE] ;
extern uint16_t      GPIO_signal2_pin[MOTOR_IN_USE];
extern GPIO_TypeDef* GPIO_signal2_port[MOTOR_IN_USE] ;
extern uint16_t U16SectorIndex;
int    capture_count;
extern _pid speed_pid[MOTOR_IN_USE],move_pid[MOTOR_IN_USE];
extern int capture_count_current[ MOTOR_IN_USE ];
extern int capture_count_last[    MOTOR_IN_USE ] ;
extern int capture_per_unit[      MOTOR_IN_USE ];

extern uint16_t  GPIO_input_enable_pin[4]   ;   
extern GPIO_TypeDef* GPIO_input_enable_port[4];  

static uint8_t u8_fullTrailForHoming = 0;//from homeapp-1 to homeapp +1 ,if home signal is not triggered, this++
static float  f_tempStart            = 0.0;
static uint8_t u8_triggerTrail       = 0;//
float  lowSignalValue[con_maxTriggerTrail];       
float  upSignalValue[con_maxTriggerTrail];   

extern uint8_t flag_entireFlashEraser ;
extern uint32_t timeForFlashErase     ;//ms
extern uint8_t u8_flag_rebooting ;
extern InnerFlash_info_Struct flashInfoStruct;
extern uint8_t flag_InderFlashEraser ;
extern uint16_t index_innerFlash ;
extern uint16_t U16SectorIndex ;

extern  long long int   lastCountInPWM_IRQ[    MOTOR_IN_USE ] ;
extern  long long int   CurrentCountInPWM_IRQ[ MOTOR_IN_USE ] ;
extern int                      lastValueEncoder[      MOTOR_IN_USE ] ;
extern int                      CurrentValueEncoder[   MOTOR_IN_USE ] ;
extern int                      indexTrigerd4MissingCecck[   MOTOR_IN_USE ];

extern int64_t                  countInPWM_noIndex[MOTOR_IN_USE];
extern master_slave_struct      masterSlaveStruct;
extern int homeFinalStep[MOTOR_IN_USE ];

 void STEP_SCAN_Task(void* pvParameters)
{
  BaseType_t xReturn = pdPASS;
  uint32_t i;
	State_paras_STEP state_paras;
  while (1)
  { 
	  for(i = 0; i< MOTOR_IN_USE; i++){
			if((   step_motor[i].this_state->miniState.state & STATE_WAIT_OR_NOT ) != STATE_WAIT_OR_NOT ){//wait command   == 0
        if(( step_motor[i].this_state->miniState.state & STATE_ENAB_OR_NOT ) != STATE_ENAB_OR_NOT ){//enable command == 0
          stateMachine(i);
          step_miniSwich(i);
          step_withSpeed_miniSwich(i);
          scan_step_miniSwich(i);
          continue_scan_miniSwich(i);
          move2p_miniswich(i);
          findHome_switch(i);
          home_swich(i);
        }else{//enable command ==1
         if(  (ee_conFile[i].this_HCONF.hconf1 & ENABLE_AVAILABLE_HCONF1 ) == ENABLE_AVAILABLE_HCONF1 ){// ENABLE signal exsit and == effective 
          if( (ee_conFile[i].this_HCONF.hconf2 & INPUTENABLE_HIGH_HCONF2 ) == INPUTENABLE_HIGH_HCONF2 ){// high effective
              if(HAL_GPIO_ReadPin(GPIO_input_enable_port[i],GPIO_input_enable_pin[i]) == GPIO_PIN_SET  ){
                 stateMachine(i);
                 step_miniSwich(i);
                 step_withSpeed_miniSwich(i);
                 scan_step_miniSwich(i);
                 continue_scan_miniSwich(i);
                 move2p_miniswich(i);
                 findHome_switch(i);
                 home_swich(i);
              }       
          }else{// low effective
              if(HAL_GPIO_ReadPin(GPIO_input_enable_port[i],GPIO_input_enable_pin[i]) == GPIO_PIN_RESET  ){
                 stateMachine(i);
                 step_miniSwich(i);
                 step_withSpeed_miniSwich(i);
                 scan_step_miniSwich(i);
                 continue_scan_miniSwich(i);
                 move2p_miniswich(i);
                 findHome_switch(i);
                 home_swich(i);
              }  
          }
         }
        }// end of else...
      }// end of if((   step_motor[i].this_state->miniSate & STATE_WAIT_OR_NOT ) != STATE_WAIT_OR_NOT ){//wait command   == 0
      /*Limitations_Control(i);
      checkCollision(i);
      checkUplimtSignal(i);
      checkLowlimtSignal(i);
      checkMissingSteps(i);	
      checkMissingSteps_index_only(i);	*/
			if (step_motor[i].this_state->miniState.speedActual >= ee_conFile[i].upperLimitation)
			{ step_motor[i].this_state->miniState.state      |= STATE_UPPER_VALUE_OR_NOT;}
			else{
				step_motor[i].this_state->miniState.state      &= ~STATE_UPPER_VALUE_OR_NOT;
			}
			if (step_motor[i].this_state->miniState.speedActual <= ee_conFile[i].lowerLimitation)
			{step_motor[i].this_state->miniState.state      |= STATE_lOWER_VALUE_OR_NOT;}
			else{
				step_motor[i].this_state->miniState.state      &= ~STATE_lOWER_VALUE_OR_NOT;
			}
		}

      vTaskDelay(100);
  }
}

//

void move2Postion(uint8_t motorId)
{
  int flag_backlsh = 0;
  int returnValue  = 0;
  float fTempSpeedSet = step_motor[motorId].this_state->miniState.speedSet;
  if( ( fabs(fTempSpeedSet) <= 1e-6)||( fTempSpeedSet >= ee_conFile[motorId].maxSpeedFast)){
     step_motor[motorId].this_state->miniState.speedSet = ee_conFile[motorId].maxSpeedFast;
  }
  setDirection(motorId);
  setSpeed_PWM(motorId);
  flag_backlsh = chekBackLash(motorId);
	if( STEP_MOVE2_POSITION == (STEP_MOVE2_POSITION & step_motor[motorId].this_state->stateMachine)){
    if( 1 == flag_backlsh){// upper direction needs backlash 
      step_motor[motorId].this_state->miniState.valueSet +=  ee_conFile[motorId].backlash;
      step_motor[motorId].this_state->flag_backlash = 1;
    }
    if(-1 == flag_backlsh ){// lower direction needs backlash 
      step_motor[motorId].this_state->miniState.valueSet -= ee_conFile[motorId].backlash;
      step_motor[motorId].this_state->flag_backlash = -1;
    }
  }
  setCounts_PWM(motorId);
 //PID 
  //move_pid[motorId].target_val     = step_motor[motorId].this_state->miniState.valueSet;
  //end of PID
  returnValue = stepper_Start(step_motor[motorId].pul_channel);
  if(-1 ==returnValue){
    start_state(motorId);
  }

}
void setSpeed_PWM(uint8_t motorId)
{
  float f_Speed =0;
  if( ( fabs(step_motor[motorId].this_state->miniState.speedSet) <= 1e-6)||( step_motor[motorId].this_state->miniState.speedSet >= ee_conFile[motorId].maxSpeedFast))
  {
     step_motor[motorId].this_state->miniState.speedSet = ee_conFile[motorId].maxSpeedFast;
  }
  f_Speed  = ee_conFile[motorId].fullStep*ee_conFile[motorId].microStep;
  f_Speed /= ee_conFile[motorId].gearRatio;
  f_Speed *= step_motor[motorId].this_state->miniState.speedSet;//*ee_conFile[motorId].resolution;
//  printf("step_motor[motorId].this_state->miniState.speedSet is %f \n",step_motor[motorId].this_state->miniState.speedSet);	
//  printf("f_Speed is %f \n",f_Speed);	

  step_motor[motorId].oc_pulse_num = (unsigned int) ( ((float)FRE_PWM)/f_Speed )>>1;
  if(0 == step_motor[motorId].oc_pulse_num)
    step_motor[motorId].oc_pulse_num = 1;
//	printf("step_motor[%d].oc_pulse_num is %d \n",motorId,step_motor[motorId].oc_pulse_num);	

}
void setCounts_PWM(uint8_t motorId)
{  
  uint32_t u32_PWMCount  = 0;  
  uint32_t u32_microStep = ee_conFile[motorId].microStep;
  float    f_tempFloat   = 0.0;
  double f_tempDouble = 0.0;
  u32_PWMCount  = ee_conFile[motorId].fullStep;
  u32_PWMCount /= ee_conFile[motorId].gearRatio;
  u32_PWMCount *= u32_microStep;
  
  f_tempFloat = fabs( step_motor[motorId].this_state->miniState.valueSet - step_motor[motorId].this_state->miniState.valueActual);
  
  //printf("f_tempFloat %f \n",f_tempFloat);
  f_tempDouble = 2*f_tempFloat*u32_PWMCount;
  //printf("f_tempDouble %f \n",f_tempDouble);
  u32_PWMCount = (uint32_t)f_tempDouble;
//  printf("u32_PWMCount %ld \n",u32_PWMCount);

/*
  if(f_tempFloat >= (ee_conFile[motorId].upperLimitation - ee_conFile[motorId].lowerLimitation)*0.5F ){
    u32_PWMCount *= (uint32_t)(2*fabs( step_motor[motorId].this_state->miniState.valueSet - step_motor[motorId].this_state->miniState.valueActual));
  }else{
    u32_PWMCount *= (uint32_t)(2*fabs( step_motor[motorId].this_state->miniState.valueSet - step_motor[motorId].this_state->miniState.valueActual));
  } */
  step_motor[motorId].this_state->countInPWM_IRQ = (uint32_t)u32_PWMCount;
  if(1 >= u32_PWMCount){
    u32_PWMCount = 2;
    step_motor[motorId].this_state->countInPWM_IRQ = 2;

  }
  
  // for PID
  if( step_motor[motorId].this_state->miniState.valueSet - step_motor[motorId].this_state->miniState.valueActual >=0){
    move_pid[motorId].target_val += (float)u32_PWMCount;
    move_pid[motorId].moveDirection  = UP;
	}
	else{
    move_pid[motorId].target_val -= (float)u32_PWMCount;
    move_pid[motorId].moveDirection  = DOWN;
  }

if(ENCODER_AVAILABLE_HCONF1 ==( ee_conFile[motorId].this_HCONF.hconf1 & ENCODER_AVAILABLE_HCONF1) ){// encoder available
    lastCountInPWM_IRQ[    motorId ]  = u32_PWMCount;
    CurrentCountInPWM_IRQ[ motorId ]  = u32_PWMCount;
    CurrentValueEncoder[    motorId]  = (int)__HAL_TIM_GET_COUNTER(&TIM_EncoderHandle[motorId]) + (Encoder_Overflow_Count[motorId] * ENCODER_TIM_PERIOD);
    lastValueEncoder[       motorId]  = CurrentValueEncoder[motorId]   ;
}else{// index only
    if(INDEX_AVAILABLE_HCONF1 ==( ee_conFile[motorId].this_HCONF.hconf1 & INDEX_AVAILABLE_HCONF1) ){
			CurrentCountInPWM_IRQ[       motorId] = countInPWM_noIndex[       motorId] ;
      lastCountInPWM_IRQ[       motorId] = countInPWM_noIndex[       motorId] ;
      indexTrigerd4MissingCecck[motorId] = 0 ;

    }
}


 // printf("microstep %d \n",ee_conFile[motorId].microStep);
  printf("u32_PWMCount %lld \n",step_motor[motorId].this_state->countInPWM_IRQ);
  //displayActual(); 
	
}

void scanOneStep(uint8_t motorId)
{
  uint32_t u32_microStep = ee_conFile[motorId].microStep;
  uint32_t u32_PWMCount = 0;  
  int returnValue  = 0;
  
  u32_PWMCount  = ee_conFile[motorId].fullStep;
  u32_PWMCount *= ee_conFile[motorId].gearRatio;
  u32_PWMCount *= step_motor[motorId].this_state->scan_step * u32_microStep * ee_conFile[motorId].resolution;

  step_motor[motorId].this_state->countInPWM_IRQ = u32_PWMCount * 2;
  
  setDirection( motorId); 
	if(0 == motorId){
		 step_motor[motorId].this_state->miniState.speedSet = ee_conFile[motorId].minSpeedSlow;
	}
  setSpeed_PWM(motorId);
  //outPluse(motorId,0); 
  returnValue = stepper_Start(step_motor[motorId].pul_channel);
	printf("PWMCount 1step %lld \n",step_motor[motorId].this_state->countInPWM_IRQ);
//  printf("valueActual %f \n",step_motor[motorId].this_state->miniState.valueActual);	
  if(-1 ==returnValue){
    start_state(motorId);
  }
  
}
void scanOneStep_withSlave(uint8_t motorId)
{
  uint32_t u32_microStep = ee_conFile[motorId].microStep;
  uint32_t u32_PWMCount = 0;  
  int returnValue  = 0;  
  u32_PWMCount  = ee_conFile[motorId].fullStep;
  u32_PWMCount *= ee_conFile[motorId].gearRatio;
  u32_PWMCount *= step_motor[motorId].this_state->scan_step * u32_microStep * ee_conFile[motorId].resolution;

  step_motor[motorId].this_state->countInPWM_IRQ = u32_PWMCount * 2;
 // printf("%lld\n",step_motor[masterSlaveStruct.master_ch].this_state->countInPWM_IRQ);	 
 // printf("%lld\n",step_motor[masterSlaveStruct.slave_ch].this_state->countInPWM_IRQ);	 
  setDirection( motorId); 
  setSpeed_PWM(motorId);
  
  //am I slave or master?
  if(motorId == masterSlaveStruct.master_ch){
    masterSlaveStruct.master_ready = CHANNEL_READY;
    printf("m ready\n");	
  }else{
    masterSlaveStruct.slave_ready = CHANNEL_READY;
    printf("s ready\n");	
  }

  if((CHANNEL_READY == masterSlaveStruct.master_ready)&&(CHANNEL_READY == masterSlaveStruct.slave_ready)){
      masterSlaveStruct.master_ready = CHANNEL_NOTREADY;
      masterSlaveStruct.slave_ready = CHANNEL_NOTREADY;  

      outPluse(masterSlaveStruct.master_ch,0);        
      outPluse(masterSlaveStruct.slave_ch,0); 	
		  
      returnValue = stepper_Start(step_motor[masterSlaveStruct.master_ch].pul_channel);
      if(-1 == returnValue){
        start_state(masterSlaveStruct.master_ch);
      }
      returnValue = stepper_Start(step_motor[masterSlaveStruct.slave_ch].pul_channel);
      if(-1 == returnValue){
        start_state(masterSlaveStruct.slave_ch);
      }
      // master and slave are moving, so ENABLE output is low, other device should wait. 

  }  
}             
void scanOneStep_withSlave_enable(uint8_t motorId)
{
  uint32_t u32_microStep = ee_conFile[motorId].microStep;
  uint32_t u32_PWMCount = 0;  
  int returnValue  = 0;    
  u32_PWMCount  = ee_conFile[motorId].fullStep;
  u32_PWMCount *= ee_conFile[motorId].gearRatio;
  u32_PWMCount *= step_motor[motorId].this_state->scan_step * u32_microStep * ee_conFile[motorId].resolution;

  step_motor[motorId].this_state->countInPWM_IRQ = u32_PWMCount * 2;
 // printf("%lld\n",step_motor[masterSlaveStruct.master_ch].this_state->countInPWM_IRQ);	 
 // printf("%lld\n",step_motor[masterSlaveStruct.slave_ch].this_state->countInPWM_IRQ);	 
  setDirection( motorId); 
  setSpeed_PWM(motorId);
  
  if((CHANNEL_READY == masterSlaveStruct.master_ready)&&(CHANNEL_READY == masterSlaveStruct.slave_ready)){
      masterSlaveStruct.master_ready = CHANNEL_NOTREADY;
      masterSlaveStruct.slave_ready = CHANNEL_NOTREADY;  

      outPluse(masterSlaveStruct.master_ch,0);        
      outPluse(masterSlaveStruct.slave_ch,0); 	
		  
      returnValue = stepper_Start(step_motor[masterSlaveStruct.master_ch].pul_channel);
      if(-1 == returnValue){
        start_state(masterSlaveStruct.master_ch);
      }      
      returnValue = stepper_Start(step_motor[masterSlaveStruct.slave_ch].pul_channel);
      if(-1 == returnValue){
        start_state(masterSlaveStruct.slave_ch);
      }

      // master and slave are moving, so ENABLE output is low, other device should wait. 

  }  
} 

void stateMachine(uint8_t motorId)
{
  float fDifference = 0.0;
  unsigned int u32_stateTemp = step_motor[motorId].this_state->stateMachine; 
  uint32_t u32_microStep = ee_conFile[motorId].microStep;
  uint32_t u32_PWMCount = 0;  
  switch ( u32_stateTemp)
  {

    case STEP_STOP:
    				stepper_Stop(step_motor[motorId].pul_channel);
    break;
    //以下状态机针�?? SCAN_ENBA模式
    case (STEP_STEP_SCAN | STEP_STOP | STEP_MOVE2_POSITION | STEP_STEP_SCAN_ENAB )://
        fDifference = fabs(step_motor[motorId].this_state->scan_start - step_motor[motorId].this_state->miniState.valueActual);
		    if (fDifference < ee_conFile[motorId].resolution){//刚进�??SCAN，判断start1==position
          step_motor[motorId].this_state->stateMachine &= ~STEP_MOVE2_POSITION;
        }
        else{
          step_motor[motorId].this_state->miniState.valueSet = step_motor[motorId]. this_state->scan_start ;
          move2Postion(motorId);
          step_motor[motorId].this_state->stateMachine &= ~STEP_STOP;
        }   
    break;
    case (STEP_STEP_SCAN | STEP_MOVE2_POSITION | STEP_STEP_SCAN_ENAB):
          //checkCollision(motorId);
          //checkUplimtSignal(motorId);
          //checkLowlimtSignal(motorId);
    break;  
    case (STEP_STEP_SCAN | STEP_STOP | STEP_STEP_SCAN_ENAB):
          
          fDifference = step_motor[motorId]. this_state->scan_stop - step_motor[motorId].this_state->miniState.valueActual - step_motor[motorId].this_state->scan_step*ee_conFile[motorId].resolution ;
          if( fDifference > ee_conFile[motorId].resolution){
            step_motor[motorId].this_state->miniState.valueSet = step_motor[motorId]. this_state->scan_stop ;
            step_motor[motorId].this_state->scanMode = step_motor[motorId].this_state->scanMode_Shadow;
            step_motor[motorId].this_state->stateMachine &= ~STEP_STOP;

            u32_PWMCount  = ee_conFile[motorId].fullStep;
            u32_PWMCount *= ee_conFile[motorId].gearRatio;
            u32_PWMCount *= step_motor[motorId].this_state->scan_step * u32_microStep * ee_conFile[motorId].resolution;
            step_motor[motorId].this_state->countInPWM_IRQ = u32_PWMCount * 2;
            if(motorId == masterSlaveStruct.master_ch){
              masterSlaveStruct.master_ready = CHANNEL_READY;
            }else{
              masterSlaveStruct.slave_ready = CHANNEL_READY;
            }
          }
          else{
            step_motor[motorId].this_state->stateMachine = STEP_STOP;
          }
    break;
    case (STEP_STEP_SCAN  | STEP_STEP_SCAN_ENAB ):
          if( (1 == step_motor[motorId].this_state->enable_triggered)//检测到触发信号
						&&( STATE_IDLE_OR_NOT ==  ( STATE_IDLE_OR_NOT & step_motor[motorId].this_state->miniState.state ) )//  
            &&( HAL_GPIO_ReadPin(GPIO_input_enable_port[motorId],GPIO_input_enable_pin[motorId]) == KEY_ON )) {// enable is high
            
              if( NO_SLAVE == masterSlaveStruct.slave_exist){
                step_motor[motorId].this_state->scanMode = 0;
                step_motor[motorId].this_state->enable_triggered = 0;    
                scanOneStep(motorId);
              }else{
                step_motor[masterSlaveStruct.master_ch].this_state->scanMode = 0;
                step_motor[masterSlaveStruct.slave_ch].this_state->scanMode = 0;                
                step_motor[masterSlaveStruct.master_ch].this_state->enable_triggered = 0;
                step_motor[masterSlaveStruct.slave_ch].this_state->enable_triggered = 0;          
                scanOneStep_withSlave_enable(motorId);              
              }            
          }else{
              if(SLAVE_EXIST == masterSlaveStruct.slave_exist){
                if((CHANNEL_READY == masterSlaveStruct.master_ready)&&(CHANNEL_READY == masterSlaveStruct.slave_ready)){
                  outPluse(masterSlaveStruct.master_ch,1);        
                  outPluse(masterSlaveStruct.slave_ch,1); 
                }  
              }else{
                if(STATE_IDLE_OR_NOT ==(  STATE_IDLE_OR_NOT & step_motor[motorId].this_state->miniState.state))
                   outPluse(motorId,1);        
              }             
          }
    break;
  default:
    break;
  }
}

// find home is for:
// SIG_1 is home( one signal or two signals)
// Sig_1 is low/up limitaion signal
void findHome_switch(uint8_t motorId)
{
  unsigned char homeMode = motor_Home_Sig_Sturct[motorId].homeMode;
  switch (homeMode)
  {
    case  ( HOME_HOME_INDEX ):
          fd_home_index_miniSwich( motorId );
    break;
   case  ( HOME_LOW_INDEX ):
          fd_low_index_miniSwich( motorId );
    break;
    case  ( HOME_UPPER_INDEX ):
          fd_up_index_miniSwich( motorId );
    break;
    case  ( HOME_LOLIMT_VALUE ):
          fd_lowlimit_itsValue_miniSwich( motorId );
    break;
 /*     case  ( HOME_UPLIMT_VALUE ):
          fd_uplimit_itsValue_miniSwich( motorId );
    break;
   case  ( HOME_HOME_NONE ):
          fd_home_none_miniSwich( motorId );
    break;*/

    case  ( HOME_LIMT_LIMT ):
          fd_limt_limt_miniSwich( motorId );
    break;
 /*
    case  ( HOME_NONE_NONE ):
          fd_none_none_miniSwich( motorId );
    break;*/
            
  default:
    break;
  }
}

void fd_home_index_miniSwich(uint8_t motorId )
{
  unsigned int u32_stateTemp = step_motor[motorId].this_state->stateMachine; 
  int returnValue  = 0; 
  uint16_t limit_As_Home = 0;
  limit_As_Home = LOW_AS_HOME_AVAILABLE_HCONF1|
                  UP_AS_HOME_AVAILABLE_HCONF1;
  if( 0 != (ee_conFile[motorId].this_HCONF.hconf1 & limit_As_Home)){
  switch (u32_stateTemp)
  {
      // if HOME is limit signal, then same as   home_index_miniSwich();

    case ( STEP_FINDINGHOME | STEP_STOP )://move to signal with minimun speed
         // direction confirming:  
        setDirectionForFindingHome(motorId);
         //speed setting: Minimunspeed
        step_motor[motorId].this_state->miniState.speedSet = ee_conFile[motorId].minSpeedSlow;
        setSpeed_PWM(motorId);
        //Target position setting: 
        if(  motor_Home_Sig_Sturct[motorId].direction  == UP){
            if(fabs(ee_conFile[motorId].upperLimitation) < ee_conFile[motorId].resolution){
                step_motor[motorId].this_state->miniState.valueSet = con_MaxUpLimitation;
            }else{
                step_motor[motorId].this_state->miniState.valueSet = 2* ee_conFile[motorId].upperLimitation;
            } 
        }
        else{
            if(fabs(ee_conFile[motorId].lowerLimitation) < ee_conFile[motorId].resolution){
                step_motor[motorId].this_state->miniState.valueSet = con_minlowLimitation;
            }else{
                step_motor[motorId].this_state->miniState.valueSet = 2* ee_conFile[motorId].lowerLimitation;
            }
        }
        setCounts_PWM(motorId);
        step_motor[motorId].this_state->stateMachine =  STEP_FINDINGHOME | STEP_DIRECTION_FIRST;
        returnValue  = stepper_Start(step_motor[motorId].pul_channel);
        if(-1 ==returnValue){
          start_state(motorId);
        }

    break;
    case ( STEP_FINDINGHOME | STEP_DIRECTION_FIRST )://waiting for sig1
         if(*motor_Home_Sig_Sturct[motorId].pu16_signal1 == 1){
           *motor_Home_Sig_Sturct[motorId].pu16_signal1 = 0;
           if(HAL_GPIO_ReadPin(motor_Home_Sig_Sturct[motorId].gpio_sig1_port,motor_Home_Sig_Sturct[motorId].gpio_sig1_pin) == motor_Home_Sig_Sturct[motorId].sig1_level){ //signal1 shows up,
            stepper_Stop(step_motor[motorId].pul_channel);
           //direction is always UP!!! then to wati for the sig1 to be disappeared
            if(fabs(ee_conFile[motorId].upperLimitation) < ee_conFile[motorId].resolution){
                step_motor[motorId].this_state->miniState.valueSet = con_MaxUpLimitation;
            }else{
                step_motor[motorId].this_state->miniState.valueSet = 2* ee_conFile[motorId].upperLimitation;
            }             
            setDirection(motorId); 
            setCounts_PWM(motorId);     

            step_motor[motorId].this_state->miniState.speedSet = ee_conFile[motorId].minSpeedSlow;
            setSpeed_PWM(motorId);   
          
            returnValue  = stepper_Start(step_motor[motorId].pul_channel);
            if(-1 == returnValue){
              start_state(motorId);
              step_motor[motorId].this_state->stateMachine = STEP_FINDINGHOME | STEP_DIRECTION_FIRST | STEP_WAIT_SIG1_DISAPPEAR;
            }

           }
         }
    break;
    case ( STEP_FINDINGHOME | STEP_DIRECTION_FIRST | STEP_STOP )://normally ,this case should not to be reached
           step_motor[motorId].this_state->stateMachine = STEP_FINDINGHOME | STEP_DIRECTION_FIRST ;
    break;

    case ( STEP_FINDINGHOME | STEP_DIRECTION_FIRST | STEP_WAIT_SIG1_DISAPPEAR )://
        
        if(*motor_Home_Sig_Sturct[motorId].pu16_signal1 == 1){
           *motor_Home_Sig_Sturct[motorId].pu16_signal1 =  0; 
            if(HAL_GPIO_ReadPin(motor_Home_Sig_Sturct[motorId].gpio_sig1_port,motor_Home_Sig_Sturct[motorId].gpio_sig1_pin) != motor_Home_Sig_Sturct[motorId].sig1_level){ // 
            stepper_Stop(step_motor[motorId].pul_channel);
           //direction is always DOWN! then to wati for the sig1 to be showed up
            if(fabs(ee_conFile[motorId].lowerLimitation) < ee_conFile[motorId].resolution){
                step_motor[motorId].this_state->miniState.valueSet = con_minlowLimitation;
            }else{
                step_motor[motorId].this_state->miniState.valueSet = 2* ee_conFile[motorId].lowerLimitation;
            }
            setDirection(motorId);
            setCounts_PWM(motorId);      

            step_motor[motorId].this_state->miniState.speedSet = ee_conFile[motorId].minSpeedSlow;
            setSpeed_PWM(motorId);  
            returnValue  = stepper_Start(step_motor[motorId].pul_channel);
            if(-1 == returnValue){
                start_state(motorId);
                step_motor[motorId].this_state->stateMachine = STEP_FINDINGHOME | STEP_DIRECTION_SECOND | STEP_WAITING_SIG1;
            }
           }          
        }  
    break;
    //20250830 
    case ( STEP_FINDINGHOME | STEP_DIRECTION_FIRST | STEP_WAIT_SIG1_DISAPPEAR | STEP_STOP)://normally ,this case should not to be reached too
     step_motor[motorId].this_state->stateMachine = STEP_FINDINGHOME | STEP_DIRECTION_FIRST | STEP_WAIT_SIG1_DISAPPEAR;
    break;
    case ( STEP_FINDINGHOME | STEP_DIRECTION_SECOND | STEP_WAITING_SIG1  ):
         if(*motor_Home_Sig_Sturct[motorId].pu16_signal1 == 1){
           *motor_Home_Sig_Sturct[motorId].pu16_signal1 = 0;
           if(HAL_GPIO_ReadPin(motor_Home_Sig_Sturct[motorId].gpio_sig1_port,motor_Home_Sig_Sturct[motorId].gpio_sig1_pin) ==  motor_Home_Sig_Sturct[motorId].sig1_level){ //signal1 shows up,         
            stepper_Stop(step_motor[motorId].pul_channel);
            step_motor[motorId].this_state->stateMachine = STEP_FINDINGHOME | STEP_DIRECTION_SECOND | STEP_WAITING_SIG1 | STEP_STOP;
           }
         }     
    break;
    case ( STEP_FINDINGHOME | STEP_DIRECTION_SECOND | STEP_WAITING_SIG1 | STEP_STOP  ):

          stepper_Stop(step_motor[motorId].pul_channel);
          step_motor[motorId].this_state->stateMachine = STEP_STOP;
          //set actualValue  = homevalue and homeAppro = true
          step_motor[motorId].this_state->miniState.valueActual = ee_conFile[motorId].home;
          step_motor[motorId].this_state->miniState.state      |= STATE_APPRO_HOME_OR_NOT;

          step_motor[motorId].this_state->miniState.homeValueApproximate      = (uint32_t)ee_conFile[motorId].home;
          stop_state(motorId);
          #ifdef UART_DEBUG_STP  
					  printf("FDHM Done \n");
		      #endif
    break;
    default:
    break;
  }}
  else{
  switch (u32_stateTemp)
  {
      // if HOME is limit signal, then same as   home_index_miniSwich();
    case ( STEP_FINDINGHOME | STEP_STOP )://move to signal with minimun speed
         // direction confirming:  
        setDirectionForFindingHome(motorId);
         //speed setting: Minimunspeed
        step_motor[motorId].this_state->miniState.speedSet = ee_conFile[motorId].minSpeedSlow;
        setSpeed_PWM(motorId);
        //Target position setting: 
        if(  motor_Home_Sig_Sturct[motorId].direction  == UP){
            if(fabs(ee_conFile[motorId].upperLimitation) < ee_conFile[motorId].resolution){
                step_motor[motorId].this_state->miniState.valueSet = con_MaxUpLimitation;
            }else{
                step_motor[motorId].this_state->miniState.valueSet = 2* ee_conFile[motorId].upperLimitation;
            } 
        }
        else{
            if(fabs(ee_conFile[motorId].lowerLimitation) < ee_conFile[motorId].resolution){
                step_motor[motorId].this_state->miniState.valueSet = con_minlowLimitation;
            }else{
                step_motor[motorId].this_state->miniState.valueSet = 2* ee_conFile[motorId].lowerLimitation;
            }
        }
        setCounts_PWM(motorId);
        step_motor[motorId].this_state->stateMachine =  STEP_FINDINGHOME | STEP_DIRECTION_FIRST;
        returnValue  = stepper_Start(step_motor[motorId].pul_channel);
        *motor_Home_Sig_Sturct[motorId].pu16_signal1 = 0;	
        if(-1 ==returnValue){
          start_state(motorId);
        }
        #ifdef UART_DEBUG_STP   //20250830 for debug
          printf("HM isnt Lmt! \n" );	
        #endif   
    break;
    case ( STEP_FINDINGHOME | STEP_DIRECTION_FIRST )://waiting for sig1
         if(*motor_Home_Sig_Sturct[motorId].pu16_signal1 == 1){
           *motor_Home_Sig_Sturct[motorId].pu16_signal1 = 0;
           if(HAL_GPIO_ReadPin(motor_Home_Sig_Sturct[motorId].gpio_sig1_port,motor_Home_Sig_Sturct[motorId].gpio_sig1_pin) == motor_Home_Sig_Sturct[motorId].sig1_level){ //signal1 shows up,
            stepper_Stop(step_motor[motorId].pul_channel);
           //direction is always UP!!! then to wati for the sig1 to be disappeared
            if(fabs(ee_conFile[motorId].upperLimitation) < ee_conFile[motorId].resolution){
                step_motor[motorId].this_state->miniState.valueSet = con_MaxUpLimitation;
            }else{
                step_motor[motorId].this_state->miniState.valueSet = 2* ee_conFile[motorId].upperLimitation;
            }             
            setDirection(motorId); 
            setCounts_PWM(motorId);     

            step_motor[motorId].this_state->miniState.speedSet = ee_conFile[motorId].minSpeedSlow;
            setSpeed_PWM(motorId);   
   
            returnValue  = stepper_Start(step_motor[motorId].pul_channel);
            if(-1 == returnValue){
              start_state(motorId);
              step_motor[motorId].this_state->stateMachine = STEP_FINDINGHOME | STEP_DIRECTION_FIRST | STEP_WAIT_SIG1_DISAPPEAR;
              #ifdef UART_DEBUG_STP   //20250830 for debug
                printf("moving UP \n" );	
              #endif  
            }

           }
         }
    break;
    case ( STEP_FINDINGHOME | STEP_DIRECTION_FIRST | STEP_STOP )://normally ,this case should not to be reached
           step_motor[motorId].this_state->stateMachine = STEP_FINDINGHOME | STEP_DIRECTION_FIRST ;
    break;

    case ( STEP_FINDINGHOME | STEP_DIRECTION_FIRST | STEP_WAIT_SIG1_DISAPPEAR )://
       // if(*motor_Home_Sig_Sturct[motorId].pu16_signal1 == 1){
       //    *motor_Home_Sig_Sturct[motorId].pu16_signal1 =  0; 
       //     if(HAL_GPIO_ReadPin(motor_Home_Sig_Sturct[motorId].gpio_sig1_port,motor_Home_Sig_Sturct[motorId].gpio_sig1_pin) != motor_Home_Sig_Sturct[motorId].sig1_level){ // 
            stepper_Stop(step_motor[motorId].pul_channel);
           //direction is always DOWN! then to wati for the sig1 to be showed up
            if(fabs(ee_conFile[motorId].lowerLimitation) < ee_conFile[motorId].resolution){
                step_motor[motorId].this_state->miniState.valueSet = con_minlowLimitation;
            }else{
                step_motor[motorId].this_state->miniState.valueSet = 2* ee_conFile[motorId].lowerLimitation;
            }
            step_motor[motorId].this_state->miniState.valueActual + 0.0;
            setDirection(motorId);
            setCounts_PWM(motorId);      
            step_motor[motorId].this_state->miniState.speedSet = ee_conFile[motorId].minSpeedSlow;
            setSpeed_PWM(motorId);  
            returnValue  = stepper_Start(step_motor[motorId].pul_channel);
            *motor_Home_Sig_Sturct[motorId].pu16_signal1 = 0;	
            #ifdef UART_DEBUG_STP   
            #endif 
            if(-1 == returnValue){
                start_state(motorId);
                step_motor[motorId].this_state->stateMachine = STEP_FINDINGHOME | STEP_DIRECTION_SECOND | STEP_WAITING_SIG1;
                #ifdef UART_DEBUG_STP  
                printf(" moving DONW,waiting for HM Dis \n" );	 
                //printf(" waiting for HM Dis  \n" );	
                #endif   
            }
         //  }
         
       // }  
    break;
    case ( STEP_FINDINGHOME | STEP_DIRECTION_FIRST | STEP_WAIT_SIG1_DISAPPEAR | STEP_STOP)://normally ,this case should not to be reached too
     step_motor[motorId].this_state->stateMachine = STEP_FINDINGHOME | STEP_DIRECTION_FIRST | STEP_WAIT_SIG1_DISAPPEAR;
    break;
    case ( STEP_FINDINGHOME | STEP_DIRECTION_SECOND | STEP_WAITING_SIG1  ):
         if(*motor_Home_Sig_Sturct[motorId].pu16_signal1 == 1){
           *motor_Home_Sig_Sturct[motorId].pu16_signal1 = 0;
           if(HAL_GPIO_ReadPin(motor_Home_Sig_Sturct[motorId].gpio_sig1_port,motor_Home_Sig_Sturct[motorId].gpio_sig1_pin) ==  motor_Home_Sig_Sturct[motorId].sig1_level){ //signal1 shows up,         
            stepper_Stop(step_motor[motorId].pul_channel);
            step_motor[motorId].this_state->stateMachine = STEP_FINDINGHOME | STEP_DIRECTION_SECOND | STEP_WAITING_SIG1 | STEP_STOP;
           }
         }
         step_motor[motorId].this_state->stateMachine = STEP_FINDINGHOME | STEP_DIRECTION_SECOND | STEP_WAITING_SIG1 | STEP_STOP;
     
    break;
    //20250830 mode A.1:move to HOME-8mm or degree
    case ( STEP_FINDINGHOME | STEP_DIRECTION_SECOND | STEP_WAITING_SIG1 | STEP_STOP ):
        step_motor[motorId].this_state->miniState.speedSet   = ee_conFile[motorId].minSpeedSlow;
        setSpeed_PWM(motorId); 
        //Always set DOWN direction
        setDirectionForStep(motorId,DOWN);    //20250830:DOWN
        step_motor[motorId].this_state->miniState.valueActual + 0.0;
        step_motor[motorId].this_state->miniState.valueSet =  step_motor[motorId].this_state->miniState.valueActual + 8.0;
        setCounts_PWM(motorId);  
 
        returnValue = stepper_Start(step_motor[motorId].pul_channel);
        if(-1 == returnValue){
          start_state(motorId);   
          step_motor[motorId].this_state->stateMachine    = STEP_HOME | STEP_DIRECTION_SECOND | STEP_WAITING_SIG2 | STEP_WAITING_SIG1 ;  
          #ifdef UART_DEBUG_STP   
          printf(" \n moving DOWN! moving to -8 \n" );	
          //printf(" DOWN moving to -8 " );	
          #endif   
        } 
    break;
    //20250830 mode A.1:from -8 to signal_1
    // When HOME-8 is reached ,the STEP_STOP is added

    case (STEP_HOME | STEP_DIRECTION_SECOND | STEP_WAITING_SIG2 | STEP_WAITING_SIG1 | STEP_STOP )://preparing go to HOME again : UP
          
          if(fabs(ee_conFile[motorId].upperLimitation) < ee_conFile[motorId].resolution){
                step_motor[motorId].this_state->miniState.valueSet = con_MaxUpLimitation;
            }else{
                step_motor[motorId].this_state->miniState.valueSet = 2* ee_conFile[motorId].upperLimitation;
            }             
            setDirectionForStep(motorId,UP);//20250830:UP
            setCounts_PWM(motorId);     
            step_motor[motorId].this_state->miniState.speedSet = ee_conFile[motorId].minSpeedSlow;
            setSpeed_PWM(motorId);   
          
            returnValue  = stepper_Start(step_motor[motorId].pul_channel);
            if(-1 == returnValue){
              start_state(motorId);
              step_motor[motorId].this_state->stateMachine = STEP_FINDINGHOME | STEP_DIRECTION_FIRST | STEP_WAITING_SIG1;
            }
          *motor_Home_Sig_Sturct[motorId].pu16_signal1 = 0;	
          #ifdef UART_DEBUG_STP   
          printf("UP moving to HOME from -8\n" );
          #endif  
          
    break;
    case ( STEP_FINDINGHOME | STEP_DIRECTION_FIRST | STEP_WAITING_SIG1 ): //waiting for sig1
         if(*motor_Home_Sig_Sturct[motorId].pu16_signal1 == 1){
           *motor_Home_Sig_Sturct[motorId].pu16_signal1 = 0;
           if(HAL_GPIO_ReadPin(motor_Home_Sig_Sturct[motorId].gpio_sig1_port,motor_Home_Sig_Sturct[motorId].gpio_sig1_pin) ==  motor_Home_Sig_Sturct[motorId].sig1_level){ //signal1 shows up,         
            stepper_Stop(step_motor[motorId].pul_channel);
            step_motor[motorId].this_state->stateMachine = STEP_FINDINGHOME | STEP_DIRECTION_FIRST | STEP_WAITING_SIG1 | STEP_STOP;
           }
          #ifdef UART_DEBUG_STP   
          printf("HOME triged\n" );	
          #endif   
         }                    
    break;
    //
    case ( STEP_FINDINGHOME | STEP_DIRECTION_FIRST | STEP_WAITING_SIG1 | STEP_STOP  ):
          stepper_Stop(step_motor[motorId].pul_channel);
          step_motor[motorId].this_state->stateMachine = STEP_STOP;
          //set actualValue  = homevalue and homeAppro = true
          step_motor[motorId].this_state->miniState.valueActual = ee_conFile[motorId].home;
          step_motor[motorId].this_state->miniState.state      |= STATE_APPRO_HOME_OR_NOT;
          step_motor[motorId].this_state->miniState.homeValueApproximate      = (uint32_t)ee_conFile[motorId].home;
          stop_state(motorId);
          #ifdef UART_DEBUG_STP  
					  printf("FDHM HM_INDX Done \n");
		      #endif
    break;
    default:
    break;
  }
  }
}

void fd_low_index_miniSwich(uint8_t motorId )
{
  unsigned int u32_stateTemp = step_motor[motorId].this_state->stateMachine;
   
   switch (u32_stateTemp)
   {
    case ( STEP_FINDINGHOME | STEP_STOP )://because lowlimit's direction  is known. to signal_1 = low  
      if(HAL_GPIO_ReadPin(motor_Home_Sig_Sturct[motorId].gpio_sig1_port,motor_Home_Sig_Sturct[motorId].gpio_sig1_pin) == motor_Home_Sig_Sturct[motorId].sig1_level){// now  is at low.
        step_motor[motorId].this_state->stateMachine = STEP_FINDINGHOME | STEP_DIRECTION_FIRST ;
      }else{
      //step_motor[motorId].this_state->miniState.speedSet = ee_conFile[motorId].maxSpeedFast;
      step_motor[motorId].this_state->miniState.speedSet = ee_conFile[motorId].minSpeedSlow;

      //Always set negtive direction
      setDirectionForStep(motorId,LOW);  
      step_motor[motorId].this_state->miniState.valueSet = con_minlowLimitation;
      step_motor[motorId].this_state->stateMachine = STEP_FINDINGHOME | STEP_DIRECTION_FIRST;
      move2Postion(motorId);
      #ifdef UART_DEBUG_STP   
        printf("valueact:%f",step_motor[motorId].this_state->miniState.valueActual );	
        printf("valueSet:%f",step_motor[motorId].this_state->miniState.valueSet );				
      #endif       
      }        
    break; 
    case ( STEP_FINDINGHOME | STEP_DIRECTION_FIRST )://
      if(HAL_GPIO_ReadPin(motor_Home_Sig_Sturct[motorId].gpio_sig1_port,motor_Home_Sig_Sturct[motorId].gpio_sig1_pin) == motor_Home_Sig_Sturct[motorId].sig1_level){// if signal_1 = lowLimit is triggered  
        stepper_Stop(step_motor[motorId].pul_channel);
        u8_triggerTrail ++;
        if(u8_triggerTrail < con_maxTriggerTrail + 1){
          lowSignalValue[u8_triggerTrail - 1] = step_motor[motorId].this_state->miniState.valueActual;
          step_motor[motorId].this_state->miniState.speedSet = ee_conFile[motorId].minSpeedSlow;
          setDirectionForStep(motorId,UP);  
          step_motor[motorId].this_state->miniState.valueSet = con_MaxUpLimitation;
          step_motor[motorId].this_state->stateMachine = STEP_FINDINGHOME | STEP_PRE;
          move2Postion(motorId);         
          #ifdef UART_DEBUG_STP   
            printf("u8_triggerTrail:%d\n",u8_triggerTrail );
            displayStateMachine( motorId);	
          #endif 
        }
        if(u8_triggerTrail == con_maxTriggerTrail){
        // find the biggest one in lowSignalValue[],then move to there
          step_motor[motorId].this_state->miniState.valueSet = findmin(lowSignalValue,con_maxTriggerTrail);
          step_motor[motorId].this_state->miniState.speedSet = ee_conFile[motorId].minSpeedSlow;  
          move2Postion(motorId); 
          step_motor[motorId].this_state->stateMachine =  STEP_FINDINGHOME | STEP_DIRECTION_FIRST;  
          #ifdef UART_DEBUG_STP   
            printf("min:%f\n",findmin(lowSignalValue,con_maxTriggerTrail));	
            printf("valueact:%f",step_motor[motorId].this_state->miniState.valueActual );	
            displayStateMachine( motorId);
          #endif   
        }
        if(u8_triggerTrail > con_maxTriggerTrail ){
           #ifdef UART_DEBUG_STP   
            printf("slowly to signal1 \n");	
          #endif          
        }
      }
    break; 

    case ( STEP_FINDINGHOME | STEP_PRE )://  
      if(HAL_GPIO_ReadPin(motor_Home_Sig_Sturct[motorId].gpio_sig1_port,motor_Home_Sig_Sturct[motorId].gpio_sig1_pin) != motor_Home_Sig_Sturct[motorId].sig1_level){
          stepper_Stop(step_motor[motorId].pul_channel);
          step_motor[motorId].this_state->miniState.speedSet = ee_conFile[motorId].minSpeedSlow;
          //Always set negtive direction
          setDirectionForStep(motorId,LOW);  
          step_motor[motorId].this_state->miniState.valueSet = con_minlowLimitation;
          step_motor[motorId].this_state->stateMachine = STEP_FINDINGHOME | STEP_DIRECTION_FIRST;
          move2Postion(motorId);
          #ifdef UART_DEBUG_STP   
            printf("valueact:%f",step_motor[motorId].this_state->miniState.valueActual );	
            printf("valueSet:%f",step_motor[motorId].this_state->miniState.valueSet );				
          #endif 
      }
    break; 

    case (STEP_FINDINGHOME | STEP_DIRECTION_FIRST | STEP_STOP ):
       if(HAL_GPIO_ReadPin(motor_Home_Sig_Sturct[motorId].gpio_sig1_port,motor_Home_Sig_Sturct[motorId].gpio_sig1_pin) == motor_Home_Sig_Sturct[motorId].sig1_level){// if signal_1 = lowLimit is triggered  
          u8_triggerTrail = 0;  
          // tempStart = actualValue;
          // homeAppro = true;
          step_motor[motorId].this_state->miniState.valueActual = ee_conFile[motorId].lowerLimitation;
          step_motor[motorId].this_state->miniState.homeValueApproximate = (int)ee_conFile[motorId].lowerLimitation;
          step_motor[motorId].this_state->miniState.state      |= STATE_APPRO_HOME_OR_NOT;
          step_motor[motorId].this_state->stateMachine          = STEP_STOP;  
           #ifdef UART_DEBUG_STP   
            printf("FDHM_LOW_INDEX done" );	
          #endif       
       }else{
          step_motor[motorId].this_state->miniState.valueSet   += ee_conFile[motorId].resolution;
          step_motor[motorId].this_state->miniState.speedSet    = ee_conFile[motorId].minSpeedSlow;  
          step_motor[motorId].this_state->stateMachine          = STEP_FINDINGHOME | STEP_DIRECTION_FIRST;          
          move2Postion(motorId);  
          printf("FDHM_LOW_INDEX one step" );	
       }
    break;     

    default:
    break;
   }

}
void fd_up_index_miniSwich(uint8_t motorId )
{
  unsigned int u32_stateTemp = step_motor[motorId].this_state->stateMachine;
   
   switch (u32_stateTemp)
   {
    case ( STEP_FINDINGHOME | STEP_STOP )://because up limit's direction  is known. to signal_1 = up  
      if(HAL_GPIO_ReadPin(motor_Home_Sig_Sturct[motorId].gpio_sig1_port,motor_Home_Sig_Sturct[motorId].gpio_sig1_pin) == motor_Home_Sig_Sturct[motorId].sig1_level){// now  is at up
        step_motor[motorId].this_state->stateMachine = STEP_FINDINGHOME | STEP_DIRECTION_FIRST ;
      }else{
      //step_motor[motorId].this_state->miniState.speedSet = ee_conFile[motorId].maxSpeedFast;
      step_motor[motorId].this_state->miniState.speedSet = ee_conFile[motorId].minSpeedSlow;
      
      setDirectionForStep(motorId,UP);  
      step_motor[motorId].this_state->miniState.valueSet = con_MaxUpLimitation;
      step_motor[motorId].this_state->stateMachine = STEP_FINDINGHOME | STEP_DIRECTION_FIRST;
      move2Postion(motorId);
      #ifdef UART_DEBUG_STP   
        printf("valueact:%f",step_motor[motorId].this_state->miniState.valueActual );	
        printf("valueSet:%f",step_motor[motorId].this_state->miniState.valueSet );				
      #endif       
      }        
    break; 
    case ( STEP_FINDINGHOME | STEP_DIRECTION_FIRST )://
      if(HAL_GPIO_ReadPin(motor_Home_Sig_Sturct[motorId].gpio_sig1_port,motor_Home_Sig_Sturct[motorId].gpio_sig1_pin) == motor_Home_Sig_Sturct[motorId].sig1_level){// if signal_1 = uplimit is triggered  
        stepper_Stop(step_motor[motorId].pul_channel);
        u8_triggerTrail ++;
        if(u8_triggerTrail < con_maxTriggerTrail + 1){
          upSignalValue[u8_triggerTrail - 1] = step_motor[motorId].this_state->miniState.valueActual;
          step_motor[motorId].this_state->miniState.speedSet = ee_conFile[motorId].minSpeedSlow;
          setDirectionForStep(motorId,LOW);  
          step_motor[motorId].this_state->miniState.valueSet = con_minlowLimitation;
          step_motor[motorId].this_state->stateMachine = STEP_FINDINGHOME | STEP_PRE;
          move2Postion(motorId);         
          #ifdef UART_DEBUG_STP   
            printf("u8_triggerTrail:%d\n",u8_triggerTrail );
            displayStateMachine( motorId);	
          #endif 
        }
        if(u8_triggerTrail == con_maxTriggerTrail){
        // find the smallest one in upSignalValue[],then move to there
          step_motor[motorId].this_state->miniState.valueSet = findmax(upSignalValue,con_maxTriggerTrail);

          step_motor[motorId].this_state->miniState.speedSet = ee_conFile[motorId].minSpeedSlow;  
          move2Postion(motorId); 
          step_motor[motorId].this_state->stateMachine =  STEP_FINDINGHOME | STEP_DIRECTION_FIRST;  
          #ifdef UART_DEBUG_STP   
            printf("min:%f\n",findmin(upSignalValue,con_maxTriggerTrail));	
            printf("valueact:%f",step_motor[motorId].this_state->miniState.valueActual );	
            displayStateMachine( motorId);
          #endif   
        }
        if(u8_triggerTrail > con_maxTriggerTrail ){
       /*    #ifdef UART_DEBUG_STP   
            printf("slowly to signal1 \n");	
          #endif          */
          u8_triggerTrail = u8_triggerTrail;
        }
      }
    break; 

    case ( STEP_FINDINGHOME | STEP_PRE )://  
      if(HAL_GPIO_ReadPin(motor_Home_Sig_Sturct[motorId].gpio_sig1_port,motor_Home_Sig_Sturct[motorId].gpio_sig1_pin) != motor_Home_Sig_Sturct[motorId].sig1_level){
          stepper_Stop(step_motor[motorId].pul_channel);
          step_motor[motorId].this_state->miniState.speedSet = ee_conFile[motorId].minSpeedSlow;
          //Always set UP direction
          setDirectionForStep(motorId,UP);  
          step_motor[motorId].this_state->miniState.valueSet = con_MaxUpLimitation;
          step_motor[motorId].this_state->stateMachine = STEP_FINDINGHOME | STEP_DIRECTION_FIRST;
          move2Postion(motorId);
          #ifdef UART_DEBUG_STP   
            printf("valueact:%f\n",step_motor[motorId].this_state->miniState.valueActual );	
            printf("valueSet:%f\n",step_motor[motorId].this_state->miniState.valueSet );				
          #endif 
      }
    break; 

    case (STEP_FINDINGHOME | STEP_DIRECTION_FIRST | STEP_STOP ):
       if(HAL_GPIO_ReadPin(motor_Home_Sig_Sturct[motorId].gpio_sig1_port,motor_Home_Sig_Sturct[motorId].gpio_sig1_pin) == motor_Home_Sig_Sturct[motorId].sig1_level){// if signal_1  is triggered  
      //   if(1 == homeFinalStep[motorId]){
       //   homeFinalStep[motorId] = 0;
          u8_triggerTrail = 0;  
          // tempStart = actualValue;
          // homeAppro = true;
          step_motor[motorId].this_state->miniState.valueActual = ee_conFile[motorId].upperLimitation;
          step_motor[motorId].this_state->miniState.state      |= STATE_APPRO_HOME_OR_NOT;
          step_motor[motorId].this_state->stateMachine          = STEP_STOP;  
          step_motor[motorId].this_state->miniState.homeValueApproximate = ( int)ee_conFile[motorId].upperLimitation;
          stop_state(motorId);
           #ifdef UART_DEBUG_STP   
            printf("FDHM_UP_INDEX done\n" );	
          #endif       
       }else{
          step_motor[motorId].this_state->miniState.valueSet   += 5*ee_conFile[motorId].resolution;
          step_motor[motorId].this_state->miniState.speedSet    = ee_conFile[motorId].minSpeedSlow;  
          step_motor[motorId].this_state->stateMachine          = STEP_FINDINGHOME | STEP_DIRECTION_FIRST;          
          move2Postion(motorId);  
          printf("FDHM_UP_INDEX one step" );	
       }
    break;     

    default:
    break;
   }
}
void fd_lowlimit_itsValue_miniSwich(uint8_t motorId ){
 //  This function is added on 12 Oct.
 //  step 1. move to the lower sigal
 //  step 2. stop. Assign the lower value to the actual value.
 //  step 3. 
  unsigned int u32_stateTemp = step_motor[motorId].this_state->stateMachine;
  int returnValue  = 0; 
switch (u32_stateTemp)
   {
    case ( STEP_FINDINGHOME | STEP_STOP ):// move to the lower sig1 
      if(HAL_GPIO_ReadPin(motor_Home_Sig_Sturct[motorId].gpio_sig1_port,motor_Home_Sig_Sturct[motorId].gpio_sig1_pin) == motor_Home_Sig_Sturct[motorId].sig1_level){// 
			if( LOW_AS_HOME_AVAILABLE_HCONF1 == (ee_conFile[motorId].this_HCONF.hconf1 & LOW_AS_HOME_AVAILABLE_HCONF1)){
        #ifdef UART_DEBUG_STP   
          printf("FDHM: on port %d.  ",motorId);
          printf("Low  triggerd.");
        #endif  
      }else{
        #ifdef UART_DEBUG_STP   
          printf("FDHM: on port %d.  ",motorId);
          printf("Up  triggerd.");
        #endif  
      }          
        step_motor[motorId].this_state->stateMachine = STEP_FINDINGHOME | STEP_DIRECTION_FIRST ;
      }else{
      step_motor[motorId].this_state->miniState.speedSet = ee_conFile[motorId].minSpeedSlow;
      
			if( LOW_AS_HOME_AVAILABLE_HCONF1 == (ee_conFile[motorId].this_HCONF.hconf1 & LOW_AS_HOME_AVAILABLE_HCONF1)){
        setDirectionForStep(motorId,LOW);  
        step_motor[motorId].this_state->miniState.valueSet = con_minlowLimitation;
        #ifdef UART_DEBUG_STP   
          printf("valueact:%f",step_motor[motorId].this_state->miniState.valueActual );	
          printf("valueSet:%f",step_motor[motorId].this_state->miniState.valueSet );		
          printf("FDHM: on port %d. ",motorId);
        #endif  
      }else{
        setDirectionForStep(motorId,UP);  
        step_motor[motorId].this_state->miniState.valueSet = con_MaxUpLimitation;
        #ifdef UART_DEBUG_STP   
          printf("valueact:%f",step_motor[motorId].this_state->miniState.valueActual );	
          printf("valueSet:%f",step_motor[motorId].this_state->miniState.valueSet );		
          printf("FDHM: on port %d.  ",motorId);
        #endif  
      }
      step_motor[motorId].this_state->stateMachine = STEP_FINDINGHOME | STEP_DIRECTION_FIRST;
      move2Postion(motorId);  
      }        
    break; 

    case ( STEP_FINDINGHOME | STEP_DIRECTION_FIRST ):// stop and assin value.
         if(HAL_GPIO_ReadPin(motor_Home_Sig_Sturct[motorId].gpio_sig1_port,motor_Home_Sig_Sturct[motorId].gpio_sig1_pin) == motor_Home_Sig_Sturct[motorId].sig1_level){// 
			if( LOW_AS_HOME_AVAILABLE_HCONF1 == (ee_conFile[motorId].this_HCONF.hconf1 & LOW_AS_HOME_AVAILABLE_HCONF1)){
          stepper_Stop(step_motor[motorId].pul_channel);
          step_motor[motorId].this_state->stateMachine          = STEP_STOP;
          step_motor[motorId].this_state->miniState.valueActual = ee_conFile[motorId].home;
          step_motor[motorId].this_state->miniState.state      |= STATE_APPRO_HOME_OR_NOT;
          step_motor[motorId].this_state->miniState.homeValueApproximate      = (uint32_t)ee_conFile[motorId].home;
          stop_state(motorId);
          #ifdef UART_DEBUG_STP  
					  printf("FDHM Done \n");
		      #endif
      }else{      
        
      step_motor[motorId].this_state->miniState.speedSet = ee_conFile[motorId].minSpeedSlow;
			if( LOW_AS_HOME_AVAILABLE_HCONF1 == (ee_conFile[motorId].this_HCONF.hconf1 & LOW_AS_HOME_AVAILABLE_HCONF1)){
        setDirectionForStep(motorId,LOW);  
        step_motor[motorId].this_state->miniState.valueSet = con_minlowLimitation;
        #ifdef UART_DEBUG_STP   
          printf("valueact:%f",step_motor[motorId].this_state->miniState.valueActual );	
          printf("valueSet:%f",step_motor[motorId].this_state->miniState.valueSet );		
          printf("FDHM: on port %d. ",motorId);
        #endif  
      }else{
        setDirectionForStep(motorId,UP);  
        step_motor[motorId].this_state->miniState.valueSet = con_MaxUpLimitation;
        #ifdef UART_DEBUG_STP   
          printf("valueact:%f",step_motor[motorId].this_state->miniState.valueActual );	
          printf("valueSet:%f",step_motor[motorId].this_state->miniState.valueSet );		
          printf("FDHM: on port %d.  ",motorId);
        #endif  
      }
      step_motor[motorId].this_state->stateMachine = STEP_FINDINGHOME | STEP_DIRECTION_FIRST;
      move2Postion(motorId);  
      }      
    break; 

    }

}
}
//20240924 added
void fd_limt_limt_miniSwich(uint8_t motorId)
{
  unsigned int u32_stateTemp = step_motor[motorId].this_state->stateMachine;
  int returnValue  = 0; 

   switch (u32_stateTemp)
   {
    case ( STEP_FINDINGHOME | STEP_STOP ):// move to the fisrt limt sig1 
      if(HAL_GPIO_ReadPin(motor_Home_Sig_Sturct[motorId].gpio_sig1_port,motor_Home_Sig_Sturct[motorId].gpio_sig1_pin) == motor_Home_Sig_Sturct[motorId].sig1_level){// 
			if( LOW_AS_HOME_AVAILABLE_HCONF1 == (ee_conFile[motorId].this_HCONF.hconf1 & LOW_AS_HOME_AVAILABLE_HCONF1)){
        #ifdef UART_DEBUG_STP   
          printf("FDHM: on port %d.  ",motorId);
          printf("Low  triggerd.");
        #endif  
      }else{
        #ifdef UART_DEBUG_STP   
          printf("FDHM: on port %d.  ",motorId);
          printf("Up  triggerd.");
        #endif  
      }          
        step_motor[motorId].this_state->stateMachine = STEP_FINDINGHOME | STEP_DIRECTION_FIRST ;
      }else{
      step_motor[motorId].this_state->miniState.speedSet = ee_conFile[motorId].minSpeedSlow;
      
			if( LOW_AS_HOME_AVAILABLE_HCONF1 == (ee_conFile[motorId].this_HCONF.hconf1 & LOW_AS_HOME_AVAILABLE_HCONF1)){
        setDirectionForStep(motorId,LOW);  
        step_motor[motorId].this_state->miniState.valueSet = con_minlowLimitation;
        #ifdef UART_DEBUG_STP   
          printf("valueact:%f",step_motor[motorId].this_state->miniState.valueActual );	
          printf("valueSet:%f",step_motor[motorId].this_state->miniState.valueSet );		
          printf("FDHM: on port %d. ",motorId);
        #endif  
      }else{
        setDirectionForStep(motorId,UP);  
        step_motor[motorId].this_state->miniState.valueSet = con_MaxUpLimitation;
        #ifdef UART_DEBUG_STP   
          printf("valueact:%f",step_motor[motorId].this_state->miniState.valueActual );	
          printf("valueSet:%f",step_motor[motorId].this_state->miniState.valueSet );		
          printf("FDHM: on port %d.  ",motorId);
        #endif  
      }
      step_motor[motorId].this_state->stateMachine = STEP_FINDINGHOME | STEP_DIRECTION_FIRST;
      move2Postion(motorId);  
      }        
    break; 

    case ( STEP_FINDINGHOME | STEP_DIRECTION_FIRST )://waiting for sig1 disapear
         if(*motor_Home_Sig_Sturct[motorId].pu16_signal1 == 1){ //sig1 triggered
           *motor_Home_Sig_Sturct[motorId].pu16_signal1 = 0;
           if(HAL_GPIO_ReadPin(motor_Home_Sig_Sturct[motorId].gpio_sig1_port,motor_Home_Sig_Sturct[motorId].gpio_sig1_pin) == motor_Home_Sig_Sturct[motorId].sig1_level){ //signal1 shows up,
             stepper_Stop(step_motor[motorId].pul_channel); 
            // if LowLimt is home, continue to move to the low direction 
			     if( LOW_AS_HOME_AVAILABLE_HCONF1 == (ee_conFile[motorId].this_HCONF.hconf1 & LOW_AS_HOME_AVAILABLE_HCONF1)){
              step_motor[motorId].this_state->miniState.valueSet = con_minlowLimitation;
           } 
          // if uplimt is home, continue to move to the up direction            
			     if( UP_AS_HOME_AVAILABLE_HCONF1 == (ee_conFile[motorId].this_HCONF.hconf1 & UP_AS_HOME_AVAILABLE_HCONF1)){
              step_motor[motorId].this_state->miniState.valueSet =con_MaxUpLimitation;
           }  
          setDirection(motorId); 
          setCounts_PWM(motorId);           
          step_motor[motorId].this_state->miniState.speedSet = ee_conFile[motorId].minSpeedSlow;
          setSpeed_PWM(motorId);             
          returnValue  = stepper_Start(step_motor[motorId].pul_channel);
          if(-1 == returnValue){
              start_state(motorId);
              step_motor[motorId].this_state->stateMachine = STEP_FINDINGHOME | STEP_DIRECTION_FIRST | STEP_WAIT_SIG1_DISAPPEAR;
          }
           #ifdef UART_DEBUG_STP   
            printf("valueAct:%f",step_motor[motorId].this_state->miniState.valueActual );	
            printf("valueSet:%f",step_motor[motorId].this_state->miniState.valueSet );		
            printf("waiting for disapear: %d. ",motorId);
           #endif  
          }
         }// end of case
    break;
    case ( STEP_FINDINGHOME | STEP_DIRECTION_FIRST | STEP_WAIT_SIG1_DISAPPEAR )://is Sig1 is disapeared, then move to the other direction
        if(*motor_Home_Sig_Sturct[motorId].pu16_signal1 == 1){
           *motor_Home_Sig_Sturct[motorId].pu16_signal1 =  0; 
            if(HAL_GPIO_ReadPin(motor_Home_Sig_Sturct[motorId].gpio_sig1_port,motor_Home_Sig_Sturct[motorId].gpio_sig1_pin) != motor_Home_Sig_Sturct[motorId].sig1_level){ // 
            stepper_Stop(step_motor[motorId].pul_channel);
            // if LowLimt is home, now the direction is up 
			     if( LOW_AS_HOME_AVAILABLE_HCONF1 == (ee_conFile[motorId].this_HCONF.hconf1 & LOW_AS_HOME_AVAILABLE_HCONF1)){
              step_motor[motorId].this_state->miniState.valueSet = con_MaxUpLimitation ;
           } 
          // if uplimt is home, now the direction is low            
			     if( UP_AS_HOME_AVAILABLE_HCONF1 == (ee_conFile[motorId].this_HCONF.hconf1 & UP_AS_HOME_AVAILABLE_HCONF1)){
              step_motor[motorId].this_state->miniState.valueSet =con_minlowLimitation;
           } 
            setDirection(motorId);
            setCounts_PWM(motorId);      
            step_motor[motorId].this_state->miniState.speedSet = ee_conFile[motorId].minSpeedSlow;
            setSpeed_PWM(motorId);  
            returnValue  = stepper_Start(step_motor[motorId].pul_channel);
            if(-1 == returnValue){
                start_state(motorId);
                step_motor[motorId].this_state->stateMachine = STEP_FINDINGHOME | STEP_DIRECTION_SECOND | STEP_WAITING_SIG1;
            }
            #ifdef UART_DEBUG_STP   
              printf("valueAct:%f",step_motor[motorId].this_state->miniState.valueActual );	
              printf("valueSet:%f",step_motor[motorId].this_state->miniState.valueSet );		
              printf("waiting for sig1 again: %d. ",motorId);
            #endif             
           }          
        }  
    break;

    case ( STEP_FINDINGHOME | STEP_DIRECTION_SECOND | STEP_WAITING_SIG1  )://waiting for sig1 showed again
         if(*motor_Home_Sig_Sturct[motorId].pu16_signal1 == 1){
           *motor_Home_Sig_Sturct[motorId].pu16_signal1 = 0;
           if(HAL_GPIO_ReadPin(motor_Home_Sig_Sturct[motorId].gpio_sig1_port,motor_Home_Sig_Sturct[motorId].gpio_sig1_pin) ==  motor_Home_Sig_Sturct[motorId].sig1_level){ //signal1 shows up,         
            stepper_Stop(step_motor[motorId].pul_channel);
            step_motor[motorId].this_state->stateMachine = STEP_FINDINGHOME | STEP_DIRECTION_SECOND | STEP_WAITING_SIG1 | STEP_STOP;
           }
           #ifdef UART_DEBUG_STP   
            printf(" sig1 shows again: %d. ",motorId);
          #endif 
         }     
    break;

    case ( STEP_FINDINGHOME | STEP_DIRECTION_SECOND | STEP_WAITING_SIG1 | STEP_STOP  ):// if sig1 is showed again ,then find home finised.
          
          stepper_Stop(step_motor[motorId].pul_channel);
          step_motor[motorId].this_state->stateMachine          = STEP_STOP;
          step_motor[motorId].this_state->miniState.valueActual = ee_conFile[motorId].home;
          step_motor[motorId].this_state->miniState.state      |= STATE_APPRO_HOME_OR_NOT;

          step_motor[motorId].this_state->miniState.homeValueApproximate      = (uint32_t)ee_conFile[motorId].home;
          stop_state(motorId);
          #ifdef UART_DEBUG_STP  
					  printf("FDHM Done \n");
		      #endif
    break;  
    } 

}
void home_swich(uint8_t motorId){//according to the homemode,swich to miniSwich
    
  unsigned char homeMode = motor_Home_Sig_Sturct[motorId].homeMode;
  switch (homeMode)
  {
    case  ( HOME_HOME_INDEX ):
          //home_index_miniSwich( motorId );
          home_index_miniSwich_A1( motorId );//20250830
    break;
    case  ( HOME_LOW_INDEX ):
          low_index_miniSwich( motorId );
    break;
    case  ( HOME_UPPER_INDEX ):
          up_index_miniSwich( motorId );
    break;
    case  ( HOME_HOME_NONE ):
          home_none_miniSwich( motorId );
    break;
    case  ( HOME_UPLIMT_VALUE ):
          uplimit_itsValue_miniSwich( motorId );
    break;
    case  ( HOME_LOLIMT_VALUE ):
          lowlimit_itsValue_miniSwich( motorId );
    break;
    case  ( HOME_LIMT_LIMT ):
          limt_limt_miniSwich( motorId );
    break;
    case  ( HOME_NONE_NONE ):
          none_none_miniSwich( motorId );
    break;
            
  default:
    break;
  }
  

}

void home_index_miniSwich(uint8_t motorId )
{
  unsigned int u32_stateTemp = step_motor[motorId].this_state->stateMachine;
   switch (u32_stateTemp)
   {
    case ( STEP_HOME | STEP_STOP )://because homeapprox is known. to signal_1 = home  
      //go to signal1 = home
      if(HAL_GPIO_ReadPin(motor_Home_Sig_Sturct[motorId].gpio_sig1_port,motor_Home_Sig_Sturct[motorId].gpio_sig1_pin) == motor_Home_Sig_Sturct[motorId].sig1_level){// now  is at home.
        step_motor[motorId].this_state->stateMachine = STEP_HOME | STEP_DIRECTION_FIRST |  STEP_STOP;
      }else{
        home_pre_HOME_PRE(motorId);
      }  
    break;

    case ( STEP_HOME | STEP_PRE | STEP_STOP) :// move to homeValueApproximate-1  
        home_preStop_readyfor_FIRST(motorId);
    break;

    case ( STEP_HOME | STEP_PRE ) :// then the UP/Positive direction must be the home direction.
          /* #ifdef UART_DEBUG_STP   
					   	printf("valueact:%f",step_motor[motorId].this_state->miniState.valueActual );	
              printf("valueSet:%f",step_motor[motorId].this_state->miniState.valueSet );					
		       #endif */
    break;

    case ( STEP_HOME | STEP_DIRECTION_FIRST ):      
      if( HAL_GPIO_ReadPin(motor_Home_Sig_Sturct[motorId].gpio_sig1_port,motor_Home_Sig_Sturct[motorId].gpio_sig1_pin) == motor_Home_Sig_Sturct[motorId].sig1_level ){//signal_1 is triggerd
        stepper_Stop(step_motor[motorId].pul_channel);       
        step_motor[motorId].this_state->stateMachine = STEP_HOME | STEP_DIRECTION_FIRST | STEP_STOP;
      }
    break;
    case ( STEP_HOME | STEP_DIRECTION_FIRST |  STEP_STOP ):// keep going until sig1 disappears      
        if( HAL_GPIO_ReadPin(motor_Home_Sig_Sturct[motorId].gpio_sig1_port,motor_Home_Sig_Sturct[motorId].gpio_sig1_pin) == motor_Home_Sig_Sturct[motorId].sig1_level ){
           home_first_WAIT_SIG1_DIS(motorId);
        }else{
           home_sig1_dnotshow_back2_HOME_PRE(motorId);
        }
    break;
    case ( STEP_HOME | STEP_DIRECTION_FIRST | STEP_WAIT_SIG1_DISAPPEAR ): 
          home_sigDis_SECOND_WAIT_SIG1(motorId);    
    break;
    case ( STEP_HOME | STEP_DIRECTION_SECOND | STEP_WAITING_SIG1 ):  
          home_secondSig1_SECOND_WAIT_SIG2(motorId);                
    break;
    case ( STEP_HOME | STEP_DIRECTION_SECOND |STEP_WAITING_SIG2 ):
       if( HAL_GPIO_ReadPin(motor_Home_Sig_Sturct[motorId].gpio_sig2_port,motor_Home_Sig_Sturct[motorId].gpio_sig2_pin) == motor_Home_Sig_Sturct[motorId].sig2_level ){//signal_2 is triggerd               
        stepper_Stop(step_motor[motorId].pul_channel);  
        // record the homedistance    
        step_motor[motorId].this_state->miniState.homeDistance = step_motor[motorId].this_state->miniState.valueActual - step_motor[motorId].this_state->f_Start_homedistance;      
        step_motor[motorId].this_state->stateMachine           = STEP_STOP;    
        stop_state(motorId); 
        step_motor[motorId].this_state->miniState.valueActual = ee_conFile[motorId].home;
        step_motor[motorId].this_state->miniState.state |= STATE_HOME_OR_NOT;   
        #ifdef UART_DEBUG_STP  
					  printf("HOME_INDEX Done.\n");
		    #endif       
      }          
    break;
	  default:
    break;
   }
}
// added 20250830, for A.1; HOME is not limit
void home_index_miniSwich_A1(uint8_t motorId )
{
  unsigned int u32_stateTemp = step_motor[motorId].this_state->stateMachine;
  
  uint16_t limit_As_Home = 0;
  limit_As_Home = LOW_AS_HOME_AVAILABLE_HCONF1|
                  UP_AS_HOME_AVAILABLE_HCONF1;
  // if HOME is limit signal, then same as   home_index_miniSwich();
  if( 0 != (ee_conFile[motorId].this_HCONF.hconf1 & limit_As_Home)){
switch (u32_stateTemp)
   {
    case ( STEP_HOME | STEP_STOP )://because homeapprox is known. to signal_1 = home  
      //go to signal1 = home
      if(HAL_GPIO_ReadPin(motor_Home_Sig_Sturct[motorId].gpio_sig1_port,motor_Home_Sig_Sturct[motorId].gpio_sig1_pin) == motor_Home_Sig_Sturct[motorId].sig1_level){// now  is at home.
        step_motor[motorId].this_state->stateMachine = STEP_HOME | STEP_DIRECTION_FIRST |  STEP_STOP;
      }else{
        home_pre_HOME_PRE(motorId);
      }  
    break;

    case ( STEP_HOME | STEP_PRE | STEP_STOP) :// move to homeValueApproximate-1  
        home_preStop_readyfor_FIRST(motorId);
    break;

    case ( STEP_HOME | STEP_PRE ) :// then the UP/Positive direction must be the home direction.
          /* #ifdef UART_DEBUG_STP   
					   	printf("valueact:%f",step_motor[motorId].this_state->miniState.valueActual );	
              printf("valueSet:%f",step_motor[motorId].this_state->miniState.valueSet );					
		       #endif */
    break;

    case ( STEP_HOME | STEP_DIRECTION_FIRST ):      
      if( HAL_GPIO_ReadPin(motor_Home_Sig_Sturct[motorId].gpio_sig1_port,motor_Home_Sig_Sturct[motorId].gpio_sig1_pin) == motor_Home_Sig_Sturct[motorId].sig1_level ){//signal_1 is triggerd
        stepper_Stop(step_motor[motorId].pul_channel);       
        step_motor[motorId].this_state->stateMachine = STEP_HOME | STEP_DIRECTION_FIRST | STEP_STOP;
      }
    break;
    case ( STEP_HOME | STEP_DIRECTION_FIRST |  STEP_STOP ):// keep going until sig1 disappears      
        if( HAL_GPIO_ReadPin(motor_Home_Sig_Sturct[motorId].gpio_sig1_port,motor_Home_Sig_Sturct[motorId].gpio_sig1_pin) == motor_Home_Sig_Sturct[motorId].sig1_level ){
           home_first_WAIT_SIG1_DIS(motorId);
        }else{
           home_sig1_dnotshow_back2_HOME_PRE(motorId);
        }
    break;
    case ( STEP_HOME | STEP_DIRECTION_FIRST | STEP_WAIT_SIG1_DISAPPEAR ): 
          home_sigDis_SECOND_WAIT_SIG1(motorId);    
    break;
    case ( STEP_HOME | STEP_DIRECTION_SECOND | STEP_WAITING_SIG1 ):  
          home_secondSig1_SECOND_WAIT_SIG2(motorId);                
    break;
    case ( STEP_HOME | STEP_DIRECTION_SECOND |STEP_WAITING_SIG2 ):
       if( HAL_GPIO_ReadPin(motor_Home_Sig_Sturct[motorId].gpio_sig2_port,motor_Home_Sig_Sturct[motorId].gpio_sig2_pin) == motor_Home_Sig_Sturct[motorId].sig2_level ){//signal_2 is triggerd               
        stepper_Stop(step_motor[motorId].pul_channel);  
        // record the homedistance    
        step_motor[motorId].this_state->miniState.homeDistance = step_motor[motorId].this_state->miniState.valueActual - step_motor[motorId].this_state->f_Start_homedistance;      
        step_motor[motorId].this_state->stateMachine           = STEP_STOP;    
        stop_state(motorId); 
        step_motor[motorId].this_state->miniState.valueActual = ee_conFile[motorId].home;
        step_motor[motorId].this_state->miniState.state |= STATE_HOME_OR_NOT;   
        #ifdef UART_DEBUG_STP  
					  printf("HOME_INDEX Done.\n");
		    #endif       
      }          
    break;
	  default:
    break;
   }

  }else{//if HOME is not limit signal_20250830
  
  switch (u32_stateTemp)
    {
      case ( STEP_HOME | STEP_STOP )://because homeapprox is known. to signal_1 = home  
        //go to signal1 = home
        if(HAL_GPIO_ReadPin(motor_Home_Sig_Sturct[motorId].gpio_sig1_port,motor_Home_Sig_Sturct[motorId].gpio_sig1_pin) == motor_Home_Sig_Sturct[motorId].sig1_level){// now  is at home.
          step_motor[motorId].this_state->stateMachine = STEP_HOME | STEP_DIRECTION_FIRST |  STEP_STOP;
        }else{
          home_pre_HOME_PRE(motorId);
        }  
      break;

      case ( STEP_HOME | STEP_PRE | STEP_STOP) :// move to homeValueApproximate-1  
          home_preStop_readyfor_FIRST(motorId);
      break;

      case ( STEP_HOME | STEP_PRE ) :// then the UP/Positive direction must be the home direction.
            /* #ifdef UART_DEBUG_STP   
                printf("valueact:%f",step_motor[motorId].this_state->miniState.valueActual );	
                printf("valueSet:%f",step_motor[motorId].this_state->miniState.valueSet );					
            #endif */
      break;

      case ( STEP_HOME | STEP_DIRECTION_FIRST ):      
        if( HAL_GPIO_ReadPin(motor_Home_Sig_Sturct[motorId].gpio_sig1_port,motor_Home_Sig_Sturct[motorId].gpio_sig1_pin) == motor_Home_Sig_Sturct[motorId].sig1_level ){//signal_1 is triggerd
          stepper_Stop(step_motor[motorId].pul_channel);       
          step_motor[motorId].this_state->stateMachine = STEP_HOME | STEP_DIRECTION_FIRST | STEP_STOP;
        }
      break;
      case ( STEP_HOME | STEP_DIRECTION_FIRST | STEP_STOP ):// keep going until sig1 disappears      
          if( HAL_GPIO_ReadPin(motor_Home_Sig_Sturct[motorId].gpio_sig1_port,motor_Home_Sig_Sturct[motorId].gpio_sig1_pin) == motor_Home_Sig_Sturct[motorId].sig1_level ){
            home_first_WAIT_SIG1_DIS(motorId);
          }else{
            home_sig1_dnotshow_back2_HOME_PRE(motorId);
          }
      break;
      case ( STEP_HOME | STEP_DIRECTION_FIRST | STEP_WAIT_SIG1_DISAPPEAR ): 
            home_sigDis_SECOND_WAIT_SIG1(motorId); //  moving to signal_1 again 20250830 
      break;
      //20250830 added
      case ( STEP_HOME | STEP_DIRECTION_SECOND | STEP_WAITING_SIG1 ):  
            home_secondSig1_SECOND_WAIT_SIG2_A1(motorId);   // when signal1_trigered, move to HOME -8 20250830
            //  State set is  :                     STEP_HOME | STEP_DIRECTION_SECOND |STEP_WAITING_SIG2 ;  
            //  When -8mm is reached , State is   : STEP_HOME | STEP_DIRECTION_SECOND |STEP_WAITING_SIG2 | STEP_STOP;      
      break;

      case ( STEP_HOME | STEP_DIRECTION_SECOND |STEP_WAITING_SIG2 | STEP_STOP):  
            home_secondSig1_SECOND_WAIT_SIG2(motorId);  
            //  State set is unchanged unless Signal_1 is triggered. 20250830
            //  When Signal is triggerd , State is : STEP_HOME | STEP_DIRECTION_SECOND |STEP_WAITING_SIG2 | STEP_WAITING_SIG1 20250830   
      break;
      // folloing is the same as HOME is LIMIT
      case ( STEP_HOME | STEP_DIRECTION_SECOND |STEP_WAITING_SIG2 | STEP_WAITING_SIG1):
        if( HAL_GPIO_ReadPin(motor_Home_Sig_Sturct[motorId].gpio_sig2_port,motor_Home_Sig_Sturct[motorId].gpio_sig2_pin) == motor_Home_Sig_Sturct[motorId].sig2_level ){//signal_2 is triggerd               
          stepper_Stop(step_motor[motorId].pul_channel);  
          // record the homedistance    
          step_motor[motorId].this_state->miniState.homeDistance = step_motor[motorId].this_state->miniState.valueActual - step_motor[motorId].this_state->f_Start_homedistance;      
          step_motor[motorId].this_state->stateMachine           = STEP_STOP;    
          stop_state(motorId); 
          step_motor[motorId].this_state->miniState.valueActual = ee_conFile[motorId].home;
          step_motor[motorId].this_state->miniState.state |= STATE_HOME_OR_NOT;   
          #ifdef UART_DEBUG_STP  
              printf("HOME_INDEX Done.\n");
          #endif       
        }          
      break;
      default:
      break;
    }
  }
  
  
}

void home_none_miniSwich(uint8_t motorId )
{
  unsigned int u32_stateTemp = step_motor[motorId].this_state->stateMachine; 
  switch (u32_stateTemp)
   {
    case ( STEP_HOME | STEP_STOP )://because homeapprox is known. to signal_1 = home  
      //go to signal1 = home
      if(HAL_GPIO_ReadPin(motor_Home_Sig_Sturct[motorId].gpio_sig1_port,motor_Home_Sig_Sturct[motorId].gpio_sig1_pin) == motor_Home_Sig_Sturct[motorId].sig1_level){// now  is at home.
        step_motor[motorId].this_state->stateMachine = STEP_HOME | STEP_DIRECTION_FIRST |  STEP_STOP;
      }else{
        home_pre_HOME_PRE(motorId);
      }      
    break; 

    case ( STEP_HOME | STEP_PRE | STEP_STOP) :// move to homeValueApproximate-1  
        home_preStop_readyfor_FIRST(motorId);
    break; 
    case ( STEP_HOME | STEP_PRE ) :// then the UP/Positive direction must be the home direction.
          /* #ifdef UART_DEBUG_STP   
					   	printf("valueact:%f",step_motor[motorId].this_state->miniState.valueActual );	
              printf("valueSet:%f",step_motor[motorId].this_state->miniState.valueSet );					
		       #endif */
    break;

    case ( STEP_HOME | STEP_DIRECTION_FIRST )://Waiting for  signal_1 = home
      if( HAL_GPIO_ReadPin(motor_Home_Sig_Sturct[motorId].gpio_sig1_port,motor_Home_Sig_Sturct[motorId].gpio_sig1_pin) == motor_Home_Sig_Sturct[motorId].sig1_level ){//signal_1 is triggerd
        stepper_Stop(step_motor[motorId].pul_channel);       
        step_motor[motorId].this_state->stateMachine = STEP_HOME | STEP_DIRECTION_FIRST | STEP_STOP;
        #ifdef UART_DEBUG_STP   
					printf("home is triggerd fistly" );	
		    #endif         
      }
    break; 

    case ( STEP_HOME | STEP_DIRECTION_FIRST |  STEP_STOP ):// keep going until sig1 disappears ,always positive/UP direction   
        if( HAL_GPIO_ReadPin(motor_Home_Sig_Sturct[motorId].gpio_sig1_port,motor_Home_Sig_Sturct[motorId].gpio_sig1_pin) == motor_Home_Sig_Sturct[motorId].sig1_level ){
           home_first_WAIT_SIG1_DIS(motorId);
        }else{
           home_sig1_dnotshow_back2_HOME_PRE(motorId);
        } 
    break;

    case ( STEP_HOME | STEP_DIRECTION_FIRST | STEP_WAIT_SIG1_DISAPPEAR ):  
       if( HAL_GPIO_ReadPin(motor_Home_Sig_Sturct[motorId].gpio_sig1_port,motor_Home_Sig_Sturct[motorId].gpio_sig1_pin) != motor_Home_Sig_Sturct[motorId].sig1_level ){//signal_1 is disappeared          
        step_motor[motorId].this_state->miniState.speedSet = ee_conFile[motorId].minSpeedSlow;
        //Always set negtive direction
        setDirectionForStep(motorId,DOWN);  
        if(fabs(ee_conFile[motorId].lowerLimitation) < ee_conFile[motorId].resolution){
            step_motor[motorId].this_state->miniState.valueSet = con_minlowLimitation;
        }else{
            step_motor[motorId].this_state->miniState.valueSet = 2* ee_conFile[motorId].lowerLimitation;
        }
        move2Postion(motorId);     
        step_motor[motorId].this_state->stateMachine = STEP_HOME | STEP_DIRECTION_SECOND | STEP_WAITING_SIG1;
         #ifdef UART_DEBUG_STP   
          printf("disappeared" );	
					printf("waiting for showup" );	
		    #endif          
      }   
    break;
    case ( STEP_HOME | STEP_DIRECTION_SECOND | STEP_WAITING_SIG1):  
      if( HAL_GPIO_ReadPin(motor_Home_Sig_Sturct[motorId].gpio_sig1_port,motor_Home_Sig_Sturct[motorId].gpio_sig1_pin) == motor_Home_Sig_Sturct[motorId].sig1_level ){//signal_1 is triggerd
        stepper_Stop(step_motor[motorId].pul_channel);
        stop_state(motorId);               
        step_motor[motorId].this_state->stateMachine =  STEP_STOP;
        step_motor[motorId].this_state->miniState.valueActual = ee_conFile[motorId].home;
        step_motor[motorId].this_state->miniState.state |= STATE_HOME_OR_NOT;   
        #ifdef UART_DEBUG_STP  
					  printf("HOME_NONE Done.\n");
		    #endif 
      }
    break;
    default:
    break;
   }
}
void low_index_miniSwich(uint8_t motorId )
{
  unsigned int u32_stateTemp = step_motor[motorId].this_state->stateMachine;
   
   switch (u32_stateTemp)
   {
    case ( STEP_HOME | STEP_STOP )://because lowlimit's direction  is known. to signal_1 = low  
      if(HAL_GPIO_ReadPin(motor_Home_Sig_Sturct[motorId].gpio_sig1_port,motor_Home_Sig_Sturct[motorId].gpio_sig1_pin) == motor_Home_Sig_Sturct[motorId].sig1_level){// now  is at low.
        step_motor[motorId].this_state->stateMachine = STEP_HOME | STEP_DIRECTION_FIRST ;
      }else{
     // step_motor[motorId].this_state->miniState.speedSet = ee_conFile[motorId].maxSpeedFast;
      step_motor[motorId].this_state->miniState.speedSet = ee_conFile[motorId].minSpeedSlow;

      //Always set negtive direction
      setDirectionForStep(motorId,LOW);  
      step_motor[motorId].this_state->miniState.valueSet = con_minlowLimitation;
      step_motor[motorId].this_state->stateMachine = STEP_HOME | STEP_DIRECTION_FIRST;
      move2Postion(motorId);
      #ifdef UART_DEBUG_STP   
        printf("valueact:%f",step_motor[motorId].this_state->miniState.valueActual );	
        printf("valueSet:%f",step_motor[motorId].this_state->miniState.valueSet );				
      #endif       
      }        
    break; 
    case ( STEP_HOME | STEP_DIRECTION_FIRST )://
      if(HAL_GPIO_ReadPin(motor_Home_Sig_Sturct[motorId].gpio_sig1_port,motor_Home_Sig_Sturct[motorId].gpio_sig1_pin) == motor_Home_Sig_Sturct[motorId].sig1_level){// if signal_1 = lowLimit is triggered  
        stepper_Stop(step_motor[motorId].pul_channel);
        u8_triggerTrail ++;
        if(u8_triggerTrail < con_maxTriggerTrail + 1){

          lowSignalValue[u8_triggerTrail - 1] = step_motor[motorId].this_state->miniState.valueActual;
          step_motor[motorId].this_state->miniState.speedSet = ee_conFile[motorId].minSpeedSlow;
          setDirectionForStep(motorId,UP);  
          step_motor[motorId].this_state->miniState.valueSet = con_MaxUpLimitation;
          step_motor[motorId].this_state->stateMachine = STEP_HOME | STEP_PRE;
          move2Postion(motorId);         
          #ifdef UART_DEBUG_STP   
            printf("u8_triggerTrail:%d",u8_triggerTrail );
            printf("valueact:%f" ,step_motor[motorId].this_state->miniState.valueActual );	
            printf("valueSet:%f\n",step_motor[motorId].this_state->miniState.valueSet );		
          #endif 
        }
        if(u8_triggerTrail == con_maxTriggerTrail){
        // find the biggest one in lowSignalValue[],then move to there
          step_motor[motorId].this_state->miniState.valueSet = findmin(lowSignalValue,con_maxTriggerTrail);
          step_motor[motorId].this_state->miniState.speedSet = ee_conFile[motorId].minSpeedSlow;  
          move2Postion(motorId);  
          step_motor[motorId].this_state->stateMachine =  STEP_HOME | STEP_DIRECTION_FIRST;  

        }
        if(u8_triggerTrail > con_maxTriggerTrail ){
          u8_triggerTrail = u8_triggerTrail;
           #ifdef UART_DEBUG_STP   
            printf("slowly to signal1 \n");	
          #endif          
        }
      }
    break; 

    case ( STEP_HOME | STEP_PRE )://  
      if(HAL_GPIO_ReadPin(motor_Home_Sig_Sturct[motorId].gpio_sig1_port,motor_Home_Sig_Sturct[motorId].gpio_sig1_pin) != motor_Home_Sig_Sturct[motorId].sig1_level){
          stepper_Stop(step_motor[motorId].pul_channel);
          step_motor[motorId].this_state->miniState.speedSet = ee_conFile[motorId].minSpeedSlow;
          //Always set negtive direction
          setDirectionForStep(motorId,LOW);  
          step_motor[motorId].this_state->miniState.valueSet = con_minlowLimitation;
          step_motor[motorId].this_state->stateMachine = STEP_HOME | STEP_DIRECTION_FIRST;
          move2Postion(motorId);
          #ifdef UART_DEBUG_STP   
            printf("valueact:%f",step_motor[motorId].this_state->miniState.valueActual );	
            printf("valueSet:%f",step_motor[motorId].this_state->miniState.valueSet );				
          #endif 
      }
    break; 

    case (STEP_HOME | STEP_DIRECTION_FIRST | STEP_STOP ):
       if(HAL_GPIO_ReadPin(motor_Home_Sig_Sturct[motorId].gpio_sig1_port,motor_Home_Sig_Sturct[motorId].gpio_sig1_pin) == motor_Home_Sig_Sturct[motorId].sig1_level){// if signal_1 = lowLimit is triggered  
          u8_triggerTrail = 0;  
          // tempStart = actualValue;
          // homeAppro = true;
          step_motor[motorId].this_state->miniState.valueActual = ee_conFile[motorId].lowerLimitation;
          f_tempStart                                           = ee_conFile[motorId].lowerLimitation;
          step_motor[motorId].this_state->miniState.state      |= STATE_APPRO_HOME_OR_NOT;
          step_motor[motorId].this_state->stateMachine          = STEP_HOME | STEP_DIRECTION_SECOND;  

          step_motor[motorId].this_state->miniState.speedSet    = ee_conFile[motorId].minSpeedSlow;
          setDirectionForStep(motorId,UP);  
          step_motor[motorId].this_state->miniState.valueSet    = con_MaxUpLimitation;
          move2Postion(motorId); 
       }else{
          step_motor[motorId].this_state->miniState.valueSet   -= 5*ee_conFile[motorId].resolution;
          step_motor[motorId].this_state->miniState.speedSet    = ee_conFile[motorId].minSpeedSlow;  
          step_motor[motorId].this_state->stateMachine          = STEP_HOME | STEP_DIRECTION_FIRST;          
          move2Postion(motorId);  
       }
    break;     
    case ( STEP_HOME | STEP_DIRECTION_SECOND )://    
      //if(HAL_GPIO_ReadPin(motor_Home_Sig_Sturct[motorId].gpio_sig2_port,motor_Home_Sig_Sturct[motorId].gpio_sig2_pin) == motor_Home_Sig_Sturct[motorId].sig2_level){// if signal_2 is trigered
      if(1 == homeFinalStep[motorId]){
       homeFinalStep[motorId] = 0;
      //actualValue = homeValue
      // homedistance = actualValue - tempStart;
      // homeStatus = true;
       step_motor[motorId].this_state->miniState.homeDistance = step_motor[motorId].this_state->miniState.valueActual - f_tempStart;
       step_motor[motorId].this_state->miniState.valueActual  = ee_conFile[motorId].home;
       step_motor[motorId].this_state->miniState.state       |= STATE_HOME_OR_NOT;
       step_motor[motorId].this_state->stateMachine           = STEP_STOP;
       stop_state(motorId);
      #ifdef UART_DEBUG_STP   
        printf("low_index Done.\n" );	
      #endif        
      }
    break; 
    default:
    break;
   }
}
/*
void lowlimit_itsValue_miniSwich(uint8_t motorId )
{
   unsigned int u32_stateTemp = step_motor[motorId].this_state->stateMachine; 
   switch (u32_stateTemp)
   {
    case ( STEP_HOME | STEP_STOP )://because lowlimit's direction  is known. to signal_1 = low  
      if(HAL_GPIO_ReadPin(motor_Home_Sig_Sturct[motorId].gpio_sig1_port,motor_Home_Sig_Sturct[motorId].gpio_sig1_pin) == motor_Home_Sig_Sturct[motorId].sig1_level){// now  is at low.
        step_motor[motorId].this_state->stateMachine = STEP_HOME | STEP_DIRECTION_FIRST ;
      }else{
      step_motor[motorId].this_state->miniState.speedSet = ee_conFile[motorId].maxSpeedFast;
      //Always set negtive direction
      setDirectionForStep(motorId,LOW);  
      step_motor[motorId].this_state->miniState.valueSet = con_minlowLimitation;
      step_motor[motorId].this_state->stateMachine = STEP_HOME | STEP_DIRECTION_FIRST;
      move2Postion(motorId);
      #ifdef UART_DEBUG_STP   
        printf("valueact:%f",step_motor[motorId].this_state->miniState.valueActual );	
        printf("valueSet:%f",step_motor[motorId].this_state->miniState.valueSet );				
      #endif       
      }        
    break; 
    case ( STEP_HOME | STEP_DIRECTION_FIRST )://
      if(HAL_GPIO_ReadPin(motor_Home_Sig_Sturct[motorId].gpio_sig1_port,motor_Home_Sig_Sturct[motorId].gpio_sig1_pin) == motor_Home_Sig_Sturct[motorId].sig1_level){// if signal_1 = lowLimit is triggered  
        stepper_Stop(step_motor[motorId].pul_channel);
        u8_triggerTrail ++;
        if(u8_triggerTrail < con_maxTriggerTrail){

          lowSignalValue[u8_triggerTrail] = step_motor[motorId].this_state->miniState.valueActual;
          step_motor[motorId].this_state->miniState.speedSet = ee_conFile[motorId].minSpeedSlow;
          setDirectionForStep(motorId,UP);  
          step_motor[motorId].this_state->miniState.valueSet = con_MaxUpLimitation;
          step_motor[motorId].this_state->stateMachine = STEP_HOME | STEP_PRE;
          move2Postion(motorId);         
          #ifdef UART_DEBUG_STP   
            printf("u8_triggerTrail:%d\n",u8_triggerTrail );
            printf("valueact:%f " ,step_motor[motorId].this_state->miniState.valueActual );	
            printf("valueSet:%f\n",step_motor[motorId].this_state->miniState.valueSet );		
          #endif 
        }
        if(u8_triggerTrail == con_maxTriggerTrail){
        // find the biggest one in lowSignalValue[],then move to there
          step_motor[motorId].this_state->miniState.valueSet = findmin(lowSignalValue,con_maxTriggerTrail);
          step_motor[motorId].this_state->miniState.speedSet = ee_conFile[motorId].minSpeedSlow;  
          move2Postion(motorId);  
        }
        if(u8_triggerTrail > con_maxTriggerTrail ){
           #ifdef UART_DEBUG_STP   
            printf("slowly to signal1 \n");	
          #endif          
        }
      }
    break; 
    case ( STEP_HOME | STEP_PRE )://  
      if(HAL_GPIO_ReadPin(motor_Home_Sig_Sturct[motorId].gpio_sig1_port,motor_Home_Sig_Sturct[motorId].gpio_sig1_pin) != motor_Home_Sig_Sturct[motorId].sig1_level){
          stepper_Stop(step_motor[motorId].pul_channel);
          step_motor[motorId].this_state->miniState.speedSet = ee_conFile[motorId].minSpeedSlow;
          //Always set negtive direction
          setDirectionForStep(motorId,LOW);  
          step_motor[motorId].this_state->miniState.valueSet = con_minlowLimitation;
          step_motor[motorId].this_state->stateMachine = STEP_HOME | STEP_DIRECTION_FIRST;
          move2Postion(motorId);
          #ifdef UART_DEBUG_STP   
            printf("valueact:%f",step_motor[motorId].this_state->miniState.valueActual );	
            printf("valueSet:%f",step_motor[motorId].this_state->miniState.valueSet );				
          #endif 
      }
    break; 
    case (STEP_HOME | STEP_DIRECTION_FIRST | STEP_STOP ):
       if(HAL_GPIO_ReadPin(motor_Home_Sig_Sturct[motorId].gpio_sig1_port,motor_Home_Sig_Sturct[motorId].gpio_sig1_pin) == motor_Home_Sig_Sturct[motorId].sig1_level){// if signal_1 = lowLimit is triggered  
          u8_triggerTrail = 0;  
          step_motor[motorId].this_state->miniState.valueActual = ee_conFile[motorId].home;
          step_motor[motorId].this_state->miniState.state      |= STATE_APPRO_HOME_OR_NOT;
          step_motor[motorId].this_state->stateMachine          = STEP_HOME | STEP_DIRECTION_SECOND;  

          step_motor[motorId].this_state->miniState.speedSet    = ee_conFile[motorId].minSpeedSlow;
          step_motor[motorId].this_state->miniState.valueSet    = ee_conFile[motorId].lowerLimitation;
          move2Postion(motorId); 
       }else{
          step_motor[motorId].this_state->miniState.valueSet   -= ee_conFile[motorId].resolution;
          step_motor[motorId].this_state->miniState.speedSet    = ee_conFile[motorId].minSpeedSlow;  
          step_motor[motorId].this_state->stateMachine          = STEP_HOME | STEP_DIRECTION_FIRST;          
          move2Postion(motorId);  
       }
    break;   
    case ( STEP_HOME | STEP_DIRECTION_SECOND )://    
      if( fabs(step_motor[motorId].this_state->miniState.valueSet - step_motor[motorId].this_state->miniState.valueActual)<=ee_conFile[motorId].resolution ){// 
      // homeStatus = true;
       step_motor[motorId].this_state->miniState.state       |= STATE_HOME_OR_NOT;
       step_motor[motorId].this_state->miniState.state       |= STATE_APPRO_HOME_OR_NOT;
       step_motor[motorId].this_state->stateMachine           = STEP_STOP;
       stop_state(motorId);
      #ifdef UART_DEBUG_STP   
        printf("low_its Done.\n" );	
      #endif        
      }
    break;
    case ( STEP_HOME | STEP_DIRECTION_SECOND | STEP_STOP)://    
      if( fabs(step_motor[motorId].this_state->miniState.valueSet - step_motor[motorId].this_state->miniState.valueActual)<=ee_conFile[motorId].resolution ){// 
      // homeStatus = true;
       step_motor[motorId].this_state->miniState.state       |= STATE_HOME_OR_NOT;
       step_motor[motorId].this_state->miniState.state       |= STATE_APPRO_HOME_OR_NOT;
       step_motor[motorId].this_state->stateMachine           = STEP_STOP;
       stop_state(motorId);
      #ifdef UART_DEBUG_STP   
        printf("low_its Done.\n" );	
      #endif        
      }else{
          step_motor[motorId].this_state->miniState.speedSet    = ee_conFile[motorId].minSpeedSlow;
          step_motor[motorId].this_state->miniState.valueSet    = ee_conFile[motorId].lowerLimitation;
          move2Postion(motorId);  
          step_motor[motorId].this_state->stateMachine          = STEP_HOME | STEP_DIRECTION_SECOND;        
      }      
   break;
   default:
  break;
   }
}
*/
//20241012
void lowlimit_itsValue_miniSwich(uint8_t motorId )
{
   unsigned int u32_stateTemp = step_motor[motorId].this_state->stateMachine; 
   double tempDouble = 0.0;
   switch (u32_stateTemp)
   {
    case ( STEP_HOME | STEP_STOP )://because lowlimit's direction  is known. to signal_1 = low  
      step_motor[motorId].this_state->miniState.speedSet = ee_conFile[motorId].minSpeedSlow;
      //Always set negtive direction
      setDirectionForStep(motorId,UP);  
      step_motor[motorId].this_state->miniState.valueSet = ee_conFile[motorId].lowerLimitation;
      step_motor[motorId].this_state->stateMachine = STEP_STOP | STEP_DIRECTION_FIRST;
      move2Postion(motorId);
      #ifdef UART_DEBUG_STP   
      //  printf("valueact:%f",step_motor[motorId].this_state->miniState.valueActual );	
       // printf("valueSet:%f",step_motor[motorId].this_state->miniState.valueSet );				
      #endif            
    break; 
    case ( STEP_HOME | STEP_DIRECTION_FIRST ): 
    tempDouble = step_motor[motorId].this_state->miniState.valueActual - ee_conFile[motorId].lowerLimitation;
    if(fabs(tempDouble) < (1e-3)){
       stepper_Stop(step_motor[motorId].pul_channel);
       stop_state(motorId);        
       step_motor[motorId].this_state->stateMachine = STEP_STOP;	
       step_motor[motorId].this_state->miniState.valueActual  = ee_conFile[motorId].home;
       step_motor[motorId].this_state->miniState.state       |= STATE_HOME_OR_NOT;			
    }
		  #ifdef UART_DEBUG_STP   
       // printf("valueact:%f",step_motor[motorId].this_state->miniState.valueActual );	
      #endif  
    break; 
  } 
}
void up_index_miniSwich(uint8_t motorId )
{
  unsigned int u32_stateTemp = step_motor[motorId].this_state->stateMachine; 
   switch (u32_stateTemp)
   {
    case ( STEP_HOME | STEP_STOP )://because UPlimit's direction  is known. to signal_1 = UP  
      if(HAL_GPIO_ReadPin(motor_Home_Sig_Sturct[motorId].gpio_sig1_port,motor_Home_Sig_Sturct[motorId].gpio_sig1_pin) == motor_Home_Sig_Sturct[motorId].sig1_level){// now  is at UP.
        step_motor[motorId].this_state->stateMachine = STEP_HOME | STEP_DIRECTION_FIRST ;
      }else{
      //step_motor[motorId].this_state->miniState.speedSet = ee_conFile[motorId].maxSpeedFast;
      step_motor[motorId].this_state->miniState.speedSet = ee_conFile[motorId].minSpeedSlow;
      //Always set positive direction
      setDirectionForStep(motorId,UP);  
      step_motor[motorId].this_state->miniState.valueSet = con_MaxUpLimitation;
      step_motor[motorId].this_state->stateMachine = STEP_HOME | STEP_DIRECTION_FIRST;
      move2Postion(motorId);
      #ifdef UART_DEBUG_STP   
        printf("valueact:%f",step_motor[motorId].this_state->miniState.valueActual );	
        printf("valueSet:%f",step_motor[motorId].this_state->miniState.valueSet );				
      #endif       
      }        
    break; 

    case ( STEP_HOME | STEP_DIRECTION_FIRST )://
      if(HAL_GPIO_ReadPin(motor_Home_Sig_Sturct[motorId].gpio_sig1_port,motor_Home_Sig_Sturct[motorId].gpio_sig1_pin) == motor_Home_Sig_Sturct[motorId].sig1_level){// if signal_1 = lowLimit is triggered  
        stepper_Stop(step_motor[motorId].pul_channel);
        u8_triggerTrail ++;
        if(u8_triggerTrail < con_maxTriggerTrail + 1){

          upSignalValue[u8_triggerTrail - 1] = step_motor[motorId].this_state->miniState.valueActual;
          step_motor[motorId].this_state->miniState.speedSet = ee_conFile[motorId].minSpeedSlow;
          setDirectionForStep(motorId,LOW);  
          step_motor[motorId].this_state->miniState.valueSet = con_minlowLimitation;
          step_motor[motorId].this_state->stateMachine = STEP_HOME | STEP_PRE;
          move2Postion(motorId);         
          #ifdef UART_DEBUG_STP   
            printf("u8_triggerTrail:%d",u8_triggerTrail );
            printf("valueact:%f" ,step_motor[motorId].this_state->miniState.valueActual );	
            printf("valueSet:%f\n",step_motor[motorId].this_state->miniState.valueSet );		
          #endif 
        }
        if(u8_triggerTrail == con_maxTriggerTrail){
        // find the smallest one in upSignalValue[],then move to there
          step_motor[motorId].this_state->miniState.valueSet = findmin(upSignalValue,con_maxTriggerTrail);
          step_motor[motorId].this_state->miniState.speedSet = ee_conFile[motorId].minSpeedSlow;  
          move2Postion(motorId);  
          step_motor[motorId].this_state->stateMachine =  STEP_HOME | STEP_DIRECTION_FIRST;  

        }
        if(u8_triggerTrail > con_maxTriggerTrail ){
           /*#ifdef UART_DEBUG_STP   
            printf("slowly to signal1 \n");	
           #endif*/   
           u8_triggerTrail = u8_triggerTrail;       
        }
      }
    break;  
    case ( STEP_HOME | STEP_PRE )://  
      if(HAL_GPIO_ReadPin(motor_Home_Sig_Sturct[motorId].gpio_sig1_port,motor_Home_Sig_Sturct[motorId].gpio_sig1_pin) != motor_Home_Sig_Sturct[motorId].sig1_level){
          stepper_Stop(step_motor[motorId].pul_channel);
          step_motor[motorId].this_state->miniState.speedSet = ee_conFile[motorId].minSpeedSlow;
          //Always set UP direction
          setDirectionForStep(motorId,UP);  
          step_motor[motorId].this_state->miniState.valueSet = con_MaxUpLimitation;
          step_motor[motorId].this_state->stateMachine = STEP_HOME | STEP_DIRECTION_FIRST;
          move2Postion(motorId);
          #ifdef UART_DEBUG_STP   
            printf("valueact:%f",step_motor[motorId].this_state->miniState.valueActual );	
            printf("valueSet:%f",step_motor[motorId].this_state->miniState.valueSet );				
          #endif 
      }
    break; 
    case (STEP_HOME | STEP_DIRECTION_FIRST | STEP_STOP ):
       if(HAL_GPIO_ReadPin(motor_Home_Sig_Sturct[motorId].gpio_sig1_port,motor_Home_Sig_Sturct[motorId].gpio_sig1_pin) == motor_Home_Sig_Sturct[motorId].sig1_level){// if signal_1 = lowLimit is triggered  
          u8_triggerTrail = 0;  
          // tempStart = actualValue;
          // homeAppro = true;
          step_motor[motorId].this_state->miniState.valueActual = ee_conFile[motorId].upperLimitation;
          f_tempStart                                           = ee_conFile[motorId].upperLimitation;
          step_motor[motorId].this_state->miniState.state      |= STATE_APPRO_HOME_OR_NOT;
          step_motor[motorId].this_state->stateMachine          = STEP_HOME | STEP_DIRECTION_SECOND;  
          //move to another direction to find the second signal
          step_motor[motorId].this_state->miniState.speedSet    = ee_conFile[motorId].minSpeedSlow;
          setDirectionForStep(motorId,LOW);  
          step_motor[motorId].this_state->miniState.valueSet    = con_minlowLimitation;
          move2Postion(motorId); 
       }else{
          step_motor[motorId].this_state->miniState.valueSet   += ee_conFile[motorId].resolution;
          step_motor[motorId].this_state->miniState.speedSet    = ee_conFile[motorId].minSpeedSlow;  
          step_motor[motorId].this_state->stateMachine          = STEP_HOME | STEP_DIRECTION_FIRST;          
          move2Postion(motorId);  
       }
    break;  
    case ( STEP_HOME | STEP_DIRECTION_SECOND )://    
//      if(HAL_GPIO_ReadPin(motor_Home_Sig_Sturct[motorId].gpio_sig2_port,motor_Home_Sig_Sturct[motorId].gpio_sig2_pin) == motor_Home_Sig_Sturct[motorId].sig2_level){// if signal_2 is trigered
        if(1 == homeFinalStep[motorId]){
          homeFinalStep[motorId] = 0;
      //actualValue = homeValue
      // homedistance = actualValue - tempStart;
      // homeStatus = true;
         step_motor[motorId].this_state->miniState.homeDistance = step_motor[motorId].this_state->miniState.valueActual - f_tempStart;
         step_motor[motorId].this_state->miniState.valueActual  = ee_conFile[motorId].home;
         step_motor[motorId].this_state->miniState.state       |= STATE_HOME_OR_NOT;
         step_motor[motorId].this_state->stateMachine           = STEP_STOP;
         stop_state(motorId);
         #ifdef UART_DEBUG_STP   
           printf("up_index Done.\n" );	
         #endif        
      }
    break; 

    default:
    break;
   }
}
void uplimit_itsValue_miniSwich(uint8_t motorId )
{
   unsigned int u32_stateTemp = step_motor[motorId].this_state->stateMachine; 
   switch (u32_stateTemp)
   {
    case ( STEP_HOME | STEP_STOP )://because UPlimit's direction  is known. to signal_1 = UP  
      if(HAL_GPIO_ReadPin(motor_Home_Sig_Sturct[motorId].gpio_sig1_port,motor_Home_Sig_Sturct[motorId].gpio_sig1_pin) == motor_Home_Sig_Sturct[motorId].sig1_level){// now  is at UP.
        step_motor[motorId].this_state->stateMachine = STEP_HOME | STEP_DIRECTION_FIRST ;
      }else{
      step_motor[motorId].this_state->miniState.speedSet = ee_conFile[motorId].maxSpeedFast;
      //Always set positive direction
      setDirectionForStep(motorId,UP);  
      step_motor[motorId].this_state->miniState.valueSet = con_MaxUpLimitation;
      step_motor[motorId].this_state->stateMachine = STEP_HOME | STEP_DIRECTION_FIRST;
      move2Postion(motorId);
      #ifdef UART_DEBUG_STP   
        printf("valueact:%f",step_motor[motorId].this_state->miniState.valueActual );	
        printf("valueSet:%f",step_motor[motorId].this_state->miniState.valueSet );				
      #endif       
      }        
    break; 

    case ( STEP_HOME | STEP_DIRECTION_FIRST )://
      if(HAL_GPIO_ReadPin(motor_Home_Sig_Sturct[motorId].gpio_sig1_port,motor_Home_Sig_Sturct[motorId].gpio_sig1_pin) == motor_Home_Sig_Sturct[motorId].sig1_level){// if signal_1 = lowLimit is triggered  
        stepper_Stop(step_motor[motorId].pul_channel);
        u8_triggerTrail ++;
        if(u8_triggerTrail < con_maxTriggerTrail + 1){
          upSignalValue[u8_triggerTrail - 1] = step_motor[motorId].this_state->miniState.valueActual;
          step_motor[motorId].this_state->miniState.speedSet = ee_conFile[motorId].minSpeedSlow;
          setDirectionForStep(motorId,LOW);  
          step_motor[motorId].this_state->miniState.valueSet = con_minlowLimitation;
          step_motor[motorId].this_state->stateMachine = STEP_HOME | STEP_PRE;
          move2Postion(motorId);         
          #ifdef UART_DEBUG_STP   
            printf("u8_triggerTrail:%d",u8_triggerTrail );
            printf("valueact:%f"  ,step_motor[motorId].this_state->miniState.valueActual );	
            printf("valueSet:%f\n",step_motor[motorId].this_state->miniState.valueSet );		
          #endif 
        }
        if(u8_triggerTrail == con_maxTriggerTrail){
        // find the smallest one in upSignalValue[],then move to there
          step_motor[motorId].this_state->miniState.valueSet = findmax(upSignalValue,con_maxTriggerTrail);
          step_motor[motorId].this_state->miniState.speedSet = ee_conFile[motorId].minSpeedSlow;  
          step_motor[motorId].this_state->stateMachine = STEP_HOME | STEP_DIRECTION_FIRST;          
          move2Postion(motorId);  
        }
        if(u8_triggerTrail > con_maxTriggerTrail ){
           #ifdef UART_DEBUG_STP   
            printf("slowly to signal1 \n");	
          #endif          
        }
      }
    break; 
    case ( STEP_HOME | STEP_PRE )://  
      if(HAL_GPIO_ReadPin(motor_Home_Sig_Sturct[motorId].gpio_sig1_port,motor_Home_Sig_Sturct[motorId].gpio_sig1_pin) != motor_Home_Sig_Sturct[motorId].sig1_level){
          stepper_Stop(step_motor[motorId].pul_channel);
          step_motor[motorId].this_state->miniState.speedSet = ee_conFile[motorId].minSpeedSlow;
          //Always set UP direction
          setDirectionForStep(motorId,UP);  
          step_motor[motorId].this_state->miniState.valueSet = con_MaxUpLimitation;
          step_motor[motorId].this_state->stateMachine = STEP_HOME | STEP_DIRECTION_FIRST;
          move2Postion(motorId);
          #ifdef UART_DEBUG_STP   
            printf("valueact:%f",step_motor[motorId].this_state->miniState.valueActual );	
            printf("valueSet:%f",step_motor[motorId].this_state->miniState.valueSet );				
          #endif 
      }
    break; 
    case (STEP_HOME | STEP_DIRECTION_FIRST | STEP_STOP ):
       if(HAL_GPIO_ReadPin(motor_Home_Sig_Sturct[motorId].gpio_sig1_port,motor_Home_Sig_Sturct[motorId].gpio_sig1_pin) == motor_Home_Sig_Sturct[motorId].sig1_level){// if signal_1 = lowLimit is triggered  
          u8_triggerTrail = 0;  
          // tempStart = actualValue;
          // homeAppro = true;
          step_motor[motorId].this_state->miniState.valueActual = ee_conFile[motorId].home;
          step_motor[motorId].this_state->stateMachine          = STEP_HOME | STEP_DIRECTION_SECOND;  
          //move to another direction to find the second signalvalue
          step_motor[motorId].this_state->miniState.speedSet    = ee_conFile[motorId].minSpeedSlow;
          step_motor[motorId].this_state->miniState.valueSet    = ee_conFile[motorId].upperLimitation;
          move2Postion(motorId); 
       }else{
          step_motor[motorId].this_state->miniState.valueSet   += ee_conFile[motorId].resolution;
          step_motor[motorId].this_state->miniState.speedSet    = ee_conFile[motorId].minSpeedSlow;  
          step_motor[motorId].this_state->stateMachine          = STEP_HOME | STEP_DIRECTION_FIRST;          
          move2Postion(motorId);  
       }
    break;  
    case ( STEP_HOME | STEP_DIRECTION_SECOND )://    
      if( fabs(step_motor[motorId].this_state->miniState.valueSet - step_motor[motorId].this_state->miniState.valueActual)<=ee_conFile[motorId].resolution ){// 
      // homeStatus = true;
       step_motor[motorId].this_state->miniState.state       |= STATE_HOME_OR_NOT;
       step_motor[motorId].this_state->miniState.state       |= STATE_APPRO_HOME_OR_NOT;
       step_motor[motorId].this_state->stateMachine           = STEP_STOP;
       stop_state(motorId);
      #ifdef UART_DEBUG_STP   
        printf("up_its Done.\n" );	
      #endif        
      }
    break;
    case ( STEP_HOME | STEP_DIRECTION_SECOND | STEP_STOP)://    
      if( fabs(step_motor[motorId].this_state->miniState.valueSet - step_motor[motorId].this_state->miniState.valueActual)<=ee_conFile[motorId].resolution ){// 
      // homeStatus = true;
       step_motor[motorId].this_state->miniState.state       |= STATE_HOME_OR_NOT;
       step_motor[motorId].this_state->miniState.state       |= STATE_APPRO_HOME_OR_NOT;
       step_motor[motorId].this_state->stateMachine           = STEP_STOP;
       stepper_Stop(step_motor[motorId].pul_channel);
       stop_state(motorId);
      #ifdef UART_DEBUG_STP   
        printf("up_its Done.\n" );	
      #endif        
      }else{
          step_motor[motorId].this_state->miniState.speedSet    = ee_conFile[motorId].minSpeedSlow;
          step_motor[motorId].this_state->miniState.valueSet    = ee_conFile[motorId].upperLimitation;
          step_motor[motorId].this_state->stateMachine          = STEP_HOME | STEP_DIRECTION_SECOND; 
          move2Postion(motorId);         
      }      
   break;
   default:
  break;
   } 
}
void limt_limt_miniSwich(uint8_t motorId )
{
   unsigned int u32_stateTemp = step_motor[motorId].this_state->stateMachine; 
   switch (u32_stateTemp)
   {
    case ( STEP_HOME | STEP_STOP )://
      if(HAL_GPIO_ReadPin(motor_Home_Sig_Sturct[motorId].gpio_sig1_port,motor_Home_Sig_Sturct[motorId].gpio_sig1_pin) == motor_Home_Sig_Sturct[motorId].sig1_level){// now  is at UP.
        step_motor[motorId].this_state->stateMachine = STEP_HOME | STEP_DIRECTION_FIRST ;
      }else{
        if( UP_AS_HOME_AVAILABLE_HCONF1 == (ee_conFile[motorId].this_HCONF.hconf1 & UP_AS_HOME_AVAILABLE_HCONF1)){// sig1=uplimit
            step_motor[motorId].this_state->miniState.valueSet = con_MaxUpLimitation;
        }else{// sig1=lowlimt
            step_motor[motorId].this_state->miniState.valueSet = con_minlowLimitation;
        }
        step_motor[motorId].this_state->miniState.speedSet = ee_conFile[motorId].maxSpeedFast;
        step_motor[motorId].this_state->stateMachine = STEP_HOME | STEP_DIRECTION_FIRST;
        move2Postion(motorId);
        #ifdef UART_DEBUG_STP   
          printf("valueact:%f",step_motor[motorId].this_state->miniState.valueActual );	
          printf("valueSet:%f",step_motor[motorId].this_state->miniState.valueSet );				
        #endif       
      }        
    break; 
    case ( STEP_HOME | STEP_DIRECTION_FIRST )://
      if(HAL_GPIO_ReadPin(motor_Home_Sig_Sturct[motorId].gpio_sig1_port,motor_Home_Sig_Sturct[motorId].gpio_sig1_pin) == motor_Home_Sig_Sturct[motorId].sig1_level){// if signal_1 = lowLimit is triggered  
        stepper_Stop(step_motor[motorId].pul_channel);
        //another direction 
        if( UP_AS_HOME_AVAILABLE_HCONF1 == (ee_conFile[motorId].this_HCONF.hconf1 & UP_AS_HOME_AVAILABLE_HCONF1)){
            step_motor[motorId].this_state->miniState.valueSet = con_minlowLimitation ;
        }else{// 
            step_motor[motorId].this_state->miniState.valueSet = con_MaxUpLimitation;
        }  
        step_motor[motorId].this_state->miniState.speedSet = ee_conFile[motorId].maxSpeedFast;
        move2Postion(motorId);
        step_motor[motorId].this_state->miniState.valueActual = 1;     
        step_motor[motorId].this_state->stateMachine = STEP_HOME | STEP_DIRECTION_SECOND;            
        #ifdef UART_DEBUG_STP   
          printf("valueact:%f",step_motor[motorId].this_state->miniState.valueActual );	
          printf("valueSet:%f",step_motor[motorId].this_state->miniState.valueSet );				
        #endif      
      }
    break;

    case ( STEP_HOME | STEP_DIRECTION_SECOND )://
      if(HAL_GPIO_ReadPin(motor_Home_Sig_Sturct[motorId].gpio_sig2_port,motor_Home_Sig_Sturct[motorId].gpio_sig2_pin) == motor_Home_Sig_Sturct[motorId].sig2_level){// if signal_1 = lowLimit is triggered  
        stepper_Stop(step_motor[motorId].pul_channel);

        if( UP_AS_HOME_AVAILABLE_HCONF1 == (ee_conFile[motorId].this_HCONF.hconf1 & UP_AS_HOME_AVAILABLE_HCONF1)){// 
            step_motor[motorId].this_state->miniState.valueSet = con_MaxUpLimitation;
        }else{// sig1=lowlimt
            step_motor[motorId].this_state->miniState.valueSet = con_minlowLimitation;
        }
        step_motor[motorId].this_state->miniState.valueActual = 2;     
        step_motor[motorId].this_state->miniState.speedSet = ee_conFile[motorId].maxSpeedFast;
        move2Postion(motorId);  
        step_motor[motorId].this_state->stateMachine = STEP_HOME | STEP_DIRECTION_SECOND | STEP_DIRECTION_FIRST;
        #ifdef UART_DEBUG_STP   
          printf("valueact:%f",step_motor[motorId].this_state->miniState.valueActual );	
          printf("valueSet:%f",step_motor[motorId].this_state->miniState.valueSet );				
        #endif      
      }
    break;

    case ( STEP_HOME | STEP_DIRECTION_SECOND | STEP_DIRECTION_FIRST )://
      if(HAL_GPIO_ReadPin(motor_Home_Sig_Sturct[motorId].gpio_sig1_port,motor_Home_Sig_Sturct[motorId].gpio_sig1_pin) == motor_Home_Sig_Sturct[motorId].sig1_level){// if signal_1 = lowLimit is triggered  
        stepper_Stop(step_motor[motorId].pul_channel);
        step_motor[motorId].this_state->miniState.valueActual = 1;     
        step_motor[motorId].this_state->stateMachine = STEP_STOP;
        stop_state(motorId);
        #ifdef UART_DEBUG_STP
          printf("limt*2 done\n" );	        
          printf("valueact:%f",step_motor[motorId].this_state->miniState.valueActual );	
          printf("valueSet:%f",step_motor[motorId].this_state->miniState.valueSet );			  
        #endif      
      }
    break;
    default:
    break;
   } 
}
void none_none_miniSwich(uint8_t motorId )
{
  unsigned int u32_stateTemp = step_motor[motorId].this_state->stateMachine;
	
   switch (u32_stateTemp)
   {
      case ( STEP_HOME | STEP_STOP )://because homeapprox is known. to signal_1 = home  
      //homeStatus = true;
      //homeAppro  = true;
      //homeValue = acturalValue = 0;
      step_motor[motorId].this_state->miniState.state       |= STATE_HOME_OR_NOT;
      step_motor[motorId].this_state->miniState.state       |= STATE_APPRO_HOME_OR_NOT;
      step_motor[motorId].this_state->miniState.valueActual  = ee_conFile[motorId].home;
      step_motor[motorId].this_state->stateMachine = STEP_STOP;   
      stop_state(motorId);
      #ifdef UART_DEBUG_STP   
			   for(u32_stateTemp = 0; u32_stateTemp < 100000; u32_stateTemp ++);
         printf("None_None Done.\n" );
         displayStateMachine( motorId );
      #endif   
      break; 

      default:
      break;
   }    
}

void move2p_miniswich(uint8_t motorId)
{
  uint32_t u32_stateTemp = step_motor[motorId].this_state->stateMachine;
  float    fDifference   = 0.0; 

  switch (u32_stateTemp)
  {
    case ( STEP_STOP | STEP_MOVE2_POSITION  )://        
         fDifference = fabs(state_motor_struct[motorId].state_struct.miniState.valueSet - step_motor[motorId].this_state->miniState.valueActual);
		    if (fDifference < ee_conFile[motorId].resolution){//        
          step_motor[motorId].this_state->stateMachine = STEP_STOP;
          stepper_Stop(step_motor[motorId].pul_channel);
					stop_state(motorId);
        }
        else{
          if(2 == motorId ){
						step_motor[motorId].this_state->miniState.speedSet = ee_conFile[motorId].minSpeedSlow;
					}
					move2Postion(motorId);
          step_motor[motorId].this_state->stateMachine = STEP_MOVE2_POSITION;

        }
    break; 
    case (  STEP_MOVE2_POSITION  )://  
      
    break;
    default:
    break;
  }
}

// run motor at minSpeed 20210601
void steps_resolution_calculation(uint8_t motorId)
{
  // 
  float f_steps = ee_conFile[motorId].fullStep * ee_conFile[motorId].microStep;
  uint32_t u32_steps = 0;
  f_steps = f_steps * ee_conFile[motorId].resolution * step_motor[motorId].this_state->scan_step;
  f_steps = f_steps/ee_conFile[motorId].gearRatio;

  u32_steps =(uint32_t)f_steps;
  
  step_motor[motorId].this_state->countInPWM_IRQ = u32_steps;

  #ifdef UART_DEBUG_STP   
		printf("st: %d",(int)u32_steps );					
	#endif  
}
 
void step_miniSwich(uint8_t motorId)
{
  uint32_t u32_stateTemp = step_motor[motorId].this_state->stateMachine; 
  int returnValue  = 0;
  switch (u32_stateTemp)
  {
    case (  STEP_STEPPING | STEP_STOP )://
        // when in this mode, the speed should be set to minSpeed. 20220601
        step_motor[motorId].this_state->miniState.speedSet = ee_conFile[motorId].minSpeedSlow;
        setSpeed_PWM(motorId);
        //calculate setps for driving motor
        //steps_resolution_calculation(motorId);
        setCounts_PWM(motorId);
        returnValue = stepper_Start(step_motor[motorId].pul_channel);
        //start motor
        if(-1 ==returnValue){
          start_state(motorId);     
          step_motor[motorId].this_state->stateMachine = STEP_STEPPING | STEP_DIRECTION_SECOND;      
        }

    break;
    case ( STEP_STEPPING | STEP_DIRECTION_SECOND | STEP_STOP):
        if(0 == step_motor[motorId].this_state->countInPWM_IRQ){
         // the following stateMachine is set to STEP_STOP in MotorStop too.
          
          /*if( fabs(step_motor[motorId].this_state->miniState.valueActual - step_motor[motorId].this_state->miniState.valueSet) < ee_conFile[motorId].resolution ){//check whether the setValue is equal to the actualValue. 
            step_motor[motorId].this_state->stateMachine = STEP_STOP; 
            stop_state(motorId);
					}
          else{
            step_motor[motorId].this_state->stateMachine = STEP_STEPPING | STEP_STOP;           
          }*/
            step_motor[motorId].this_state->stateMachine = STEP_STOP; 
            stop_state(motorId);         
        }
      // | STEP_DIRECTION_SECOND is used only for adding a new state.
    break;
    default:
    break;
  }
}
void step_withSpeed_miniSwich(uint8_t motorId)
{
  uint32_t u32_stateTemp = step_motor[motorId].this_state->stateMachine; 
  int returnValue  = 0;
  switch (u32_stateTemp)
  {
    case (  STEP_STEPPING_WITH_SPEED | STEP_STOP )://

        setSpeed_PWM(motorId);
        step_motor[motorId].this_state->countInPWM_IRQ = MAX_PWMCOUNT; 
        returnValue = stepper_Start(step_motor[motorId].pul_channel);
        //start motor
        if(-1 == returnValue){
          start_state(motorId);        
          step_motor[motorId].this_state->stateMachine = STEP_STEPPING_WITH_SPEED; 
        }
    break;
    case ( STEP_STEPPING_WITH_SPEED ):     
        checkCollision(motorId);
        //checkUplimtSignal(motorId);
        // checkLowlimtSignal(motorId);
    break;
    default:
    break;
  }
}
void scan_step_miniSwich(uint8_t motorId)
{
  uint32_t u32_stateTemp = step_motor[motorId].this_state->stateMachine;
  float fDifference = 0.0; 
  uint8_t myMasterPort = 0;
  uint32_t u32_PWMCount = 0; 
  uint32_t u32_microStep = ee_conFile[motorId].microStep;
  switch (u32_stateTemp)
  {
    //以下状态机 SCAN_TIME模式
    case (STEP_STEP_SCAN | STEP_STOP | STEP_MOVE2_POSITION | STEP_STEP_SCAN_TIME )://
        fDifference = fabs(step_motor[motorId].this_state->scan_start - step_motor[motorId].this_state->miniState.valueActual);
		    if (fDifference < ee_conFile[motorId].resolution){//刚进�??SCAN，判断start1==position
          step_motor[motorId].this_state->stateMachine &= ~STEP_MOVE2_POSITION;
        }
        else{
          step_motor[motorId].this_state->miniState.valueSet = step_motor[motorId].this_state->scan_start;
         /// printf("actual:%f\n",step_motor[motorId].this_state->miniState.valueActual);
          move2Postion(motorId);
         step_motor[motorId].this_state->stateMachine &= ~STEP_STOP;

          }   
    break;
    case (STEP_STEP_SCAN | STEP_MOVE2_POSITION | STEP_STEP_SCAN_TIME):
         // checkCollision(motorId);
         // checkUplimtSignal(motorId);
        //  checkLowlimtSignal(motorId);
    break;  
    case (STEP_STEP_SCAN | STEP_STOP | STEP_STEP_SCAN_TIME):              
        if(step_motor[motorId].this_state->scan_start >= step_motor[motorId].this_state->scan_stop){
            fDifference = step_motor[motorId].this_state->scan_stop - step_motor[motorId].this_state->miniState.valueActual + step_motor[motorId].this_state->scan_step * ee_conFile[motorId].resolution ;
            fDifference = -fDifference;
          } 
          else{
            fDifference = step_motor[motorId].this_state->scan_stop - step_motor[motorId].this_state->miniState.valueActual - step_motor[motorId].this_state->scan_step * ee_conFile[motorId].resolution ;
        }
				//	printf(" %f: fDifference! \n",fDifference);         
        //if( fDifference > step_motor[motorId].this_state->scan_step*ee_conFile[motorId].resolution) {
        if( fDifference > ee_conFile[motorId].resolution) {
          step_motor[motorId].this_state->scanMode = step_motor[motorId].this_state->scanMode_Shadow;
          step_motor[motorId].this_state->scanTime_2_wait_ms = step_motor[motorId].this_state->scanTime_2_wait_ms_shadow;
          step_motor[motorId].this_state->stateMachine &= ~STEP_STOP;
          u32_PWMCount  = ee_conFile[motorId].fullStep;
          u32_PWMCount *= ee_conFile[motorId].gearRatio;
          u32_PWMCount *= step_motor[motorId].this_state->scan_step * u32_microStep * ee_conFile[motorId].resolution;
          step_motor[motorId].this_state->countInPWM_IRQ = u32_PWMCount * 2; 
          //step_motor[motorId].this_state->countInPWM_IRQ	= 0;	
          step_motor[motorId].this_state->miniState.valueSet =   step_motor[motorId].this_state->scan_stop;				
        }
        else{
					printf(" %d: STOP! \n",motorId);
          step_motor[motorId].this_state->stateMachine = STEP_STOP;
					stop_state(motorId);
        } 
    break;
    case (STEP_STEP_SCAN  | STEP_STEP_SCAN_TIME ):
          if( (0 == step_motor[motorId].this_state->scanTime_2_wait_ms)&&
						  ( STATE_IDLE_OR_NOT ==  ( STATE_IDLE_OR_NOT & step_motor[motorId].this_state->miniState.state ) )  ){
            //if no slave
            if( NO_SLAVE == masterSlaveStruct.slave_exist){
              step_motor[motorId].this_state->scanMode = 0;
              scanOneStep(motorId);
            }else{
              step_motor[motorId].this_state->scanMode = 0;
              scanOneStep_withSlave(motorId);              
            }
          }else{
              if(SLAVE_EXIST == masterSlaveStruct.slave_exist){
                if((CHANNEL_READY == masterSlaveStruct.master_ready)&&(CHANNEL_READY == masterSlaveStruct.slave_ready)){
                  outPluse(masterSlaveStruct.master_ch,1);        
                  outPluse(masterSlaveStruct.slave_ch,1); 
                }  
              }else{
                if(STATE_IDLE_OR_NOT ==(  STATE_IDLE_OR_NOT & step_motor[motorId].this_state->miniState.state))
                  outPluse(motorId,1);        
              } 
          }
     
    break;
  }

}
float differenceCal_start(uint8_t motorId)
{
    float fDifference = 0.0; 
    float steps_2_distance = (float) step_motor[motorId].this_state->scan_step * ee_conFile[motorId].resolution;// 1*step = 1*resolution
    if( ( step_motor[motorId].this_state->scan_start - step_motor[motorId].this_state->scan_stop)>= 0)// get the direction
      fDifference = step_motor[motorId].this_state->scan_start - step_motor[motorId].this_state->miniState.valueActual + steps_2_distance;
    else{
      fDifference = step_motor[motorId].this_state->scan_start - step_motor[motorId].this_state->miniState.valueActual - steps_2_distance;
    }
  // printf("fabs %f \n",fabs(fDifference));
   return fabs(fDifference);
}

float differenceCal_target(uint8_t motorId)
{
    float fDifference = 0.0; 
   // float steps_2_distance = (float) step_motor[motorId].this_state->scan_step * ee_conFile[motorId].resolution;// 1*step = 1*resolution
    float steps_2_distance =  ee_conFile[motorId].resolution;// 1*step = 1*resolution


    if( ( step_motor[motorId].this_state->scan_start - step_motor[motorId].this_state->scan_stop)>= 0){// get the direction
      fDifference = step_motor[motorId].this_state->scan_stop - step_motor[motorId].this_state->miniState.valueActual + steps_2_distance;
      // start>stop, then directin is dow
    //  MOTOR_DIR( step_motor[motorId].dir_port, step_motor[motorId].dir_pin,DOWN);
      if(fDifference >= 0)
        return 0.0;
      }
    else{
      fDifference = step_motor[motorId].this_state->scan_stop - step_motor[motorId].this_state->miniState.valueActual - steps_2_distance;
      // start<stop, then directin is up
     //  MOTOR_DIR( step_motor[motorId].dir_port, step_motor[motorId].dir_pin,UP);  
        if(fDifference <= 0)
         return 0.0;  
    }
    
   return fabs(fDifference);
}
void setSpeed_PWM_continueScan(uint8_t motorId)
{
  float f_Speed    = 0.0;
  float f_Distance = step_motor[motorId].this_state->scan_step * ee_conFile[motorId].resolution;
  float f_time     = step_motor[motorId].this_state->scanTime_2_wait_ms_shadow/1000.0;

  if( f_time != 0){
     f_Speed = f_Distance/f_time;
     step_motor[motorId].this_state->miniState.speedSet = f_Speed;  
      #ifdef UART_DEBUG_STP   
		//		printf("f_Speed is %f",f_Speed);					
		  #endif  
  }
  else{
    return ;
  }
  // if this is a slave channel ,it's speed may be set by command:
 /* if( 1 == step_motor[motorId].this_state->slaveChanel){
     step_motor[motorId].this_state->miniState.speedSet = step_motor[motorId].this_state->scan_velosity;
  }
*/
  if( ( fabs(step_motor[motorId].this_state->miniState.speedSet) <= 1e-6)||( step_motor[motorId].this_state->miniState.speedSet >= ee_conFile[motorId].maxSpeedFast)){
     step_motor[motorId].this_state->miniState.speedSet = ee_conFile[motorId].maxSpeedFast;
  }
  f_Speed  = ee_conFile[motorId].fullStep*ee_conFile[motorId].microStep;
  f_Speed /= ee_conFile[motorId].gearRatio;
  f_Speed *= step_motor[motorId].this_state->miniState.speedSet;//*ee_conFile[motorId].resolution;

  //f_Speed = step_motor[motorId].this_state->miniState.speedSet*ee_conFile[motorId].fullStep * ee_conFile[motorId].microStep/ee_conFile[motorId].gearRatio;
  //printf("f_Speed %f \n",f_Speed);
  step_motor[motorId].oc_pulse_num = (unsigned int) ( ((float)FRE_PWM)/f_Speed )>>1;
  if(0 == step_motor[motorId].oc_pulse_num)
    step_motor[motorId].oc_pulse_num = 1;
}
void scanOneStep_Contimue(uint8_t motorId)
{

  uint32_t u32_PWMCount = 0; 
  uint32_t u32_temp = 0;
  int returnValue  = 0;  
  u32_PWMCount   = ee_conFile[motorId].fullStep;
  u32_PWMCount  *= ee_conFile[motorId].microStep;
  u32_PWMCount  /= ee_conFile[motorId].gearRatio;
  u32_temp = u32_PWMCount;


  u32_PWMCount  =(uint32_t)( u32_temp* (fabs)(2*step_motor[motorId].this_state->miniState.valueActual - 2*step_motor[motorId].this_state->scan_stop )  );
  
  
  u32_PWMCount  += (uint32_t)(ee_conFile[motorId].fullStep*ee_conFile[motorId].microStep*1*ee_conFile[motorId].resolution/ee_conFile[motorId].gearRatio);
  if(1 >= u32_PWMCount){
    u32_PWMCount = 2;
  }

  #ifdef UART_DEBUG_STP   
		printf("PWMCount:%d",u32_PWMCount);					
	#endif  
  setDirection( motorId);
  step_motor[motorId].this_state->countInPWM_IRQ = u32_PWMCount;
  //printf("u32_PWMCount %d \n",u32_PWMCount);
  setSpeed_PWM_continueScan(motorId);
  returnValue = stepper_Start(step_motor[motorId].pul_channel);
  if(-1 == returnValue){
    start_state(motorId);
  }
}
void scanOneStep_Contimue_withslave(uint8_t motorId)
{

  uint32_t u32_PWMCount = 0; 
  uint32_t u32_temp = 0;
  int returnValue  = 0;    
  u32_PWMCount   = ee_conFile[motorId].fullStep;
  u32_PWMCount  *= ee_conFile[motorId].microStep;
  u32_PWMCount  /= ee_conFile[motorId].gearRatio;
  u32_temp = u32_PWMCount;

  u32_PWMCount  =(uint32_t)( u32_temp* (fabs)(2*step_motor[motorId].this_state->miniState.valueActual - 2*step_motor[motorId].this_state->scan_stop )  );
  //u32_PWMCount  += (uint32_t)(ee_conFile[motorId].fullStep*ee_conFile[motorId].microStep*1*ee_conFile[motorId].resolution/ee_conFile[motorId].gearRatio);
  step_motor[motorId].this_state->countInPWM_IRQ = u32_PWMCount;

  #ifdef UART_DEBUG_STP   
//		printf("PWMCount:%d",u32_PWMCount);					
	#endif  
  setDirection( motorId);
  setSpeed_PWM_continueScan(motorId);


  if((CHANNEL_READY == masterSlaveStruct.master_ready)&&(CHANNEL_READY == masterSlaveStruct.slave_ready)){
      masterSlaveStruct.master_ready = CHANNEL_NOTREADY;
      masterSlaveStruct.slave_ready = CHANNEL_NOTREADY;  
      setSpeed_PWM_continueScan(masterSlaveStruct.master_ch);
      setSpeed_PWM_continueScan(masterSlaveStruct.slave_ch);
  #ifdef UART_DEBUG_STP   
		printf("m_PWM:%lld\n",step_motor[masterSlaveStruct.master_ch].this_state->countInPWM_IRQ);				
    printf("S_PWM:%lld\n",step_motor[masterSlaveStruct.slave_ch].this_state->countInPWM_IRQ);					
	#endif  

      outPluse(masterSlaveStruct.master_ch,0);        
      outPluse(masterSlaveStruct.slave_ch,0); 	
		  
      returnValue = stepper_Start(step_motor[masterSlaveStruct.master_ch].pul_channel);
      if(-1 == returnValue){
        start_state(masterSlaveStruct.master_ch);
      }
      returnValue = stepper_Start(step_motor[masterSlaveStruct.slave_ch].pul_channel);
      if(-1 == returnValue){
        start_state(masterSlaveStruct.slave_ch);
      }

      // master and slave are moving, so ENABLE output is low, other device should wait. 
  } 
}
void continue_scan_miniSwich(uint8_t motorId)
{
  uint32_t u32_stateTemp = step_motor[motorId].this_state->stateMachine;
  float fDifference = 0.0; 
  float steps_2_distance = (float)step_motor[motorId].this_state->scan_step * ee_conFile[motorId].resolution;// 1*step = 1*resolution
  uint32_t u32_PWMCount = 0; 
  uint32_t u32_temp = 0;
  Limitations_Control(motorId);
  switch (u32_stateTemp)
  {
    case ( STEP_STOP | STEP_MOVE2_POSITION | STEP_STEP_CONTINUE_SCAN)://        
        fDifference = differenceCal_start(motorId);
        if (fDifference < ee_conFile[motorId].resolution){//刚进�??SCAN，判断start1 - step1 ==position

          step_motor[motorId].this_state->stateMachine &= ~STEP_MOVE2_POSITION;
        }
        else{
          //set the target postion fristly 
          if( ( step_motor[motorId].this_state->scan_start - step_motor[motorId].this_state->scan_stop)>= 0)
            step_motor[motorId].this_state->miniState.valueSet = step_motor[motorId].this_state->scan_start + steps_2_distance;
          else{
            step_motor[motorId].this_state->miniState.valueSet = step_motor[motorId].this_state->scan_start - steps_2_distance;
          }
          step_motor[motorId].this_state->miniState.speedSet =  ee_conFile[motorId].minSpeedSlow;
          move2Postion(motorId);
			    step_motor[motorId].this_state->stateMachine &= ~STEP_STOP;
		
        }   
    break;
    case ( STEP_MOVE2_POSITION | STEP_STEP_CONTINUE_SCAN):

    break;  
    case ( STEP_STOP | STEP_STEP_CONTINUE_SCAN):              
         //to check if target is reached.
        fDifference = differenceCal_target(motorId);
        if( fDifference > ee_conFile[motorId].resolution) {
          step_motor[motorId].this_state->scanMode           = step_motor[motorId].this_state->scanMode_Shadow;
          step_motor[motorId].this_state->scanTime_2_wait_ms = step_motor[motorId].this_state->scanTime_2_wait_ms_shadow;
          step_motor[motorId].this_state->stateMachine       &= ~STEP_STOP;

          u32_PWMCount   = ee_conFile[motorId].fullStep;
          u32_PWMCount  *= ee_conFile[motorId].microStep;
          u32_PWMCount  /= ee_conFile[motorId].gearRatio;
          u32_temp = u32_PWMCount;
        
          u32_PWMCount  =(uint32_t)( u32_temp* (fabs)(2*step_motor[motorId].this_state->miniState.valueActual - 2*step_motor[motorId].this_state->scan_stop )  );
         // u32_PWMCount  += (uint32_t)(ee_conFile[motorId].fullStep*ee_conFile[motorId].microStep*1*ee_conFile[motorId].resolution/ee_conFile[motorId].gearRatio);
          step_motor[motorId].this_state->countInPWM_IRQ = u32_PWMCount;

          if(motorId == masterSlaveStruct.master_ch){
            masterSlaveStruct.master_ready = CHANNEL_READY;
            printf("m ready\n");	
          }else{
            masterSlaveStruct.slave_ready = CHANNEL_READY;
            printf("s ready\n");	
          }

          if( step_motor[motorId].this_state->pulse_out_or_not == 1);//
          		step_motor[motorId].this_state->pulse_out_or_not = 1;
          
          step_motor[motorId].this_state->miniState.valueSet =   step_motor[motorId].this_state->scan_stop;

        }
        else{
          step_motor[motorId].this_state->stateMachine = STEP_STOP;
					stop_state(motorId);
         // printf("STOP at scan.\n ");

        }

    break;
    case (STEP_STEP_CONTINUE_SCAN ):
         if( STATE_IDLE_OR_NOT ==  ( STATE_IDLE_OR_NOT & step_motor[motorId].this_state->miniState.state ) ){
            if( NO_SLAVE == masterSlaveStruct.slave_exist){
              scanOneStep_Contimue(motorId);
              printf("value is  %f \n ",state_motor_struct[motorId].state_struct.miniState.valueActual);                 
            }else{
               scanOneStep_Contimue_withslave(motorId);        
            }
         }
    break;

    default:
    break;
  }
}
void Limitations_Control(uint8_t motorId)
{
  if(  0 == ee_conFile[motorId].rotationAvailable ){//if rotation is true, the value limitation is not used
    if(step_motor[motorId].this_state->miniState.valueActual >= ee_conFile[motorId].upperLimitation ){
       step_motor[motorId].this_state->miniState.state |= STATE_UPPER_VALUE_OR_NOT;
       if( step_motor[motorId].this_state->miniState.valueSet <= step_motor[motorId].this_state->miniState.valueActual){
         return;
       }    
      if(HAL_GPIO_ReadPin( step_motor[motorId].dir_port, step_motor[motorId].dir_pin) == step_motor[motorId].this_state->u8_direction_up){
       if(0 != (step_motor[motorId].this_state->stateMachine & NOT_CONSTRIANTS_MOVE)){
          return;
       }
       else{
        stepper_Stop(step_motor[motorId].pul_channel);
        stop_state(motorId);
        printf("STOP at limitation.\n ");
        step_motor[motorId].this_state->stateMachine   = STEP_STOP;
       }
      }
       return;
    }
    else{
      step_motor[motorId].this_state->miniState.state &= ~STATE_UPPER_VALUE_OR_NOT;
    }
    if(step_motor[motorId].this_state->miniState.valueActual <= ee_conFile[motorId].lowerLimitation){
       step_motor[motorId].this_state->miniState.state |= STATE_lOWER_VALUE_OR_NOT;
       if( step_motor[motorId].this_state->miniState.valueSet >= step_motor[motorId].this_state->miniState.valueActual){
         return;
       }
      if(HAL_GPIO_ReadPin( step_motor[motorId].dir_port, step_motor[motorId].dir_pin) == step_motor[motorId].this_state->u8_direction_down){
       if(0 != (step_motor[motorId].this_state->stateMachine & NOT_CONSTRIANTS_MOVE)){
          return;
       }else{
          stepper_Stop(step_motor[motorId].pul_channel);
          stop_state(motorId);
          printf("STOP at limitation.\n ");
          step_motor[motorId].this_state->stateMachine   = STEP_STOP;
       }
       return;
      }else{
        step_motor[motorId].this_state->miniState.state &= ~STATE_lOWER_VALUE_OR_NOT;
      }
    }  
  }
}
void setDirection(uint8_t motorId)
{
  step_motor[motorId].this_state->u8_direction_down  = 0;
  step_motor[motorId].this_state->u8_direction_up    = 1;

   if((ee_conFile[motorId].this_HCONF.hconf2 & MOTOR_DIRECTION_HIGH_HCONF2 )!= MOTOR_DIRECTION_HIGH_HCONF2 ){
    // 1:up direction
    step_motor[motorId].this_state->u8_direction_down = 1;
    step_motor[motorId].this_state->u8_direction_up   = 0;
   }
   else{
    // 0: up dretion
   }
  if( ( step_motor[motorId].this_state->miniState.valueSet - step_motor[motorId].this_state->miniState.valueActual)>= 0){// get the direction
      MOTOR_DIR( step_motor[motorId].dir_port, step_motor[motorId].dir_pin,step_motor[motorId].this_state->u8_direction_up);
      }else{
      MOTOR_DIR( step_motor[motorId].dir_port, step_motor[motorId].dir_pin,step_motor[motorId].this_state->u8_direction_down);      
    }   

}
void setDirectionForStep(uint8_t motorId,uint8_t inputDirection)
{
  step_motor[motorId].this_state->u8_direction_down  = 0;
  step_motor[motorId].this_state->u8_direction_up    = 1;

   if((ee_conFile[motorId].this_HCONF.hconf2 & MOTOR_DIRECTION_HIGH_HCONF2 )!= MOTOR_DIRECTION_HIGH_HCONF2 ){
    // 1:up direction
    step_motor[motorId].this_state->u8_direction_down = 1;
    step_motor[motorId].this_state->u8_direction_up   = 0;
   }
   else{
    // 0: up dretion
   }
   
   if( inputDirection == 0){//up
      MOTOR_DIR( step_motor[motorId].dir_port, step_motor[motorId].dir_pin,step_motor[motorId].this_state->u8_direction_up);
   }else{
      MOTOR_DIR( step_motor[motorId].dir_port, step_motor[motorId].dir_pin,step_motor[motorId].this_state->u8_direction_down);
   }

}

void checkCollision(uint8_t motorId)
{
  if(COLLLIM_AVAILABLE_HCONF1 == (COLLLIM_AVAILABLE_HCONF1 &  ee_conFile[motorId].this_HCONF.hconf1) ){// if colission singal exists.
   
   if(COLLISION_HIGH_HCONF2 == (COLLISION_HIGH_HCONF2 & ee_conFile[motorId].this_HCONF.hconf2)){
     //high effecitve
     if( HAL_GPIO_ReadPin( step_motor[motorId].collision_port,step_motor[motorId].collision_pin ) == KEY_ON  ){
       if( STEP_STEPPING == (step_motor[motorId].this_state->stateMachine & STEP_STEPPING)){
          step_motor[motorId].this_state->miniState.state |= STATE_COLLISION_OR_NOT;
          return;
       }      
       stepper_Stop(step_motor[motorId].pul_channel);
       step_motor[motorId].this_state->miniState.state |= STATE_COLLISION_OR_NOT;
       stop_state(motorId);
       step_motor[motorId].this_state->stateMachine      = STEP_STOP;
     }else{
       step_motor[motorId].this_state->miniState.state &= ~STATE_COLLISION_OR_NOT;
     }

   }else{// low effective
     if(HAL_GPIO_ReadPin( step_motor[motorId].collision_port,step_motor[motorId].collision_pin ) == KEY_OFF ){
       if( STEP_STEPPING == (step_motor[motorId].this_state->stateMachine & STEP_STEPPING)){
          step_motor[motorId].this_state->miniState.state |= STATE_COLLISION_OR_NOT;
          return;
       }        
       stepper_Stop(step_motor[motorId].pul_channel);
       step_motor[motorId].this_state->miniState.state |= STATE_COLLISION_OR_NOT;
       stop_state(motorId);
       step_motor[motorId].this_state->stateMachine      = STEP_STOP;    
     }else{
       step_motor[motorId].this_state->miniState.state &= ~STATE_COLLISION_OR_NOT;
     }
   }
 }//end of if colission singal exists.
}
uint16_t getCollision(uint8_t motorId)
{
  return (step_motor[motorId].this_state->miniState.state & STATE_COLLISION_OR_NOT);
}

void checkUplimtSignal(uint8_t motorId)
{

 if(UPLIM_AVAILABLE_HCONF1 == (UPLIM_AVAILABLE_HCONF1 &  ee_conFile[motorId].this_HCONF.hconf1) ){// if uplimt singal exists.
   if(UP_LIMITIATION_HCONF2 == (UP_LIMITIATION_HCONF2 & ee_conFile[motorId].this_HCONF.hconf2)){
     //high effecitve
     if( HAL_GPIO_ReadPin( step_motor[motorId].limP_port,step_motor[motorId].limP_pin ) == KEY_ON  ){
      // if motor is in step mode ,or up/low as home while homing, this signal dose not stop movement.
       if(0 != (step_motor[motorId].this_state->stateMachine & NOT_CONSTRIANTS_MOVE)){
          step_motor[motorId].this_state->miniState.state |= STATE_UPPER_OR_NOT;
          return;
       }
       stepper_Stop(step_motor[motorId].pul_channel);
       step_motor[motorId].this_state->miniState.state |= STATE_UPPER_OR_NOT;
       stop_state(motorId);
       step_motor[motorId].this_state->stateMachine      = STEP_STOP;
     }else{
       step_motor[motorId].this_state->miniState.state &= ~STATE_UPPER_OR_NOT;
     }

   }else{// low effective
     if(HAL_GPIO_ReadPin(step_motor[motorId].limP_port,step_motor[motorId].limP_pin ) == KEY_OFF ){
       if(0 != (step_motor[motorId].this_state->stateMachine & NOT_CONSTRIANTS_MOVE)){
          step_motor[motorId].this_state->miniState.state |= STATE_UPPER_OR_NOT;
          return;
       }      
       stepper_Stop(step_motor[motorId].pul_channel);
       step_motor[motorId].this_state->miniState.state |= STATE_UPPER_OR_NOT;
       stop_state(motorId);
       step_motor[motorId].this_state->stateMachine      = STEP_STOP;    
     }else{
       step_motor[motorId].this_state->miniState.state &= ~STATE_UPPER_OR_NOT;
     }
   }   
 }//end of if uplimt singal exists.
}
uint16_t getUpLimSig(uint8_t motorId)
{
  return (step_motor[motorId].this_state->miniState.state & STATE_UPPER_OR_NOT);
}

void checkLowlimtSignal(uint8_t motorId)
{
 if(LOWLIM_AVAILABLE_HCONF1 == (LOWLIM_AVAILABLE_HCONF1 &  ee_conFile[motorId].this_HCONF.hconf1) ){// if lowlimt singal exists.
   if(LOW_LIMITIATION_HCONF2 == (LOW_LIMITIATION_HCONF2 & ee_conFile[motorId].this_HCONF.hconf2)){
     //high effecitve
     if( HAL_GPIO_ReadPin( step_motor[motorId].limN_port,step_motor[motorId].limN_pin ) == KEY_ON  ){
      // if motor is in step mode ,or up/low as home while homing, this signal dose not stop movement.
      if(0 != (step_motor[motorId].this_state->stateMachine & NOT_CONSTRIANTS_MOVE)){
          step_motor[motorId].this_state->miniState.state |= STATE_LOWER_OR_NOT;        
          return;
       }            
       stepper_Stop(step_motor[motorId].pul_channel);
       step_motor[motorId].this_state->miniState.state |= STATE_LOWER_OR_NOT;
       stop_state(motorId);
       step_motor[motorId].this_state->stateMachine      = STEP_STOP;
     }else{
       step_motor[motorId].this_state->miniState.state &= ~STATE_LOWER_OR_NOT;
     }
   }else{// low effective
     if(HAL_GPIO_ReadPin(step_motor[motorId].limN_port,step_motor[motorId].limN_pin ) == KEY_OFF ){
      if(0 != (step_motor[motorId].this_state->stateMachine & NOT_CONSTRIANTS_MOVE)){
          step_motor[motorId].this_state->miniState.state |= STATE_LOWER_OR_NOT;        
          return;
       }         
       stepper_Stop(step_motor[motorId].pul_channel);
       step_motor[motorId].this_state->miniState.state |= STATE_LOWER_OR_NOT;
       stop_state(motorId);
       step_motor[motorId].this_state->stateMachine      = STEP_STOP;    
     }else{
       step_motor[motorId].this_state->miniState.state &= ~STATE_LOWER_OR_NOT;
     }
   }   
 }//end of if uplimt singal exists.
}
uint16_t getLowLimSig(uint8_t motorId)
{
  return (step_motor[motorId].this_state->miniState.state & STATE_LOWER_OR_NOT);
}


void setDirectionForFindingHome(uint8_t motorId)//0:up,1:down
{
  step_motor[motorId].this_state->u8_direction_down  = 0;
  step_motor[motorId].this_state->u8_direction_up    = 1;

   if((ee_conFile[motorId].this_HCONF.hconf2 & MOTOR_DIRECTION_HIGH_HCONF2 )!= MOTOR_DIRECTION_HIGH_HCONF2 ){
    // 1:up direction
    step_motor[motorId].this_state->u8_direction_down = 1;
    step_motor[motorId].this_state->u8_direction_up   = 0;
   }
   else{
    // 0: up dretion
   }
  if(motor_Home_Sig_Sturct[motorId].direction == UP ){
    MOTOR_DIR( step_motor[motorId].dir_port, step_motor[motorId].dir_pin,step_motor[motorId].this_state->u8_direction_up);
  }else{
    MOTOR_DIR( step_motor[motorId].dir_port, step_motor[motorId].dir_pin,step_motor[motorId].this_state->u8_direction_down);      
  }  
}

// move to homeValueApproximate - 1 with minSpeed.
void home_pre_HOME_PRE(uint8_t motorId)
{
  step_motor[motorId].this_state->miniState.speedSet = ee_conFile[motorId].maxSpeedFast;
  step_motor[motorId].this_state->miniState.valueSet = step_motor[motorId].this_state->miniState.homeValueApproximate - 1; 
  step_motor[motorId].this_state->stateMachine = STEP_HOME | STEP_PRE;  
  move2Postion(motorId);
  #ifdef UART_DEBUG_STP   
  	printf("valueact:%f",step_motor[motorId].this_state->miniState.valueActual );	
    printf("valueSet:%f",step_motor[motorId].this_state->miniState.valueSet );				
  #endif 
}
void home_first_WAIT_SIG1_DIS(uint8_t motorId)
{
    step_motor[motorId].this_state->miniState.speedSet = ee_conFile[motorId].minSpeedSlow;
    //Always set positive direction
    setDirectionForStep(motorId,UP);  
    if(fabs(ee_conFile[motorId].upperLimitation) < ee_conFile[motorId].resolution){
        step_motor[motorId].this_state->miniState.valueSet = con_MaxUpLimitation;
    }else{
        step_motor[motorId].this_state->miniState.valueSet = 2* ee_conFile[motorId].upperLimitation;
    }
    move2Postion(motorId);
    step_motor[motorId].this_state->stateMachine = STEP_HOME | STEP_DIRECTION_FIRST | STEP_WAIT_SIG1_DISAPPEAR;
    #ifdef UART_DEBUG_STP   
    	 printf("waiting for dis" );	
    #endif 
}
//20250830
void home_first_WAIT_SIG1_DIS_A1(uint8_t motorId)
{
    step_motor[motorId].this_state->miniState.speedSet = ee_conFile[motorId].minSpeedSlow;
    //Always set positive direction
    setDirectionForStep(motorId,UP);  
    if(fabs(ee_conFile[motorId].upperLimitation) < ee_conFile[motorId].resolution){
        step_motor[motorId].this_state->miniState.valueSet = con_MaxUpLimitation;
    }else{
        step_motor[motorId].this_state->miniState.valueSet = 2* ee_conFile[motorId].upperLimitation;
    }
    move2Postion(motorId);
    step_motor[motorId].this_state->stateMachine = STEP_HOME | STEP_DIRECTION_FIRST | STEP_WAIT_SIG1_DISAPPEAR;
    #ifdef UART_DEBUG_STP   
    	 printf("waiting for dis" );	
    #endif 
}

void home_sig1_dnotshow_back2_HOME_PRE(uint8_t motorId)
{
    step_motor[motorId].this_state->miniState.speedSet = ee_conFile[motorId].maxSpeedFast; 
    step_motor[motorId].this_state->miniState.valueSet = step_motor[motorId].this_state->miniState.homeValueApproximate - 1; 
    step_motor[motorId].this_state->stateMachine = STEP_HOME | STEP_PRE;  
    move2Postion(motorId);
    u8_fullTrailForHoming++;
    if( con_maxHomingTrail == u8_fullTrailForHoming){
      u8_fullTrailForHoming = 0;
      #ifdef UART_DEBUG_STP   
		    printf("No home!" );	
		  #endif            
    }
}
void home_preStop_readyfor_FIRST(uint8_t motorId)
{
  float f_difference = 0.0;
  f_difference = step_motor[motorId].this_state->miniState.valueSet - (float)step_motor[motorId].this_state->miniState.homeValueApproximate + 1 ;
  if( fabs(f_difference) <= 2*ee_conFile[motorId].resolution){// near miniState.homeValueApproximate - 1       
    step_motor[motorId].this_state->miniState.valueSet = step_motor[motorId].this_state->miniState.homeValueApproximate + 1;
    step_motor[motorId].this_state->miniState.speedSet = ee_conFile[motorId].minSpeedSlow;
    step_motor[motorId].this_state->stateMachine = STEP_HOME | STEP_DIRECTION_FIRST;    
    move2Postion(motorId);
  }  
}
void home_sigDis_SECOND_WAIT_SIG1(uint8_t motorId)
{
  
  if( HAL_GPIO_ReadPin(motor_Home_Sig_Sturct[motorId].gpio_sig1_port,motor_Home_Sig_Sturct[motorId].gpio_sig1_pin) != motor_Home_Sig_Sturct[motorId].sig1_level ){//signal_1 is disappeared          
    step_motor[motorId].this_state->miniState.speedSet = ee_conFile[motorId].minSpeedSlow;
    //Always set negtive direction
    setDirectionForStep(motorId,DOWN);  
    if(fabs(ee_conFile[motorId].lowerLimitation) < ee_conFile[motorId].resolution){
        step_motor[motorId].this_state->miniState.valueSet = con_minlowLimitation;
    }else{
        step_motor[motorId].this_state->miniState.valueSet = 2* ee_conFile[motorId].lowerLimitation;
    }
    move2Postion(motorId); 
    step_motor[motorId].this_state->stateMachine = STEP_HOME | STEP_DIRECTION_SECOND | STEP_WAITING_SIG1;
    #ifdef UART_DEBUG_STP   
		    printf("wait sig1 again" );	
		#endif  
   }

}
void home_secondSig1_SECOND_WAIT_SIG2(uint8_t motorId)
{
  int returnValue  = 0;
  if( HAL_GPIO_ReadPin(motor_Home_Sig_Sturct[motorId].gpio_sig1_port,motor_Home_Sig_Sturct[motorId].gpio_sig1_pin) == motor_Home_Sig_Sturct[motorId].sig1_level ){//signal_1 is triggerd
    stepper_Stop(step_motor[motorId].pul_channel);       
    step_motor[motorId].this_state->f_Start_homedistance = step_motor[motorId].this_state->miniState.valueActual;
    step_motor[motorId].this_state->miniState.speedSet   = ee_conFile[motorId].minSpeedSlow;
    setSpeed_PWM(motorId); 
    //Always set positive direction
    setDirectionForStep(motorId,UP);  
    if(fabs(ee_conFile[motorId].upperLimitation) < ee_conFile[motorId].resolution){
        step_motor[motorId].this_state->miniState.valueSet = con_MaxUpLimitation;
    }else{
        step_motor[motorId].this_state->miniState.valueSet = 2* ee_conFile[motorId].upperLimitation;
    }
    setCounts_PWM(motorId);  
    returnValue = stepper_Start(step_motor[motorId].pul_channel);
    if(-1 == returnValue){
      start_state(motorId);   
      step_motor[motorId].this_state->stateMachine    = STEP_HOME | STEP_DIRECTION_SECOND |STEP_WAITING_SIG2 |STEP_WAITING_SIG1;  
      #ifdef UART_DEBUG_STP   
		  printf("wait sig2" );	
		  #endif   
    }   


  }  
}
void home_secondSig1_SECOND_WAIT_SIG2_A1(uint8_t motorId)
{
  //20250830, if signal 1 triggerd, continuing move -8 to DOWN direction
  int returnValue  = 0;
  if( HAL_GPIO_ReadPin(motor_Home_Sig_Sturct[motorId].gpio_sig1_port,motor_Home_Sig_Sturct[motorId].gpio_sig1_pin) == motor_Home_Sig_Sturct[motorId].sig1_level ){//signal_1 is triggerd
    stepper_Stop(step_motor[motorId].pul_channel);       
    //step_motor[motorId].this_state->f_Start_homedistance = step_motor[motorId].this_state->miniState.valueActual;
    step_motor[motorId].this_state->miniState.speedSet   = ee_conFile[motorId].minSpeedSlow;
    setSpeed_PWM(motorId); 
    //Always set DOWN direction
    setDirectionForStep(motorId,DOWN);    //20250830:UP->DOWN

    step_motor[motorId].this_state->miniState.valueSet =  step_motor[motorId].this_state->miniState.valueActual + 8.0;
    setCounts_PWM(motorId);  
    
    returnValue = stepper_Start(step_motor[motorId].pul_channel);
    if(-1 == returnValue){
      start_state(motorId);   
      step_motor[motorId].this_state->stateMachine    = STEP_HOME | STEP_DIRECTION_SECOND |STEP_WAITING_SIG2 ;  
      #ifdef UART_DEBUG_STP   
		  printf("moving -8" );	
		  #endif   
    }   
  }  
}  

float findmin(float* pbuff,const uint8_t len)
{
  float  tempmin = pbuff[0];
  uint8_t i = 0;
  for(i = 0; i < len; i ++){
    if( tempmin < pbuff[i] ){
       tempmin   = pbuff[i];        
    }
  }
   return tempmin;
}
float findmax(float* pbuff,const uint8_t len)
{
  float  tempmin = pbuff[0];
  uint8_t i = 0;
  for(i = 0; i < len; i ++){
    if( tempmin  >pbuff[i] ){
       tempmin   = pbuff[i];        
    }
  }
   return tempmin;
}
//connect OUT1<-->lowlimit
void Test_lowsignal(uint8_t motorId)
{
  float f_testIndex =  0.1*ee_conFile[motorId].upperLimitation + 1;
  if(step_motor[motorId].this_state->miniState.valueActual <  ee_conFile[motorId].lowerLimitation - 20 - ee_conFile[motorId].resolution){
     outPluse(0,1);
   /*  #ifdef UART_DEBUG_STP   
        printf("lowerLimitation:%f\n",ee_conFile[motorId].lowerLimitation );	
        printf("valueact:%f\n",step_motor[motorId].this_state->miniState.valueActual );	
        printf("low triggerd\n" );
		#endif     */
  }
  else{
    outPluse(0,0);
  }
}
//connect OUT1<-->lowlimit
//connect OUT4<-->index
void Test_UPsignal(uint8_t motorId)
{
  float f_testIndex_up =  0.8*ee_conFile[motorId].upperLimitation  + 1;
  float f_testIndex_low =  0.8*ee_conFile[motorId].upperLimitation ;

  if(step_motor[motorId].this_state->miniState.valueActual >  ee_conFile[motorId].upperLimitation +30 ){
     outPluse(0,1);
   /*  #ifdef UART_DEBUG_STP   
        printf("lowerLimitation:%f\n",ee_conFile[motorId].lowerLimitation );	
        printf("valueact:%f\n",step_motor[motorId].this_state->miniState.valueActual );	
        printf("low triggerd\n" );
		#endif     */
  }
  else{
    outPluse(0,0);
  }
  if( (step_motor[motorId].this_state->miniState.valueActual > f_testIndex_low)){
    if(step_motor[motorId].this_state->miniState.valueActual < f_testIndex_up)
       outPluse(3,1);  
  }else{
       outPluse(3,0);   
  }
} 
//connect OUT1<-->lowlimit
//connect OUT4<-->uplimit
void test_limt_limt(uint8_t motorId)
{
  float f_testIndex_up  =  ee_conFile[motorId].upperLimitation  + 1;
  float f_testIndex_low =  ee_conFile[motorId].lowerLimitation  - 1;
  
  if(motor_Home_Sig_Sturct[motorId].homeMode == HOME_LIMT_LIMT ){// only in this mode.
    capture_count_current[motorId] = (int)__HAL_TIM_GET_COUNTER(&TIM_EncoderHandle[motorId]) + (Encoder_Overflow_Count[motorId] * ENCODER_TIM_PERIOD);
    if(motorId == ee_conFile[motorId].encoderCounts){
	    ee_conFile[motorId].encoderCounts = ENCODER_TOTAL_RESOLUTION;
    }
    step_motor[motorId].this_state->f_valueActual_test += (float)(capture_count_current[motorId]-capture_count_last[motorId])/ee_conFile[motorId].encoderCounts;
    capture_count_last[motorId] = capture_count_current[motorId];
  }
  if(step_motor[motorId].this_state->f_valueActual_test > f_testIndex_up){
       outPluse(3,1);  
  }else{
      outPluse(3,0);     
  }
  if(step_motor[motorId].this_state->f_valueActual_test <  f_testIndex_low){
       outPluse(0,1);  
  }else{
      outPluse(0,0);     
     /* #ifdef UART_DEBUG_STP   
          printf("f_valueActual_test:%f\n", step_motor[motorId].this_state->f_valueActual_test);	
          printf("f_testIndex_low %f\n", f_testIndex_low);	
      #endif   */ 
  }


}

#ifdef UART_DEBUG_STP   
void displayCaptureUnit(void)
{
    printf("per[0]:%d\n", capture_per_unit[0]);	
    printf("1: %d\n", capture_per_unit[1]);	
    printf("2: %d\n", capture_per_unit[2]);	
}
#endif   

//20220914 about backlash
int chekBackLash(uint8_t motorId)
{
  /*
  uint32_t homeMode = 0;

  if(0.0 == ee_conFile[motorId].backlash){
    return 0;
  }
  homeMode = motor_Home_Sig_Sturct[motorId].homeMode;
	//homeMode = 0x02;
  switch (homeMode)
  {
    case ( HOME_HOME_INDEX)://  
          // because index is ALWAYS greater than home!!! 
          // so if the direction is to lower,then backlash is needed
          if(step_motor[motorId].this_state->miniState.valueSet < step_motor[motorId].this_state->miniState.valueActual){
            return -1;
          }
    break;
    case ( HOME_HOME_NONE):// 
          if(step_motor[motorId].this_state->miniState.valueSet < step_motor[motorId].this_state->miniState.valueActual){
            return -1;
          }          
    break;
    case ( HOME_LOW_INDEX):
          // if the direction is to lowwer, then backlash is needed
          if(step_motor[motorId].this_state->miniState.valueSet < step_motor[motorId].this_state->miniState.valueActual){
            return -1;
          }
    break;
    case ( HOME_LOLIMT_VALUE):// 
          // if the direction is to lowwer, then backlash is needed
          if(step_motor[motorId].this_state->miniState.valueSet < step_motor[motorId].this_state->miniState.valueActual){
            return -1;
          }
    break;

    case ( HOME_UPPER_INDEX)://
          // if the direction is to upper, then backlash is needed
          if(step_motor[motorId].this_state->miniState.valueSet > step_motor[motorId].this_state->miniState.valueActual){
            return 1;
          }             
    break;

    case ( HOME_UPLIMT_VALUE)://  
          // if the direction is to upper, then backlash is needed
          if(step_motor[motorId].this_state->miniState.valueSet > step_motor[motorId].this_state->miniState.valueActual){
            return 1;
          }             
    break;
    
    case ( HOME_LIMT_LIMT)://   
          return 0;      
    break;

    case ( HOME_NONE_NONE)://  
          return 0;       
    break;

    default:  
          return 0;       
    break;
  }
*/
/*
  unsigned char homeMode = motor_Home_Sig_Sturct[motorId].homeMode;
  switch (homeMode)
  {
    case  ( HOME_HOME_INDEX ):
          //home_index_miniSwich( motorId );
		     // if(step_motor[motorId].this_state->miniState.valueSet < step_motor[motorId].this_state->miniState.valueActual){
         //   return -1;
         // }
    break;
    case  ( HOME_LOW_INDEX ):
          //low_index_miniSwich( motorId );
		      if(step_motor[motorId].this_state->miniState.valueSet < step_motor[motorId].this_state->miniState.valueActual){
            return -1;
          }
    break;
    case  ( HOME_UPPER_INDEX ):
          if(step_motor[motorId].this_state->miniState.valueSet > step_motor[motorId].this_state->miniState.valueActual){
            return 1;
          }       
		break;
    case  ( HOME_HOME_NONE ):
    //      if(step_motor[motorId].this_state->miniState.valueSet < step_motor[motorId].this_state->miniState.valueActual){
     //       return -1;
     //     }     
		break;
    case  ( HOME_UPLIMT_VALUE ):
   
		break;
    case  ( HOME_LOLIMT_VALUE ):
     //     if(step_motor[motorId].this_state->miniState.valueSet > step_motor[motorId].this_state->miniState.valueActual){
      //      return 1;
       //   }   
    break;
    case  ( HOME_LIMT_LIMT ):

    break;
    case  ( HOME_NONE_NONE ):
      //    return 0;
    break;
            
    default:
		      return 0;
    break;
  }
*/
  uint32_t homeMode = 0;
  if(0.0 == ee_conFile[motorId].backlash){
    return 0;
  }
  homeMode = motor_Home_Sig_Sturct[motorId].homeMode;
	if(HOME_HOME_INDEX == homeMode){
    // because index is ALWAYS greater than home!!! 
    // so if the direction is to lower,then backlash is needed
    if(step_motor[motorId].this_state->miniState.valueSet < step_motor[motorId].this_state->miniState.valueActual){
      return -1;
    }
  }
  if(HOME_HOME_NONE == homeMode){
    if(step_motor[motorId].this_state->miniState.valueSet < step_motor[motorId].this_state->miniState.valueActual){
      return -1;
    }   
  }
  if(HOME_LOW_INDEX == homeMode){
    // if the direction is to lowwer, then backlash is needed
    if(step_motor[motorId].this_state->miniState.valueSet < step_motor[motorId].this_state->miniState.valueActual){
      return -1;
    }
  }
  if(HOME_LOLIMT_VALUE == homeMode){
    // if the direction is to lowwer, then backlash is needed
    if(step_motor[motorId].this_state->miniState.valueSet < step_motor[motorId].this_state->miniState.valueActual){
      return -1;
    }
  }
  if(HOME_UPPER_INDEX == homeMode ){
    // if the direction is to upper, then backlash is needed
    if(step_motor[motorId].this_state->miniState.valueSet > step_motor[motorId].this_state->miniState.valueActual){
      return 1;
    } 
  }
  if(HOME_UPLIMT_VALUE == homeMode){
     // if the direction is to upper, then backlash is needed
     if(step_motor[motorId].this_state->miniState.valueSet > step_motor[motorId].this_state->miniState.valueActual){
       return 1;
     }        
  }
  
  return 0;

}

//end of this file

