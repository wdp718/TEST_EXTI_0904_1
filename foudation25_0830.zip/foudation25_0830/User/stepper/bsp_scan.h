#ifndef __STEP_SCAN_H
#define	__STEP_SCAN_H


#include "stm32h7xx.h"
#include "stm32h7xx_hal.h"
#include "./exti/bsp_exti.h"

#include "stm32h7xx.h"
#include "main.h"
#include "bsp_led.h"
#include "bsp_key.h" 
#include "core_delay.h"   
#include "bsp_debug_usart.h"
#include "bsp_exti.h"
//#include "./i2c/bsp_i2c_ee.h"
#include "bsp_basic_tim.h"
#include "./stepper/bsp_stepper_init.h"
#include "./stepper/stepper_task.h"

/* FreeRTOS头文�? */
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"
#include "event_groups.h"


extern QueueHandle_t Queue_STEPPER_to_STPSCAN[MOTOR_IN_USE];
extern QueueHandle_t Queue_PWMIRQ_to_STPSCAN[MOTOR_IN_USE];
extern QueueHandle_t Queue_STPSCAN_to_STEPPER[MOTOR_IN_USE];

#define SCAN_MODE_TIME       0X1000
#define SCAN_MODE_ENABLE     0X2000
#define SCAN_MODE_CONTINUE   0X4000
#define MAX_PWMCOUNT         0XFFFFFFFFFFFFFFFF

static const uint8_t con_maxHomingTrail = 10;
static const float con_MaxUpLimitation  = 1.0e+5F;
static const float con_minlowLimitation = -1.0e+5F;
#define NOT_CONSTRIANTS_MOVE       STEP_STEPPING|STEP_FINDINGHOME|STEP_HOME


//how many trails to trigger up/low signal, while in home operation
#define con_maxTriggerTrail  5

void STEP_SCAN_Task(void* pvParameters);

void setSpeed_PWM(uint8_t motorId);
void setCounts_PWM(uint8_t motorId);
void move2Postion(uint8_t motorId);
void scanOneStep(uint8_t motorId);
void stateMachine(uint8_t motorId);

//find home
void findHome_switch(uint8_t motorId);
void fd_home_index_miniSwich(uint8_t motorId );
void fd_low_index_miniSwich(uint8_t motorId );
void fd_up_index_miniSwich(uint8_t motorId );
void fd_lowlimit_itsValue_miniSwich(uint8_t motorId );

//20240924 added
void fd_limt_limt_miniSwich( uint8_t motorId );

// home
void home_swich(uint8_t motorId);
void home_index_miniSwich(uint8_t motorId );
//added 20250830, for A.1;HOME is not limit
void home_index_miniSwich_A1(uint8_t motorId );
void home_first_WAIT_SIG1_DIS_A1(uint8_t motorId);
void home_secondSig1_SECOND_WAIT_SIG2_A1(uint8_t motorId);


void home_none_miniSwich( uint8_t motorId );
void low_index_miniSwich( uint8_t motorId );
void up_index_miniSwich( uint8_t motorId  );
void uplimit_itsValue_miniSwich(uint8_t motorId );
void lowlimit_itsValue_miniSwich(uint8_t motorId );
void limt_limt_miniSwich(uint8_t motorId );
void none_none_miniSwich(uint8_t motorId );


void step_miniSwich(uint8_t motorId);
void step_withSpeed_miniSwich(uint8_t motorId);
void scan_step_miniSwich(uint8_t motorId);

float differenceCal_start(uint8_t motorId);
void continue_scan_miniSwich(uint8_t motorId);

void setSpeed_PWM_continueScan(uint8_t motorId);
void scanOneStep_Contimue(uint8_t motorId);
void move2p_miniswich(uint8_t motorId);

void scanOneStep_withSlave(uint8_t motorId);	
void scanOneStep_withSlave_enable(uint8_t motorId);

void scanOneStep_Contimue_withslave(uint8_t motorId);


void Limitations_Control(uint8_t motorId);
void setDirection(uint8_t motorId);

void     checkCollision(uint8_t motorId);
uint16_t getCollision(uint8_t motorId);

void setDirectionForStep(uint8_t motorId,uint8_t inputDirection);

void checkUplimtSignal(uint8_t motorId);
uint16_t getUpLimSig(uint8_t motorId);

void checkLowlimtSignal(uint8_t motorId);
uint16_t getLowLimSig(uint8_t motorId);
void home_pre_HOME_PRE(uint8_t motorId);
void home_first_WAIT_SIG1_DIS(uint8_t motorId);
void home_sig1_dnotshow_back2_HOME_PRE(uint8_t motorId);
void home_preStop_readyfor_FIRST(uint8_t motorId);
void home_sigDis_SECOND_WAIT_SIG1(uint8_t motorId);
void home_secondSig1_SECOND_WAIT_SIG2(uint8_t motorId);
float findmin(float* pbuff,const uint8_t len);
float findmax(float* pbuff,const uint8_t len);


void Test_lowsignal(uint8_t motorId);
void Test_UPsignal(uint8_t motorId);
void test_limt_limt(uint8_t motorId);

void displayCaptureUnit(void);
static void ee_Delay(__IO uint32_t nCount);	 //�򵥵���ʱ����

int chekBackLash(uint8_t motorId);

#endif /* __USART1_H */
