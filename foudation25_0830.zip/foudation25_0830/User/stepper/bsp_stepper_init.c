/**
  ******************************************************************************
  * @file    bsp_stepper_init.c
  * @author  fire
  * @version V1.0
  * @date    2019-xx-xx
  * @brief   ���������ʼ��
  ******************************************************************************
  * @attention
  *
  * ʵ��ƽ̨:Ұ��  STM32 H743 ������  
  * ��̳    :http://www.firebbs.cn
  * �Ա�    :http://firestm32.taobao.com
  *
  ******************************************************************************
  */
#include "./stepper/bsp_stepper_init.h"
#include "./stepper/bsp_scan.h"
#include "./usart/bsp_debug_usart.h"

/* FreeRTOSͷ�ļ� */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "semphr.h"
#include "./control/bsp_ctrl.h"
#include "./pid/bsp_pid.h"
#include "./i2c_io/bsp_i2c_ee.h"
#include "./i2c_io/bsp_i2c_gpio.h"
/* ��ʱ����� */
TIM_HandleTypeDef TIM_StepperHandle;
extern _pid speed_pid[MOTOR_IN_USE],move_pid[MOTOR_IN_USE];
extern _EEPROM_CONF_STEP   ee_conFile[MOTOR_IN_USE];
master_slave_struct masterSlaveStruct={NO_SLAVE,0,0,CHANNEL_NOTREADY,CHANNEL_NOTREADY};
extern _EEPROM_STATE_STEP state_motor_struct[MOTOR_IN_USE];
extern unsigned long long int   lastCountInPWM_IRQ[    MOTOR_IN_USE ];
extern unsigned long long int   CurrentCountInPWM_IRQ[ MOTOR_IN_USE ];
/* ����������� */
Stepper_TypeDef step_motor[MOTOR_IN_USE] = 
{
  {MOTOR_PUL1_PIN, MOTOR_DIR1_PIN, MOTOR_EN1_PIN, MOTOR_PUL1_CHANNEL, MOTOR_PUL1_PORT, MOTOR_DIR1_GPIO_PORT, MOTOR_EN1_GPIO_PORT, 
  MOTOR_POS1_PIN,  MOTOR_NEG1_PIN,  MOTOR_INDEX1_PIN,  MOTOR_HOME1_PIN, MOTOR_COLLISION1_PIN,
  MOTOR_POS1_PORT, MOTOR_NEG1_PORT, MOTOR_INDEX1_PORT, MOTOR_HOME1_PORT,MOTOR_COLLISION1_PORT,0},

  {MOTOR_PUL2_PIN, MOTOR_DIR2_PIN, MOTOR_EN2_PIN, MOTOR_PUL2_CHANNEL, MOTOR_PUL2_PORT, MOTOR_DIR2_GPIO_PORT, MOTOR_EN2_GPIO_PORT,
  MOTOR_POS2_PIN,  MOTOR_NEG2_PIN,  MOTOR_INDEX2_PIN,  MOTOR_HOME2_PIN,  MOTOR_COLLISION2_PIN,
  MOTOR_POS2_PORT, MOTOR_NEG2_PORT, MOTOR_INDEX2_PORT, MOTOR_HOME2_PORT, MOTOR_COLLISION2_PORT,0},

  {MOTOR_PUL3_PIN, MOTOR_DIR3_PIN, MOTOR_EN3_PIN, MOTOR_PUL3_CHANNEL, MOTOR_PUL3_PORT, MOTOR_DIR3_GPIO_PORT, MOTOR_EN3_GPIO_PORT,
  MOTOR_POS3_PIN,  MOTOR_NEG3_PIN,  MOTOR_INDEX3_PIN,  MOTOR_HOME3_PIN,  MOTOR_COLLISION3_PIN,
  MOTOR_POS3_PORT, MOTOR_NEG3_PORT, MOTOR_INDEX3_PORT, MOTOR_HOME3_PORT, MOTOR_COLLISION3_PORT,0},
//  {MOTOR_PUL4_PIN, MOTOR_DIR4_PIN, MOTOR_EN4_PIN, MOTOR_PUL4_CHANNEL, MOTOR_PUL4_PORT, MOTOR_DIR4_GPIO_PORT, MOTOR_EN4_GPIO_PORT, 250},
};
uint16_t  GPIO_input_enable_pin[4]       = {INPUT_EN0_PIN,INPUT_EN3_PIN,INPUT_EN2_PIN,INPUT_EN1_PIN};
GPIO_TypeDef* GPIO_input_enable_port[4]  = {INPUT_EN0_GPIO_PORT,INPUT_EN3_GPIO_PORT,INPUT_EN2_GPIO_PORT,INPUT_EN1_GPIO_PORT};

uint16_t  GPIO_output_enable_pin[4]      = {OUTPUT_EN0_PIN,OUTPUT_EN1_PIN,OUTPUT_EN2_PIN,OUTPUT_EN3_PIN};
GPIO_TypeDef* GPIO_output_enable_port[4] = {OUTPUT_EN0_GPIO_PORT,OUTPUT_EN1_GPIO_PORT,OUTPUT_EN2_GPIO_PORT,OUTPUT_EN3_GPIO_PORT};


// for HOME and Find home operation

uint16_t      GPIO_signal1_pin[MOTOR_IN_USE];
GPIO_TypeDef* GPIO_signal1_port[MOTOR_IN_USE] ;
uint16_t      GPIO_signal2_pin[MOTOR_IN_USE];
GPIO_TypeDef* GPIO_signal2_port[MOTOR_IN_USE] ;
static GPIO_PinState outState[MOTOR_IN_USE]={GPIO_PIN_RESET,GPIO_PIN_RESET,GPIO_PIN_RESET};

int64_t       countInPWM_noIndex[MOTOR_IN_USE]={0,0,0};
/**
  * @brief  �ж����ȼ�����
  * @param  ��
  * @retval ��
  */
static void TIMx_NVIC_Configuration(void)
{
  /* �����ж����� */
  HAL_NVIC_SetPriority(MOTOR_PUL_IRQn,3, 0);
	//HAL_NVIC_SetPriority(MOTOR_PUL_IRQn,0, 0);
  HAL_NVIC_EnableIRQ(MOTOR_PUL_IRQn);
}

/**
  * @brief  ����TIM�������PWMʱ�õ���I/O
  * @param  ��
  * @retval ��
  */
static void Stepper_GPIO_Config(void)
{
	GPIO_InitTypeDef GPIO_InitStruct;
  
 // MOTOR_DIR1_GPIO_CLK_ENABLE();
 // MOTOR_EN1_GPIO_CLK_ENABLE();
  MOTOR_PUL1_GPIO_CLK_ENABLE();
  MOTOR_POS1_GPIO_CLK_ENABLE();
  MOTOR_NEG1_GPIO_CLK_ENABLE();	
  MOTOR_INDEX1_GPIO_CLK_ENABLE();	
  MOTOR_HOME1_GPIO_CLK_ENABLE();	
  MOTOR_COLLISION1_GPIO_CLK_ENABLE();	
		
  //MOTOR_DIR2_GPIO_CLK_ENABLE();
  //MOTOR_EN2_GPIO_CLK_ENABLE();
  MOTOR_PUL2_GPIO_CLK_ENABLE();
  MOTOR_POS2_GPIO_CLK_ENABLE();
  MOTOR_NEG2_GPIO_CLK_ENABLE();	
  MOTOR_INDEX2_GPIO_CLK_ENABLE();	
  MOTOR_HOME2_GPIO_CLK_ENABLE();	
  MOTOR_COLLISION2_GPIO_CLK_ENABLE();

  //MOTOR_DIR3_GPIO_CLK_ENABLE();
 // MOTOR_EN3_GPIO_CLK_ENABLE();
  MOTOR_PUL3_GPIO_CLK_ENABLE();
  MOTOR_POS3_GPIO_CLK_ENABLE();
  MOTOR_NEG3_GPIO_CLK_ENABLE();	
  MOTOR_INDEX3_GPIO_CLK_ENABLE();	
  MOTOR_HOME3_GPIO_CLK_ENABLE();	
  MOTOR_COLLISION3_GPIO_CLK_ENABLE();
	
  //MOTOR_DIR4_GPIO_CLK_ENABLE();
 // MOTOR_EN4_GPIO_CLK_ENABLE();
 // MOTOR_PUL4_GPIO_CLK_ENABLE();




  /* ��ȡ����Ԫ�ظ��� */
  uint8_t member_count = sizeof(step_motor)/sizeof(Stepper_TypeDef);

  for(uint8_t i = 0; i < member_count; i++)
  {
    /*ѡ��Ҫ���Ƶ�GPIO����*/															   
    GPIO_InitStruct.Pin = step_motor[i].dir_pin;	
    /*�������ŵ��������Ϊ�������*/
    GPIO_InitStruct.Mode  = GPIO_MODE_OUTPUT_PP;  
    GPIO_InitStruct.Pull =GPIO_PULLUP;
    /*������������Ϊ���� */   
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
    /*Motor �������� ��ʼ��*/
    HAL_GPIO_Init(step_motor[i].dir_port, &GPIO_InitStruct);
   // MOTOR_DIR(step_motor[i].dir_port, step_motor[i].dir_pin, CW);
    
    /*Motor ʹ������ ��ʼ��*/
    GPIO_InitStruct.Pin = step_motor[i].en_pin;
    HAL_GPIO_Init(step_motor[i].en_port, &GPIO_InitStruct);
    //MOTOR_OFFLINE(step_motor[i].en_port, step_motor[i].en_pin, ON);

    /* ��ʱ�����ͨ����������IO��ʼ�� */
    /*�����������*/
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    /*������������ */ 
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
    /*���ø���*/
    GPIO_InitStruct.Alternate = MOTOR_PUL_GPIO_AF;
    /*���ø���*/
    GPIO_InitStruct.Pull = GPIO_PULLUP;
    /*ѡ��Ҫ���Ƶ�GPIO����*/	
    GPIO_InitStruct.Pin = step_motor[i].pul_pin;
    /*Motor �������� ��ʼ��*/
    HAL_GPIO_Init(step_motor[i].pul_port, &GPIO_InitStruct);
  }
  //�����ж�ʹ��
  for(uint8_t i = 0; i < member_count; i++)
    {
      /*ѡ��Ҫ���Ƶ�GPIO����*/															   
      GPIO_InitStruct.Pin = step_motor[i].limP_pin;	
      /*��������Ϊ����ģʽ*/
      GPIO_InitStruct.Mode  = GPIO_MODE_INPUT;  
    /* �������Ų�����Ҳ������ */      
      GPIO_InitStruct.Pull =GPIO_NOPULL;
      /*Motor �������� ��ʼ��*/
      HAL_GPIO_Init(step_motor[i].limP_port, &GPIO_InitStruct);

      GPIO_InitStruct.Pin = step_motor[i].limN_pin;	
      HAL_GPIO_Init(step_motor[i].limN_port, &GPIO_InitStruct);

      GPIO_InitStruct.Pin = step_motor[i].home_pin;	
      HAL_GPIO_Init(step_motor[i].home_port, &GPIO_InitStruct);
      
      GPIO_InitStruct.Pin = step_motor[i].index_pin;	
      HAL_GPIO_Init(step_motor[i].index_port, &GPIO_InitStruct);

      GPIO_InitStruct.Pin = step_motor[i].collision_pin;	
      HAL_GPIO_Init(step_motor[i].collision_port, &GPIO_InitStruct);
    }

   input_output_enable_GPIO();
    /* ���� EXTI �ж�Դ ��key1 ���š������ж����ȼ�*/
  //  HAL_NVIC_SetPriority(KEY1_INT_EXTI_IRQ, 7, 0);
    /* ʹ���ж� */
  //  HAL_NVIC_EnableIRQ(KEY1_INT_EXTI_IRQ);

}

/*
 * ע�⣺TIM_TimeBaseInitTypeDef�ṹ��������5����Ա��TIM6��TIM7�ļĴ�������ֻ��
 * TIM_Prescaler��TIM_Period������ʹ��TIM6��TIM7��ʱ��ֻ���ʼ����������Ա���ɣ�
 * ����������Ա��ͨ�ö�ʱ���͸߼���ʱ������.
 *-----------------------------------------------------------------------------
 * TIM_Prescaler         ����
 * TIM_CounterMode			 TIMx,x[6,7]û�У��������У�������ʱ����
 * TIM_Period            ����
 * TIM_ClockDivision     TIMx,x[6,7]û�У���������(������ʱ��)
 * TIM_RepetitionCounter TIMx,x[1,8]����(�߼���ʱ��)
 *-----------------------------------------------------------------------------
 */
static void TIM_PWMOUTPUT_Config(void)
{
	TIM_OC_InitTypeDef  TIM_OCInitStructure;

  /* ��ȡ����Ԫ�ظ��� */
  uint8_t member_count = sizeof(step_motor)/sizeof(Stepper_TypeDef);
  uint8_t i ;
	/*ʹ�ܶ�ʱ��*/
	MOTOR_PUL_CLK_ENABLE();

	TIM_StepperHandle.Instance = MOTOR_PUL_TIM;    
	/* �ۼ� TIM_Period�������һ�����»����ж�*/		
	//����ʱ����0������TIM_PERIOD����ΪTIM_PERIOD�Σ�Ϊһ����ʱ����
	TIM_StepperHandle.Init.Period = TIM_PERIOD;
	// ͨ�ÿ��ƶ�ʱ��ʱ��ԴTIMxCLK = HCLK/2=168MHz 
	// �趨��ʱ��Ƶ��Ϊ=TIMxCLK/(TIM_Prescaler+1)=2MHz
	TIM_StepperHandle.Init.Prescaler = TIM_PRESCALER-1;                

	/*������ʽ*/
	TIM_StepperHandle.Init.CounterMode = TIM_COUNTERMODE_UP;            
	/*����ʱ�ӷ�Ƶ*/	
	TIM_StepperHandle.Init.ClockDivision=TIM_CLOCKDIVISION_DIV1;   
	TIM_StepperHandle.Init.RepetitionCounter = 0 ;  		
	/*��ʼ����ʱ��*/
	HAL_TIM_OC_Init(&TIM_StepperHandle);

	/*PWMģʽ����--��������Ϊ����Ƚ�ģʽ*/
	TIM_OCInitStructure.OCMode = TIM_OCMODE_TOGGLE; 
	/*�Ƚ�����ļ���ֵ*/
	TIM_OCInitStructure.Pulse = TIM_PERIOD;                    
	/*����ʱ������ֵС��CCR1_ValʱΪ�ߵ�ƽ*/
	TIM_OCInitStructure.OCPolarity = TIM_OCPOLARITY_HIGH;          
	/*���û���ͨ������ļ���*/
	TIM_OCInitStructure.OCNPolarity = TIM_OCNPOLARITY_LOW; 
	/*����ģʽ����*/
	TIM_OCInitStructure.OCFastMode = TIM_OCFAST_DISABLE;   
	/*���е�ƽ*/
	TIM_OCInitStructure.OCIdleState = TIM_OCIDLESTATE_RESET;  
	/*����ͨ������*/
	TIM_OCInitStructure.OCNIdleState = TIM_OCNIDLESTATE_RESET;
  
  for( i = 0; i < member_count; i++)
  {
    /* �����Ƚ������ʹ���ж� */
    HAL_TIM_OC_ConfigChannel(&TIM_StepperHandle, &TIM_OCInitStructure, step_motor[i].pul_channel);
    //HAL_TIM_OC_Start_IT(&TIM_StepperHandle, step_motor[i].pul_channel);
  }
  
  /* ������ʱ�� */
	HAL_TIM_Base_Start(&TIM_StepperHandle);
}

/**
  * @brief  ��ʱ���жϷ�����
	*	@note   ��
  * @retval ��
  */
void MOTOR_PUL_IRQHandler(void)
{
  HAL_TIM_IRQHandler(&TIM_StepperHandle);
}




/**
  * @brief  ��ʱ���Ƚ��жϻص�����
  * @param  htim����ʱ�����ָ��
	*	@note   ��
  * @retval ��
  */
 static int interruptindex = 0;

void HAL_TIM_OC_DelayElapsedCallback(TIM_HandleTypeDef *htim)
{
  uint32_t channel = htim->Channel;
  /* ��ȡ��ǰ���� */
  uint32_t count = __HAL_TIM_GET_COUNTER(htim);
  float tempF = 0.0;
  float tempF_1 = 0.0;
  float tempF_2 = 0.0;
  double dbSum = 0.0;
  switch(channel)
  {
    case HAL_TIM_ACTIVE_CHANNEL_1:
      /* ���ñȽ���ֵ */
		  __HAL_TIM_SET_COMPARE(&TIM_StepperHandle, MOTOR_PUL1_CHANNEL, count + step_motor[0].oc_pulse_num);
     //����ָ��������ֹͣ��
 		  if( (step_motor[0].this_state->miniState.state & STATE_RUN_OR_NOT) == STATE_RUN_OR_NOT ){
				
				step_motor[0].this_state->miniState.state |= STATE_RUN_OR_NOT;
				if(step_motor[0].this_state->countInPWM_IRQ >0){
				    step_motor[0].this_state->countInPWM_IRQ --;
            if(1 == step_motor[0].this_state->pulse_out_or_not){
             if(0 == step_motor[0].this_state->countInPWM_IRQ % 8 ){
                outState[0] = ~outState[0];	 
                HAL_GPIO_WritePin(GPIO_output_enable_port[0],GPIO_output_enable_pin[0] ,(outState[0]));
              }
            }
        }else{
						stepper_Stop(step_motor[0].pul_channel);	
						stop_state(0);
            if( STEP_MOVE2_POSITION == (STEP_MOVE2_POSITION & step_motor[0].this_state->stateMachine)){
              if( -1 == step_motor[0].this_state->flag_backlash ){
                step_motor[0].this_state->miniState.valueSet += ee_conFile[0].backlash;
                step_motor[0].this_state->flag_backlash = 0;
              }
              if( 1 == step_motor[0].this_state->flag_backlash){
                step_motor[0].this_state->miniState.valueSet -= ee_conFile[0].backlash;
                step_motor[0].this_state->flag_backlash = 0;
              }
            }           
        }
        //20240925 delete the second condition. 
        // if there is no encoder, use the following method to record actual position
        if(( ENCODER_AVAILABLE_HCONF1 != ( ENCODER_AVAILABLE_HCONF1 & ee_conFile[0].this_HCONF.hconf1))//&&( INDEX_AVAILABLE_HCONF1   == ( INDEX_AVAILABLE_HCONF1 & ee_conFile[0].this_HCONF.hconf1))
            ){//NO encoder,But index Exists
						 tempF =1.0/ (2.0*ee_conFile[0].gearRatio*ee_conFile[0].microStep*ee_conFile[0].fullStep);
						/* if(0 != tempF){
                 tempF = 1.0/tempF;		
             }*/	
						//printf("tempf: %f",tempF);
						 if(( step_motor[0].this_state->miniState.valueSet - step_motor[0].this_state->miniState.valueActual)>= 0){//up
                countInPWM_noIndex[0] ++;
                step_motor[0].this_state->miniState.valueActual = step_motor[0].this_state->miniState.valueActual +tempF;
             }
             else{//down
                countInPWM_noIndex[0] --;
                step_motor[0].this_state->miniState.valueActual =step_motor[0].this_state->miniState.valueActual- tempF;
							  //printf("valAct: %f",step_motor[0].this_state->miniState.valueActual);
             }
        }
        
			}
		  break;
    case HAL_TIM_ACTIVE_CHANNEL_2:
      /* ���ñȽ���ֵ */
      __HAL_TIM_SET_COMPARE(&TIM_StepperHandle, MOTOR_PUL2_CHANNEL, count + step_motor[1].oc_pulse_num);
      if( (step_motor[1].this_state->miniState.state & STATE_RUN_OR_NOT) == STATE_RUN_OR_NOT  ){
          if(step_motor[1].this_state->countInPWM_IRQ >0){
             step_motor[1].this_state->countInPWM_IRQ --;
            if(1 == step_motor[1].this_state->pulse_out_or_not){
             if(0 == step_motor[1].this_state->countInPWM_IRQ % 8 ){
                outState[1] = ~outState[1];	 
                HAL_GPIO_WritePin(GPIO_output_enable_port[1],GPIO_output_enable_pin[1] ,(outState[1]));
              }
            }
          }else{
            stepper_Stop(step_motor[1].pul_channel);
            stop_state(1);
            if( STEP_MOVE2_POSITION == (STEP_MOVE2_POSITION & step_motor[1].this_state->stateMachine)){
              if( -1 == step_motor[1].this_state->flag_backlash ){
                step_motor[1].this_state->miniState.valueSet += ee_conFile[1].backlash;
                step_motor[1].this_state->flag_backlash = 0;
              }
              if( 1 == step_motor[1].this_state->flag_backlash){
                step_motor[1].this_state->miniState.valueSet -= ee_conFile[1].backlash;
                step_motor[1].this_state->flag_backlash = 0;
              }
            }             
          }
         if(( ENCODER_AVAILABLE_HCONF1 != ( ENCODER_AVAILABLE_HCONF1 & ee_conFile[1].this_HCONF.hconf1))&&
           ( INDEX_AVAILABLE_HCONF1   == ( INDEX_AVAILABLE_HCONF1 & ee_conFile[1].this_HCONF.hconf1)) ){//NO encoder,But index Exists
						 tempF_1 = (2.0*ee_conFile[1].gearRatio*ee_conFile[1].microStep*ee_conFile[1].fullStep);
						 if(0 != tempF_1){
                 tempF_1 = 1.0/tempF_1;		
             }	
             if(( step_motor[1].this_state->miniState.valueSet - step_motor[1].this_state->miniState.valueActual)>= 0){//up
                countInPWM_noIndex[1] ++;
                step_motor[1].this_state->miniState.valueActual += tempF_1;
             }
             else{//down
                countInPWM_noIndex[1] --;
                step_motor[1].this_state->miniState.valueActual -= tempF_1;               
             }
         }
       } 				
		break;
    case HAL_TIM_ACTIVE_CHANNEL_3:
		  __HAL_TIM_SET_COMPARE(&TIM_StepperHandle, MOTOR_PUL3_CHANNEL, count + step_motor[2].oc_pulse_num);
     if( (step_motor[2].this_state->miniState.state & STATE_RUN_OR_NOT) ==STATE_RUN_OR_NOT  ) {
         if(step_motor[2].this_state->countInPWM_IRQ > 0 ){
           step_motor[2].this_state->countInPWM_IRQ --;
           if(1 == step_motor[2].this_state->pulse_out_or_not){
             if(0 == step_motor[2].this_state->countInPWM_IRQ % 8 ){
                outState[2] = ~outState[2];	 
                HAL_GPIO_WritePin(GPIO_output_enable_port[2],GPIO_output_enable_pin[2] ,(outState[2]));
              }
            }
         }else{
          stepper_Stop(step_motor[2].pul_channel);
          stop_state(2);
            if( STEP_MOVE2_POSITION == (STEP_MOVE2_POSITION & step_motor[2].this_state->stateMachine)){
              if( -1 == step_motor[2].this_state->flag_backlash ){
                step_motor[2].this_state->miniState.valueSet += ee_conFile[2].backlash;
                step_motor[2].this_state->flag_backlash = 0;
              }
              if( 1 == step_motor[2].this_state->flag_backlash){
                step_motor[2].this_state->miniState.valueSet -= ee_conFile[2].backlash;
                step_motor[2].this_state->flag_backlash = 0;
              }
            }          
         }

        if(( ENCODER_AVAILABLE_HCONF1 != ( ENCODER_AVAILABLE_HCONF1 & ee_conFile[2].this_HCONF.hconf1))&&
           ( INDEX_AVAILABLE_HCONF1   == ( INDEX_AVAILABLE_HCONF1 & ee_conFile[2].this_HCONF.hconf1)) ){//NO encoder,But index Exists
						 tempF_2 = (2.0*ee_conFile[2].gearRatio*ee_conFile[2].microStep*ee_conFile[2].fullStep);
						 if(0 != tempF_2){
                 tempF_2 = 1.0/tempF_2;		
             }						 
             if(( step_motor[2].this_state->miniState.valueSet - step_motor[2].this_state->miniState.valueActual)>= 0){//up
                countInPWM_noIndex[2] ++;
                step_motor[2].this_state->miniState.valueActual += tempF_2;
             }
             else{//down
                countInPWM_noIndex[2] --;
                step_motor[2].this_state->miniState.valueActual -= tempF_2;
             }
        }
       } 
      break;
    case HAL_TIM_ACTIVE_CHANNEL_4:
      /* ���ñȽ���ֵ */
    //  __HAL_TIM_SET_COMPARE(&TIM_StepperHandle, MOTOR_PUL4_CHANNEL, count + step_motor[3].oc_pulse_num);
      break;
  }
}


/**
  * @brief  ���������ʼ��
  * @param  *step_motor����������ṹ��ָ��
  * @param  member_count����Ҫ��ʼ���Ĳ����������
	*	@note   ��
  * @retval ��
  */
void stepper_Init(void)
{
	/*���IO����*/
	Stepper_GPIO_Config();
	/*��ʱ��PWM�������*/
	TIM_PWMOUTPUT_Config();
	/*�ж�����*/
	TIMx_NVIC_Configuration();
	int i;
	for(i = 0; i < MOTOR_IN_USE; i++)
	{
		stepper_Stop(step_motor[i].pul_channel);
	}
	
}

/**
  * @brief  �������
  * @param  channel�����ͨ��
	*	@note   ��
  * @retval ��
  */
//void stepper_Start(uint32_t channel)
/*
0:  could not start
-1: start successfully
*/
int stepper_Start(uint32_t channel)
{
 uint32_t i=0;
 uint32_t delayForStart = 0x10000;
 uint32_t motorId = 0;
 uint32_t result = 0xffffffff;
 uint32_t tempHong   = NOT_CONSTRIANTS_MOVE;

 //	printf("channel is: %d !\n",channel);  
  if(8 == channel){
    motorId = 2;
  }
  if(4 == channel){
    motorId = 1;
  }
  if(0 == channel){
    motorId = 0;
  }
  result = ((uint32_t)step_motor[motorId].this_state->stateMachine & tempHong);
  if(0 != result){

      if(8 == channel){
          MOTOR_OFFLINE(MOTOR_EN3_GPIO_PORT, MOTOR_EN3_PIN, ON); 
          for(i = delayForStart; i >0; i --);       
          HAL_TIM_OC_Start_IT(&TIM_StepperHandle, TIM_CHANNEL_3);
          TIM_CCxChannelCmd(MOTOR_PUL_TIM, TIM_CHANNEL_3, TIM_CCx_ENABLE);
      }else{
          if(4 == channel){
              MOTOR_OFFLINE(MOTOR_EN2_GPIO_PORT, MOTOR_EN2_PIN, ON);    
              for(i = delayForStart; i >0; i --);
              HAL_TIM_OC_Start_IT(&TIM_StepperHandle, TIM_CHANNEL_2);
              TIM_CCxChannelCmd(MOTOR_PUL_TIM, TIM_CHANNEL_2, TIM_CCx_ENABLE);
          }else if(0 == channel){
              MOTOR_OFFLINE(MOTOR_EN1_GPIO_PORT, MOTOR_EN1_PIN, ON);
              //printf("prepare\n");      
              for(i = delayForStart; i >0; i --);
              //printf("Go\n");      
              HAL_TIM_OC_Start_IT(&TIM_StepperHandle, TIM_CHANNEL_1);
              TIM_CCxChannelCmd(MOTOR_PUL_TIM, TIM_CHANNEL_1, TIM_CCx_ENABLE);
          }  
      }

   return -1;
  }
 // if current state is one of COLLISION /  UPPER SIGNAL / LOWER SIGNAL , couldn't start
  checkCollision(motorId);
  checkUplimtSignal(motorId);
  checkLowlimtSignal(motorId);
  if(STATE_COLLISION_OR_NOT == getCollision(motorId)){
   return 0;
  } 
  if(STATE_UPPER_OR_NOT == getUpLimSig(motorId)){
		if( step_motor[motorId].this_state->miniState.valueSet <= step_motor[motorId].this_state->miniState.valueActual){
		}
		else{
				return 0;
		}
  } 
  if(STATE_LOWER_OR_NOT == getLowLimSig(motorId)){
    //now is smaller than the lower signal ,if set value is greater than actualvalue ,then motor can go 
		if( step_motor[motorId].this_state->miniState.valueSet >= step_motor[motorId].this_state->miniState.valueActual){
		}
		else{
			printf("Setv: %f\n",step_motor[motorId].this_state->miniState.valueSet);
      printf("valueActual is %f \n",step_motor[motorId].this_state->miniState.valueSet);	   
			
				return 0;
		}
  }

  if(8 == channel){
			MOTOR_OFFLINE(MOTOR_EN3_GPIO_PORT, MOTOR_EN3_PIN, ON); 
			for(i = delayForStart; i >0; i --);       
			HAL_TIM_OC_Start_IT(&TIM_StepperHandle, TIM_CHANNEL_3);
			TIM_CCxChannelCmd(MOTOR_PUL_TIM, TIM_CHANNEL_3, TIM_CCx_ENABLE);
  }
  if(4 == channel){
			MOTOR_OFFLINE(MOTOR_EN2_GPIO_PORT, MOTOR_EN2_PIN, ON);    
			for(i = delayForStart; i >0; i --);
			HAL_TIM_OC_Start_IT(&TIM_StepperHandle, TIM_CHANNEL_2);
			TIM_CCxChannelCmd(MOTOR_PUL_TIM, TIM_CHANNEL_2, TIM_CCx_ENABLE);
  }
  if(0 == channel){
			MOTOR_OFFLINE(MOTOR_EN1_GPIO_PORT, MOTOR_EN1_PIN, ON);
			for(i = delayForStart; i >0; i --);
			HAL_TIM_OC_Start_IT(&TIM_StepperHandle, TIM_CHANNEL_1);
			TIM_CCxChannelCmd(MOTOR_PUL_TIM, TIM_CHANNEL_1, TIM_CCx_ENABLE);
  }
  return -1;

}

/**
  * @brief  ֹͣ���
  * @param  channel�����ͨ��
	*	@note   ��
  * @retval ��
  */
void stepper_Stop(uint32_t channel)
{
  TIM_CCxChannelCmd(MOTOR_PUL_TIM, channel, TIM_CCx_DISABLE);
  HAL_TIM_OC_Stop_IT(&TIM_StepperHandle, channel);
  /*
  if(8 == channel){
    MOTOR_OFFLINE(MOTOR_EN3_GPIO_PORT, MOTOR_EN3_PIN, HIGH);
  }
  if(4 == channel){
    MOTOR_OFFLINE(MOTOR_EN2_GPIO_PORT, MOTOR_EN2_PIN, HIGH);
  }
  if(0 == channel){
    MOTOR_OFFLINE(MOTOR_EN1_GPIO_PORT, MOTOR_EN1_PIN, HIGH);
  }
*/
// 20241012 �ߵ�ƽ ��Ϊ�͵�ƽ����ס�缫
  if(8 == channel){
    MOTOR_OFFLINE(MOTOR_EN3_GPIO_PORT, MOTOR_EN3_PIN, LOW);
  }
  if(4 == channel){
    MOTOR_OFFLINE(MOTOR_EN2_GPIO_PORT, MOTOR_EN2_PIN, LOW);
  }
  if(0 == channel){
    MOTOR_OFFLINE(MOTOR_EN1_GPIO_PORT, MOTOR_EN1_PIN, LOW);
  }
 /*
 if(8 == channel){
      HAL_TIM_OC_Stop_IT(&TIM_StepperHandle, TIM_CHANNEL_3);
		  TIM_CCxChannelCmd(MOTOR_PUL_TIM, TIM_CHANNEL_3, TIM_CCx_DISABLE);
  }
  if(4 == channel){
      HAL_TIM_OC_Stop_IT(&TIM_StepperHandle, TIM_CHANNEL_2);
			TIM_CCxChannelCmd(MOTOR_PUL_TIM, TIM_CHANNEL_2, TIM_CCx_DISABLE);
  }
  if(0 == channel){
      HAL_TIM_OC_Stop_IT(&TIM_StepperHandle, TIM_CHANNEL_1);
			TIM_CCxChannelCmd(MOTOR_PUL_TIM, TIM_CHANNEL_1, TIM_CCx_DISABLE);
  }    */
}
void stop_state(uint8_t port)
{
  step_motor[port].this_state->miniState.state |=	STATE_IDLE_OR_NOT ;
  step_motor[port].this_state->miniState.state &=	~STATE_RUN_OR_NOT ;
  step_motor[port].this_state->miniState.state &=  ~STATE_LOCK_OR_NOT; 
  
  step_motor[port].this_state->stateMachine   |= STEP_STOP;
	speed_pid[port].last_count = 0;
  speed_pid[port].actual_val = 0;
  speed_pid[port].err        = 0;
  speed_pid[port].err_last   = 0;
  speed_pid[port].err_next   = 0;
  speed_pid[port].cont_val   = 0;
	
	move_pid[port].last_count = 0;
  move_pid[port].actual_val = 0;
  move_pid[port].err        = 0;
  move_pid[port].err_last   = 0;
  move_pid[port].err_next   = 0;
  move_pid[port].cont_val   = 0;
  if((SLAVE_EXIST == masterSlaveStruct.slave_exist)&&
     ( STEP_MOVE2_POSITION != (STEP_MOVE2_POSITION & step_motor[port].this_state->stateMachine))) {

      if(port == masterSlaveStruct.master_ch){
        masterSlaveStruct.master_ready = CHANNEL_READY;
       // printf("m ready in stop\n");	
      }else{
        masterSlaveStruct.slave_ready = CHANNEL_READY;
       // printf("s ready in stop\n");	
      }
  }
  //2023 08 17 ADDED
  countInPWM_noIndex[       port] = 0;
  CurrentCountInPWM_IRQ[ port] = countInPWM_noIndex[       port] ;
  lastCountInPWM_IRQ[    port] = countInPWM_noIndex[       port] ;

}
void start_state(uint8_t port)
{
  //int i=0;
  //for(i = 0xfff0; i >0; i --); 
  step_motor[port].this_state->miniState.state &=	~STATE_IDLE_OR_NOT ;
  step_motor[port].this_state->miniState.state |=	STATE_RUN_OR_NOT ;
  step_motor[port].this_state->miniState.state &=  ~STATE_LOCK_OR_NOT;
  //step_motor[port].this_state->stateMachine &= ~STEP_STOP;

}

void input_output_enable_GPIO(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;

    INPUT_EN0_GPIO_CLK_ENABLE();
    INPUT_EN1_GPIO_CLK_ENABLE();
		INPUT_EN2_GPIO_CLK_ENABLE();
		INPUT_EN3_GPIO_CLK_ENABLE();

		OUTPUT_EN0_GPIO_CLK_ENABLE();
		OUTPUT_EN1_GPIO_CLK_ENABLE();
    OUTPUT_EN2_GPIO_CLK_ENABLE();
    OUTPUT_EN3_GPIO_CLK_ENABLE();


    GPIO_InitStructure.Pin = INPUT_EN0_PIN; 
    /*��������Ϊ����ģʽ*/
    GPIO_InitStructure.Mode = GPIO_MODE_INPUT; 
    /*�������Ų�����Ҳ������*/
    GPIO_InitStructure.Pull = GPIO_NOPULL;

    HAL_GPIO_Init(INPUT_EN0_GPIO_PORT, &GPIO_InitStructure);


    GPIO_InitStructure.Pin = INPUT_EN1_PIN; 
    HAL_GPIO_Init(INPUT_EN1_GPIO_PORT, &GPIO_InitStructure);
	
		GPIO_InitStructure.Pin = INPUT_EN2_PIN; 
		HAL_GPIO_Init(INPUT_EN2_GPIO_PORT, &GPIO_InitStructure);
		
		GPIO_InitStructure.Pin = INPUT_EN3_PIN; 
		HAL_GPIO_Init(INPUT_EN3_GPIO_PORT, &GPIO_InitStructure);
		

    GPIO_InitStructure.Pin = OUTPUT_EN0_PIN; 
    GPIO_InitStructure.Mode  = GPIO_MODE_OUTPUT_PP;  
    GPIO_InitStructure.Pull =GPIO_PULLUP;
    GPIO_InitStructure.Speed = GPIO_SPEED_FREQ_HIGH;

    HAL_GPIO_Init(OUTPUT_EN0_GPIO_PORT, &GPIO_InitStructure);


    GPIO_InitStructure.Pin = OUTPUT_EN1_PIN; 
    HAL_GPIO_Init(OUTPUT_EN1_GPIO_PORT, &GPIO_InitStructure);
	
		GPIO_InitStructure.Pin = OUTPUT_EN2_PIN; 
		HAL_GPIO_Init(OUTPUT_EN2_GPIO_PORT, &GPIO_InitStructure);
		
		GPIO_InitStructure.Pin = OUTPUT_EN3_PIN; 
		HAL_GPIO_Init(OUTPUT_EN3_GPIO_PORT, &GPIO_InitStructure);
	
}

void outPluse(uint8_t motorId,uint8_t level)
{
	if(0 ==level)
  HAL_GPIO_WritePin(GPIO_output_enable_port[motorId],GPIO_output_enable_pin[motorId] ,GPIO_PIN_RESET);
	else
  HAL_GPIO_WritePin(GPIO_output_enable_port[motorId],GPIO_output_enable_pin[motorId] ,GPIO_PIN_SET);		
}
/*
typedef enum
{
  GPIO_PIN_RESET = 0,
  GPIO_PIN_SET
}GPIO_PinState;*/



