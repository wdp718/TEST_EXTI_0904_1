#ifndef __BSP_STEP_MOTOR_INIT_H
#define __BSP_STEP_MOTOR_INIT_H

#include "stm32h7xx.h"
#include "stm32h7xx_hal.h"
#include "./exti/bsp_exti.h"


//

 typedef struct {
  uint16_t      state;
  float         valueSet;
  double         valueActual;
  int           valueEncoder;
  float         speedSet;
  float         speedActual; 
  float         homeDistance;
  int           homeValueApproximate;
} __attribute__((packed)) State_mini_paras_STEP;//

typedef struct {
//state
  State_mini_paras_STEP miniState;
  float         homeUsed;
  unsigned int  valueTriggeredorNot;
  unsigned int  slaveChanel;
//unsigned int  countInPWM_IRQ;
  unsigned long long int   countInPWM_IRQ;
  unsigned int  scanMode;
	unsigned int  scanTime_2_wait_ms;
  unsigned char wait_or_not;
  unsigned char enable_or_not;
  unsigned char pulse_out_or_not;
  float         scan_start;
  float         scan_stop;
  uint32_t      scan_step;
  float         scan_velosity; 
  unsigned int  stateMachine;
  //���ڳ�������shadow����
  unsigned int  scanMode_Shadow;
	unsigned int  scanTime_2_wait_ms_shadow;
  unsigned char enable_triggered;
  float         f_Start_homedistance;
  unsigned char u8_direction_down;
  unsigned char u8_direction_up;
  float         f_valueActual_test; 
  int           flag_backlash; 
} __attribute__((packed)) State_paras_STEP;//
 

//
typedef struct {
uint16_t  hconf1 ; //
uint16_t  hconf2 ; //
uint16_t  hconf3 ; //
}__attribute__((packed))HCONF;

typedef struct{
	unsigned char  homeMode;
  uint16_t*      pu16_signal1;
  uint16_t*      pu16_signal2;
  unsigned char  sig1_level;
  unsigned char  sig2_level;
  float          f_value_1;
  float          f_value_2;
	unsigned char  direction;
  uint16_t       gpio_sig1_pin;
 GPIO_TypeDef*   gpio_sig1_port;
  uint16_t       gpio_sig2_pin;
 GPIO_TypeDef*   gpio_sig2_port;

}__attribute__((packed))HOME_SIGNALS_STRUCT;

typedef struct {
uint8_t  slave_exist ; //
uint8_t  master_ch ; //
uint8_t  slave_ch ; //
uint8_t  master_ready ; //
uint8_t  slave_ready ; //
}__attribute__((packed))master_slave_struct;

#define NO_SLAVE            0X00
#define SLAVE_EXIST         0X01
#define CHANNEL_READY       0X00
#define CHANNEL_NOTREADY    0X01



//hconf1-���ޣ���Ĭ��0��
#define ENCODER_AVAILABLE_HCONF1              0X0001
#define INDEX_AVAILABLE_HCONF1                0X0002
#define LOWLIM_AVAILABLE_HCONF1               0X0004
#define UPLIM_AVAILABLE_HCONF1                0X0008
#define COLLLIM_AVAILABLE_HCONF1              0X0010
#define ENABLE_AVAILABLE_HCONF1               0X0020
#define LOW_AS_HOME_AVAILABLE_HCONF1          0X0040
#define UP_AS_HOME_AVAILABLE_HCONF1           0X0080
#define RESERVED_AVAILABLE_HCONF1             0X0100
#define RESERVED__AVAILABLEHCONF1             0X0200
#define BIT1_UNIT_AVAILABLE_HCONF1            0X0400
#define BIT2_UNIT_AVAILABLE_HCONF1            0X0800
#define BIT1_HOME_AVAILABLE_HCONF1            0X1000
#define BIT2_HOME_AVAILABLE_HCONF1            0X2000
#define BIT3_HOME_AVAILABLE_HCONF1            0X4000
#define BIT4_HOME_AVAILABLE_HCONF1            0X8000
//hconf2-�ߵ���Ч�����򣺣�Ĭ��0��
#define ENCODER_A_HIGH_HCONF2                 0X0001
#define ENCODER_B_HIGH_HCONF2                 0X0002
#define ENCODER_Z_HIGH_HCONF2                 0X0004
#define HOME_HIGH_HCONF2                      0X0008
#define INDEX_HIGH_HCONF2                     0X0010
#define LOW_LIMITIATION_HCONF2                0X0020
#define UP_LIMITIATION_HCONF2                 0X0040
#define COLLISION_HIGH_HCONF2                 0X0080
#define INPUTENABLE_HIGH_HCONF2               0X0100
#define OUTPUTENABLE_HIGH_HCONF2              0X0200
#define MOTOR_DIRECTION_HIGH_HCONF2           0X0400
#define ENCODER_DIRECTION_HIGH_HCONF2         0X0800
#define LIMITATION_DIRECTION_HCONF2           0X1000
#define INITIAL_DIRECTION_HCONF2              0X2000
#define RESERVED_HCONF2                       0X4000
#define INITIAL_AUTORUN_HCONF2                0X8000

//״̬��صĶ���,Ĭ��Ϊ0
#define STATE_HOME_OR_NOT                0X8000
#define STATE_APPRO_HOME_OR_NOT          0X4000
#define STATE_IDLE_OR_NOT                0X2000
#define STATE_RUN_OR_NOT                 0X1000
#define STATE_LOCK_OR_NOT                0X0800
#define STATE_UPPER_OR_NOT               0X0400
#define STATE_LOWER_OR_NOT               0X0200
#define STATE_COLLISION_OR_NOT           0X0100  
#define STATE_POS_WRONG_OR_NOT           0X0080     
#define STATE_OVER_CURRENT_OR_NOT        0X0040        
#define STATE_WAIT_OR_NOT                0X0020
#define STATE_ENAB_OR_NOT                0X0010
#define STATE_ROTATION_OR_NOT            0X0008    
#define STATE_UPPER_VALUE_OR_NOT         0X0004
#define STATE_lOWER_VALUE_OR_NOT         0X0002
#define STATE_ROTATION_WRONG_bit0        0X0001


            

/* ��������ṹ�� */
typedef struct{
  uint16_t pul_pin;                     //�������������ź�
  uint16_t dir_pin;                     //����������ź�
  uint16_t en_pin;                      //���ʹ�����ź�
  uint32_t pul_channel;                 //����������ͨ��
  GPIO_TypeDef *pul_port;               //����������Ŷ˿�
  GPIO_TypeDef *dir_port;               //����������Ŷ˿�
  GPIO_TypeDef *en_port;                //���ʹ�����Ŷ˿�
 //���������ж�.
  uint16_t limP_pin;                     //
  uint16_t limN_pin;                     //
  uint16_t index_pin;
  uint16_t home_pin;  
  uint16_t collision_pin;
  GPIO_TypeDef *limP_port;              //�������λ���Ŷ˿����룺
  GPIO_TypeDef *limN_port;              //�������λ���Ŷ˿����룺
  GPIO_TypeDef *index_port;              //���homeλ���Ŷ˿����룺
  GPIO_TypeDef *home_port;             //���index��λ���Ŷ˿����룺
  GPIO_TypeDef *collision_port;         //�����ײ��λ���Ŷ˿����룺
  uint16_t oc_pulse_num;                //����Ƚϼ���ֵ��ֵԽС���ת��Խ��
	State_paras_STEP* this_state;
  State_paras_STEP* slave_state;
  // for signal interrupt, home and find home operation
  uint16_t limP_pin_interrupt;                     //
  uint16_t limN_pin_interrupt;                     //
  uint16_t home_pin_interrupt;   
  uint16_t index_pin_interrupt;
  uint16_t collision_pin_interrupt; 
}Stepper_TypeDef;



#define MOTOR_IN_USE                   3


#define STEP_STOP                     0X0001
#define STEP_FINDINGHOME              0X0002
#define STEP_HOME                     0X0004
#define STEP_MOVE2_POSITION           0X0008
#define STEP_STEPPING                 0X0010
#define STEP_STEPPING_WITH_SPEED      0X0020
#define STEP_STEP_SCAN                0X0040
#define STEP_STEP_CONTINUE_SCAN       0X0080

#define STEP_STEP_SCAN_TIME           0X0100
#define STEP_STEP_SCAN_ENAB           0X0200

#define STEP_DIRECTION_FIRST          0X0400
#define STEP_DIRECTION_SECOND         0X0800
#define STEP_WAIT_SIG1_DISAPPEAR      0X1000
#define STEP_WAITING_SIG1             0X2000
#define STEP_WAITING_SIG2             0X4000
#define STEP_PRE                      0X8000//used for find home;  move to homeValueApproximate-1 to make sure the home signal is at the up direction

// home mode type definition
#define HOME_HOME_INDEX               0X01
#define HOME_LOW_INDEX                0X02
#define HOME_UPPER_INDEX              0X04
#define HOME_HOME_NONE                0X08
#define HOME_UPLIMT_VALUE             0X10
#define HOME_LOLIMT_VALUE             0X20
#define HOME_LIMT_LIMT                0X40
#define HOME_NONE_NONE                0X80

#define FDHM_FREE_COMMAND             (HOME_LOW_INDEX  | HOME_UPLIMT_VALUE | HOME_UPLIMT_VALUE | HOME_LOLIMT_VALUE | HOME_LIMT_LIMT |HOME_NONE_NONE)
#define FDHM_BEFORE_HOME              (HOME_HOME_INDEX | HOME_HOME_NONE)

// motor type definition
#define MOTORTYE_STEP                 0X01
#define MOTORTYE_DCBRUSHED_OPENLOOP   0X02
#define MOTORTYE_DCBRUSHED_CLOSELOOP  0X03
#define HEAD_IN_EEPROM                0xa5

/*�궨��*/
/*******************************************************/
#define MOTOR_PUL_IRQn                   TIM8_CC_IRQn
#define MOTOR_PUL_IRQHandler             TIM8_CC_IRQHandler
#define MOTOR_PUL_TIM                    TIM8
#define MOTOR_PUL_CLK_ENABLE()  		     __TIM8_CLK_ENABLE()
#define MOTOR_PUL_GPIO_AF                GPIO_AF3_TIM8
/////////////////////////////////////////////////////////////////////////
////////////////ͨ��1
//Motor ����
#define MOTOR_DIR1_PIN                  	GPIO_PIN_1   
#define MOTOR_DIR1_GPIO_PORT            	GPIOE
#define MOTOR_DIR1_GPIO_CLK_ENABLE()   	  __HAL_RCC_GPIOE_CLK_ENABLE()

//Motor ʹ��
#define MOTOR_EN1_PIN                  	  GPIO_PIN_0
#define MOTOR_EN1_GPIO_PORT            	  GPIOE
#define MOTOR_EN1_GPIO_CLK_ENABLE()    	  __HAL_RCC_GPIOE_CLK_ENABLE()

//Motor ����
#define MOTOR_PUL1_PORT       			      GPIOI
#define MOTOR_PUL1_PIN             		    GPIO_PIN_5
#define MOTOR_PUL1_GPIO_CLK_ENABLE()		  __HAL_RCC_GPIOI_CLK_ENABLE()

//��ʱ��ͨ��
#define MOTOR_PUL1_CHANNEL                TIM_CHANNEL_1
//Motor1 �ⲿIO�źţ���������ԭ��ͼ����
#define MOTOR_POS1_PORT       			    GPIOD//PH5
#define MOTOR_POS1_PIN             		  GPIO_PIN_5
#define MOTOR_POS1_GPIO_CLK_ENABLE()		__HAL_RCC_GPIOD_CLK_ENABLE()
#define MOTOR_POS1_INT_EXTI_IRQ         EXTI9_5_IRQn
#define MOTOR_POS1_IRQHandler           EXTI9_5_IRQHandler

#define MOTOR_NEG1_PORT       			    GPIOD//PD4
#define MOTOR_NEG1_PIN             		  GPIO_PIN_4
#define MOTOR_NEG1_GPIO_CLK_ENABLE()		__HAL_RCC_GPIOD_CLK_ENABLE()
#define MOTOR_NEG1_INT_EXTI_IRQ         EXTI4_IRQn
#define MOTOR_NEG1_IRQHandler           EXTI4_IRQHandler

#define MOTOR_INDEX1_PORT       		  	GPIOG//PG8
#define MOTOR_INDEX1_PIN             		GPIO_PIN_8
#define MOTOR_INDEX1_GPIO_CLK_ENABLE()	__HAL_RCC_GPIOG_CLK_ENABLE()
#define MOTOR_INDEX1_INT_EXTI_IRQ       EXTI9_5_IRQn
#define MOTOR_INDEX1_IRQHandler         EXTI9_5_IRQHandler

#define MOTOR_HOME1_PORT       			    GPIOD//PD6
#define MOTOR_HOME1_PIN             		GPIO_PIN_6
#define MOTOR_HOME1_GPIO_CLK_ENABLE()		__HAL_RCC_GPIOD_CLK_ENABLE()
#define MOTOR_HOME1_INT_EXTI_IRQ       EXTI9_5_IRQn
#define MOTOR_HOME1_IRQHandler         EXTI9_5_IRQHandler

#define MOTOR_COLLISION1_PORT             GPIOG//PG9
#define MOTOR_COLLISION1_PIN             	GPIO_PIN_9
#define MOTOR_COLLISION1_GPIO_CLK_ENABLE()	__HAL_RCC_GPIOG_CLK_ENABLE()
#define MOTOR_COLLISION1_INT_EXTI_IRQ       EXTI9_5_IRQn
#define MOTOR_COLLISION1_IRQHandler         EXTI9_5_IRQnHandler
///////////////////////////////////////////////////////////////////////////
//ͨ��2
//Motor ����
#define MOTOR_DIR2_PIN                  	GPIO_PIN_8
#define MOTOR_DIR2_GPIO_PORT            	GPIOI          
#define MOTOR_DIR2_GPIO_CLK_ENABLE()      __HAL_RCC_GPIOI_CLK_ENABLE()

//Motor ʹ��
#define MOTOR_EN2_PIN                     GPIO_PIN_4
#define MOTOR_EN2_GPIO_PORT               GPIOE                       
#define MOTOR_EN2_GPIO_CLK_ENABLE()    	  __HAL_RCC_GPIOE_CLK_ENABLE()

//Motor ����
#define MOTOR_PUL2_PORT       			      GPIOI
#define MOTOR_PUL2_PIN             		    GPIO_PIN_6
#define MOTOR_PUL2_GPIO_CLK_ENABLE()	  	__HAL_RCC_GPIOI_CLK_ENABLE()

//��ʱ��ͨ��
#define MOTOR_PUL2_CHANNEL                TIM_CHANNEL_2
//Motor2 �ⲿIO�źţ���������ԭ��ͼ����
#define MOTOR_POS2_PORT       			    GPIOF//PF0
#define MOTOR_POS2_PIN             		  GPIO_PIN_0
#define MOTOR_POS2_GPIO_CLK_ENABLE()		__HAL_RCC_GPIOF_CLK_ENABLE()
#define MOTOR_POS2_INT_EXTI_IRQ         EXTI0_IRQn
#define MOTOR_POS2_IRQHandler           EXTI0_IRQHandler


#define MOTOR_NEG2_PORT       			    GPIOE//PE15
#define MOTOR_NEG2_PIN             		    GPIO_PIN_15
#define MOTOR_NEG2_GPIO_CLK_ENABLE()		__HAL_RCC_GPIOE_CLK_ENABLE()
#define MOTOR_NEG2_INT_EXTI_IRQ         EXTI15_10_IRQn
#define MOTOR_NEG2_IRQHandler           EXTI15_10_IRQHandler


#define MOTOR_INDEX2_PORT       			  GPIOD//PD1
#define MOTOR_INDEX2_PIN             		GPIO_PIN_1
#define MOTOR_INDEX2_GPIO_CLK_ENABLE()		__HAL_RCC_GPIOD_CLK_ENABLE()
#define MOTOR_INDEX2_INT_EXTI_IRQ       EXTI1_IRQn
#define MOTOR_INDEX2_IRQHandler         EXTI1_IRQHandler


#define MOTOR_HOME2_PORT       			    GPIOE//PE7
#define MOTOR_HOME2_PIN             		GPIO_PIN_7
#define MOTOR_HOME2_GPIO_CLK_ENABLE()		__HAL_RCC_GPIOE_CLK_ENABLE()
#define MOTOR_HOME2_INT_EXTI_IRQ       EXTI9_5_IRQn
#define MOTOR_HOME2_IRQHandler         EXTI9_5_IRQHandler

#define MOTOR_COLLISION2_PORT               GPIOF//PF3
#define MOTOR_COLLISION2_PIN             	GPIO_PIN_3
#define MOTOR_COLLISION2_GPIO_CLK_ENABLE()	__HAL_RCC_GPIOF_CLK_ENABLE()
#define MOTOR_COLLISION2_INT_EXTI_IRQ       EXTI3_IRQn
#define MOTOR_COLLISION2_IRQHandler         EXTI3_IRQHandler
//ͨ��3
//Motor ����
#define MOTOR_DIR3_PIN                  	GPIO_PIN_11
#define MOTOR_DIR3_GPIO_PORT            	GPIOI          
#define MOTOR_DIR3_GPIO_CLK_ENABLE()   	  __HAL_RCC_GPIOI_CLK_ENABLE()

//Motor ʹ��
#define MOTOR_EN3_PIN                  	  GPIO_PIN_10
#define MOTOR_EN3_GPIO_PORT            	  GPIOI                 
#define MOTOR_EN3_GPIO_CLK_ENABLE()    	  __HAL_RCC_GPIOI_CLK_ENABLE()

//Motor ����
#define MOTOR_PUL3_PORT       			      GPIOI
#define MOTOR_PUL3_PIN             		    GPIO_PIN_7
#define MOTOR_PUL3_GPIO_CLK_ENABLE()		  __HAL_RCC_GPIOI_CLK_ENABLE()

//��ʱ��ͨ��
#define MOTOR_PUL3_CHANNEL                TIM_CHANNEL_3
//Motor3 �ⲿIO�źţ���������ԭ��ͼ����
#define MOTOR_POS3_PORT       			    GPIOE//PE11
#define MOTOR_POS3_PIN             		  GPIO_PIN_11
#define MOTOR_POS3_GPIO_CLK_ENABLE()		__HAL_RCC_GPIOE_CLK_ENABLE()
#define MOTOR_POS3_INT_EXTI_IRQ         EXTI15_10_IRQn
#define MOTOR_POS3_IRQHandler           EXTI15_10_IRQHandler

#define MOTOR_NEG3_PORT       			    GPIOE//PE12
#define MOTOR_NEG3_PIN             		  GPIO_PIN_12
#define MOTOR_NEG3_GPIO_CLK_ENABLE()		__HAL_RCC_GPIOE_CLK_ENABLE()
#define MOTOR_NEG3_INT_EXTI_IRQ         EXTI15_10_IRQn
#define MOTOR_NEG3_IRQHandler           EXTI15_10_IRQHandler

#define MOTOR_INDEX3_PORT       			  GPIOE//PE14
#define MOTOR_INDEX3_PIN             		GPIO_PIN_14
#define MOTOR_INDEX3_GPIO_CLK_ENABLE()	__HAL_RCC_GPIOE_CLK_ENABLE()
#define MOTOR_INDEX3_INT_EXTI_IRQ       EXTI15_10_IRQn
#define MOTOR_INDEX3_IRQHandler         EXTI15_10_IRQHandler

#define MOTOR_HOME3_PORT       			    GPIOE//PE13
#define MOTOR_HOME3_PIN             		GPIO_PIN_13
#define MOTOR_HOME3_GPIO_CLK_ENABLE()		__HAL_RCC_GPIOE_CLK_ENABLE()
#define MOTOR_HOME3_INT_EXTI_IRQ       EXTI15_10_IRQn
#define MOTOR_HOME3_IRQHandler         EXTI15_10_IRQHandler

#define MOTOR_COLLISION3_PORT               GPIOD//PD10
#define MOTOR_COLLISION3_PIN             	  GPIO_PIN_10
#define MOTOR_COLLISION3_GPIO_CLK_ENABLE()	__HAL_RCC_GPIOD_CLK_ENABLE()
#define MOTOR_COLLISION3_INT_EXTI_IRQ       EXTI15_10_IRQn
#define MOTOR_COLLISION3_IRQHandler         EXTI15_10_IRQHandler

//ͨ��4
//Motor ����
#define MOTOR_DIR4_PIN                  	GPIO_PIN_2
#define MOTOR_DIR4_GPIO_PORT            	GPIOF
#define MOTOR_DIR4_GPIO_CLK_ENABLE()   	  __HAL_RCC_GPIOF_CLK_ENABLE()

//Motor ʹ��
#define MOTOR_EN4_PIN                  	  GPIO_PIN_1
#define MOTOR_EN4_GPIO_PORT            	  GPIOF       
#define MOTOR_EN4_GPIO_CLK_ENABLE()    	  __HAL_RCC_GPIOF_CLK_ENABLE()

//Motor ����
#define MOTOR_PUL4_PORT       			      GPIOC
#define MOTOR_PUL4_PIN             		    GPIO_PIN_9
#define MOTOR_PUL4_GPIO_CLK_ENABLE()      __HAL_RCC_GPIOC_CLK_ENABLE()

//��ʱ��ͨ��
#define MOTOR_PUL4_CHANNEL                TIM_CHANNEL_4

// added IN_ENABLE OUT_ENBALE SIGNALS
#define INPUT_EN0_PIN                  	  GPIO_PIN_0 //PB0
#define INPUT_EN0_GPIO_PORT            	  GPIOB       
#define INPUT_EN0_GPIO_CLK_ENABLE()    	  __HAL_RCC_GPIOB_CLK_ENABLE()

#define INPUT_EN1_PIN                  	  GPIO_PIN_15 //PB15
#define INPUT_EN1_GPIO_PORT            	  GPIOB       
#define INPUT_EN1_GPIO_CLK_ENABLE()    	  __HAL_RCC_GPIOB_CLK_ENABLE()

#define INPUT_EN2_PIN                  	  GPIO_PIN_14 //PB14
#define INPUT_EN2_GPIO_PORT            	  GPIOB       
#define INPUT_EN2_GPIO_CLK_ENABLE()    	  __HAL_RCC_GPIOB_CLK_ENABLE()

#define INPUT_EN3_PIN                  	  GPIO_PIN_13 //PB13
#define INPUT_EN3_GPIO_PORT            	  GPIOB       
#define INPUT_EN3_GPIO_CLK_ENABLE()    	  __HAL_RCC_GPIOB_CLK_ENABLE()


#define OUTPUT_EN0_PIN                  	  GPIO_PIN_0 //PC0
#define OUTPUT_EN0_GPIO_PORT            	  GPIOC       
#define OUTPUT_EN0_GPIO_CLK_ENABLE()    	  __HAL_RCC_GPIOC_CLK_ENABLE()

#define OUTPUT_EN1_PIN                  	  GPIO_PIN_3 //PA3
#define OUTPUT_EN1_GPIO_PORT            	  GPIOA       
#define OUTPUT_EN1_GPIO_CLK_ENABLE()    	  __HAL_RCC_GPIOA_CLK_ENABLE()

#define OUTPUT_EN2_PIN                  	  GPIO_PIN_1 //PB1
#define OUTPUT_EN2_GPIO_PORT            	  GPIOB       
#define OUTPUT_EN2_GPIO_CLK_ENABLE()    	  __HAL_RCC_GPIOB_CLK_ENABLE()

#define OUTPUT_EN3_PIN                  	  GPIO_PIN_12 //PG12
#define OUTPUT_EN3_GPIO_PORT            	  GPIOG       
#define OUTPUT_EN3_GPIO_CLK_ENABLE()    	  __HAL_RCC_GPIOG_CLK_ENABLE()

//����ʹ������
/* ���κ꣬��������������һ��ʹ�� */
#define MOTOR_OFFLINE(port, pin, x)       HAL_GPIO_WritePin(port, pin, x)
#define MOTOR_PUL(port, pin, x)           HAL_GPIO_WritePin(port, pin, x)
#define MOTOR_DIR(port, pin, x)           HAL_GPIO_WritePin(port, pin, x)

/*Ƶ����ز���*/
//��ʱ��ʵ��ʱ��Ƶ��Ϊ��240MHz/TIM_PRESCALER
//240/TIM_PRESCALER=2MHz
//������Ҫ��Ƶ�ʿ����Լ�����

//#define TIM_PRESCALER                1200
//#define FRE_PWM                      200000//pwm��Ƶ�� 200khz
#define TIM_PRESCALER                600
#define FRE_PWM                      400000//pwm��Ƶ�� 200khz

// ���嶨ʱ�����ڣ�����Ƚ�ģʽ��������Ϊ0xFFFF
#define TIM_PERIOD                   0xFFFF
#define MICROSTEP                    256

/************************************************************/
#define HIGH GPIO_PIN_SET	  //�ߵ�ƽ
#define LOW  GPIO_PIN_RESET	//�͵�ƽ

#define ON   LOW	          //��
#define OFF  HIGH	          //��

#define CW   HIGH		        //˳ʱ��
#define CCW  LOW      	    //��ʱ��
#define UP   0
#define DOWN 1
/* ����������� */
extern Stepper_TypeDef step_motor[3];

void stepper_Init(void);

//20230816 changed. Return value added to enhance the robustness
//void stepper_Start(uint32_t channel);
int stepper_Start(uint32_t channel);
void stepper_Stop(uint32_t channel);

void stop_state(uint8_t port);
void start_state(uint8_t port);

void input_output_enable_GPIO(void);

void outPluse(uint8_t motorId,uint8_t level);

#endif /* __BSP_STEPPER_INIT_H */
