#include "./stepper/stepper_task.h"
#include "./stepper/bsp_scan.h"
#include "./control/bsp_ctrl.h"
#include "./stepper/bsp_stepper_init.h"
#include "./i2c_io/bsp_i2c_ee.h"
#include "./i2c_io/bsp_i2c_gpio.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include "./iwdg/bsp_iwdg.h"  

//#define UART_DEBUG_STP 1 //茅聹聙膷艢聛膰聣聯暮聧掳膷啪聯暮聡艧膰聴艣膹藕聦暮沤職盲拧聣膰?陇暮沤聫
uint8_t SendBuffI[32]  = "  This is from MOTOR   \n";
uint8_t flag_LowePower = 0;
extern volatile uint32_t CPU_RunTime ;
volatile uint32_t indexTime_current[MOTOR_IN_USE];
volatile uint32_t indexTime_last[MOTOR_IN_USE];

long long int   lastCountInPWM_IRQ[    MOTOR_IN_USE ] = {0,0,0};
long long int   CurrentCountInPWM_IRQ[ MOTOR_IN_USE ] = {0,0,0};
int                      lastValueEncoder[      MOTOR_IN_USE ] = {0,0,0};
int                      CurrentValueEncoder[   MOTOR_IN_USE ] = {0,0,0};
int                      indexTrigerd4MissingCecck[   MOTOR_IN_USE ] = {0,0,0};


extern  uint8_t SendBuff[SENDBUFF_SIZE]; 
extern  DMA_HandleTypeDef UART1TxDMA_Handler;
extern  DMA_HandleTypeDef UART3TxDMA_Handler;
extern QueueHandle_t Queue_PWMIRQ_to_STPSCAN[MOTOR_IN_USE];
extern GPIO_TypeDef* GPIO_input_enable_port[4] ;
extern uint16_t  GPIO_input_enable_pin[4];
extern _EEPROM_STATE_STEP state_motor_struct[MOTOR_IN_USE];
extern _EEPROM_CONF_STEP ee_conFile[MOTOR_IN_USE];
extern TIM_HandleTypeDef TIM_StepperHandle;
extern int64_t           countInPWM_noIndex[MOTOR_IN_USE];

void STEPPER1_Task(void* parameter)
{	
  BaseType_t xReturn = pdPASS;/* 暮沤職盲拧聣盲赂聙盲赂?暮聢聸暮钮艧盲偶膭膰聛呕膷偶聰暮聸聻暮聙藕膹藕聦茅钮聵膷?陇盲赂艧pdPASS */
  static uint8_t u8_timeForSaveStates = 0;
  uint32_t r_queue;	//膰聨慕膰聰艣膰聺慕膷聡艦暮陇聳茅聝篓盲赂?膰聳?莽職聞暮聫聵茅聡?
  uint32_t temp;	//膰聨慕膰聰艣膰聺慕膷聡艦暮陇聳茅聝篓盲赂?膰聳?莽職聞暮聫聵茅聡?
  uint32_t i;
  while (1)
  { 
    //3盲赂?膰颅慕膷偶聸莽聰木膰聹艧膰艁聙膰木聥莽膭殴盲钮艣盲赂颅膰聳?    //3盲赂?膰颅慕膷偶聸莽聰木膰聹艧膷搂艁膰聻聬暮聧聫膷??膬聙?
    for(i = 0; i< MOTOR_IN_USE; i++)
    {
        xReturn = xQueueReceive( Queue_IRQ_to_STP[i],    /* 膰艣聢膰聛呕茅聵聼暮聢聴莽職聞暮聫慕膰聼? */
                                &r_queue,      /* 暮聫聭茅聙聛莽職聞膰艣聢膰聛呕暮聠聟暮?? */
                                0); /* 盲赂聧莽颅聣 */
        if(pdPASS == xReturn){       
            temp = r_queue & 0xff;
            EXIT_to_STP_Handler(&step_motor[i],temp);
        }
		if(	step_motor[i].this_state->scanMode == SCAN_MODE_ENABLE ){//SCAN膰篓膭暮藕聫膷藰?膷沤啪莽藵沤膰聢聬盲艧聠莽颅聣暮啪聟盲藵偶膷聝藵
          if(HAL_GPIO_ReadPin(GPIO_input_enable_port[i],GPIO_input_enable_pin[i]) != KEY_ON){
            step_motor[i].this_state->enable_triggered = 2; //low  
            //printf("In%d:0\n",i);          
          }
          if((HAL_GPIO_ReadPin(GPIO_input_enable_port[i],GPIO_input_enable_pin[i]) == KEY_ON)
             &&(step_motor[i].this_state->enable_triggered == 2)){
            step_motor[i].this_state->enable_triggered = 1; //low to high
            //printf("In%d:1\n",i);              
          }
           /*
            if(HAL_GPIO_ReadPin(GPIO_input_enable_port[i],GPIO_input_enable_pin[i]) != KEY_ON){
              printf("In%d:0\n",i);
              step_motor[i].this_state->scanMode = 0;
              xQueueSend(Queue_STEPPER_to_STPSCAN[i],  //膰艣聢膰聛呕茅聵聼暮聢聴莽職聞暮聫慕膰聼? 
                                                &i,
                                                0);	// 暮聫聭茅聙聛莽職聞膰艣聢膰聛呕暮聠聟暮?? 
              step_motor[i].this_state->enable_triggered = 1;    
			}else{

            }*/               	          
		}
      Limitations_Control(i);
      checkCollision(i);
      checkUplimtSignal(i);
      checkLowlimtSignal(i);
      checkMissingSteps(i);	
      checkMissingSteps_index_only(i);	
    } 
    u8_timeForSaveStates ++;
    if((20 == u8_timeForSaveStates)&&(0 == flag_LowePower )){
      u8_timeForSaveStates = 0;
      EEPROM_Write_state();    
      LED4_TOGGLE;
      IWDG_Feed();	
    }

    vTaskDelay(50);
  }
}
void STEPPER2_Task(void* parameter)
{
// int i;
}
void STEPPER3_Task(void* parameter)
{
  //  int i;
}

void EXIT_to_STP_Handler( Stepper_TypeDef* pMotor,uint32_t temp )
{
	//	printf("膷搂艢暮聫聭盲赂?膰聳?莽職聞膰聵呕 KEY%d !\n",r_queue);
	//暮聢陇膰聳颅膰聵?暮聯?盲赂?盲偶膭暮聫藝莽職聞盲赂颅膰聳?膹藕聦暮?拧暮艧聰莽聸赂暮艧聰莽職聞暮聤篓盲藵?	
	if( (POSITIVE_LIM & temp)  == POSITIVE_LIM)
    {
        positiveLimHandler(pMotor);
    }
    if( (NEGITIVE_LIM & temp)  == NEGITIVE_LIM)
    {
        negtiveLimHandler(pMotor);
    }
    if( (HOME & temp)  == HOME)
    {
        homeHandler(pMotor);
    }
    if( (INDEX & temp)  == INDEX)
    {
        indexHandler(pMotor);
    }
    if( (COLLISION & temp)  == COLLISION)
    {
        collisionHandler(pMotor);
    }
}

void positiveLimHandler( Stepper_TypeDef* pMotor )
{


 	int i=0;
    switch (pMotor->pul_channel)
    {
      case ( TIM_CHANNEL_1 ):
          i = 1;  
      break;
      case ( TIM_CHANNEL_2 ):
          i = 2;
      break;
      case ( TIM_CHANNEL_3 ):
          i = 3;
      break;
      case ( TIM_CHANNEL_4 ):
          i = 4;
      break;
              
      default:
      break;
    }

    if(LIMITATION_DIRECTION_HCONF2 == (ee_conFile[i-1].this_HCONF.hconf2 & LIMITATION_DIRECTION_HCONF2) ){
	  step_motor[i-1].limN_pin_interrupt = 1; 
      #ifdef UART_DEBUG_STP
	    printf("NEG_LIM %d exchanged!\n",i);				
	  #endif  
    }else{
	  step_motor[i-1].limP_pin_interrupt = 1;
      #ifdef UART_DEBUG_STP
	    printf("POSITIVE_LIM %d!\n",i);				
	  #endif        
    }	
}
void negtiveLimHandler( Stepper_TypeDef* pMotor )
{
	  int i=0;
    switch (pMotor->pul_channel)
    {
      case ( TIM_CHANNEL_1 ):
          i = 1;  
      break;
      case ( TIM_CHANNEL_2 ):
          i = 2;
      break;
      case ( TIM_CHANNEL_3 ):
          i = 3;
      break;
      case ( TIM_CHANNEL_4 ):
          i = 4;
      break;
              
      default:
      break;
    }
    if(LIMITATION_DIRECTION_HCONF2 == (ee_conFile[i-1].this_HCONF.hconf2 & LIMITATION_DIRECTION_HCONF2) ){
	  step_motor[i-1].limP_pin_interrupt = 1; 
      #ifdef UART_DEBUG_STP
	    printf("POS_LIM %d exchanged!\n",i);				
	  #endif  
    }else{
	  step_motor[i-1].limN_pin_interrupt = 1;
      #ifdef UART_DEBUG_STP
	    printf("NEG_LIM %d!\n",i);				
	  #endif        
    }
}
void homeHandler(Stepper_TypeDef* pMotor)
{
    int i=0;
    switch (pMotor->pul_channel)
    {
      case ( TIM_CHANNEL_1 ):
          i = 1;  
      break;
      case ( TIM_CHANNEL_2 ):
          i = 2;
      break;
      case ( TIM_CHANNEL_3 ):
          i = 3;
      break;
      case ( TIM_CHANNEL_4 ):
          i = 4;
      break;
              
      default:
      break;
    }
    //#ifdef UART_DEBUG_STP				
	printf("This is motor %d 's HOME!\n",i);  
    //printf("HOME!\n");			
    //#endif
    step_motor[i-1].home_pin_interrupt = 1;
}
void indexHandler(Stepper_TypeDef* pMotor)
{
    int i = 0;
    switch (pMotor->pul_channel)
    {
      case ( TIM_CHANNEL_1 ):
          i = 1;  
      break;
      case ( TIM_CHANNEL_2 ):
          i = 2;
      break;
      case ( TIM_CHANNEL_3 ):
          i = 3;
      break;
      case ( TIM_CHANNEL_4 ):
          i = 4;
      break;
              
      default:
      break;
    }


    if( indexTrigerd4MissingCecck[i-1] > 0){
         //indexTime_current[i-1] = CPU_RunTime;       
        if( (indexTime_current[i-1] - indexTime_last[i-1])> 100){
            indexTrigerd4MissingCecck[i-1] ++;
            step_motor[i-1].index_pin_interrupt = 1;
            //indexTime_current[i-1] = CPU_RunTime;
            indexTime_last[i-1] = indexTime_current[i-1];  
            #ifdef UART_DEBUG_STP
                printf("INDEX %d !\n",i);   
            //printf("RTime %d !\n",indexTime_current[i-1] );  
            #endif         
        }else{
            //indexTime_current[i-1] = CPU_RunTime;
            //indexTime_last[i-1] = indexTime_current[i-1];   
        }

    }else{
        indexTrigerd4MissingCecck[i-1] =1;
        step_motor[i-1].index_pin_interrupt = 1;
        //indexTime_current[i-1] = CPU_RunTime;
        indexTime_last[i-1] = indexTime_current[i-1];
        #ifdef UART_DEBUG_STP
            printf("INDEX %d !\n",i);   
        //printf("RTime %d !\n",indexTime_current[i-1] );  
        #endif
    }


}
void collisionHandler(Stepper_TypeDef* pMotor)
{
	int i=0;

    switch (pMotor->pul_channel)
    {
      case ( TIM_CHANNEL_1 ):
          i = 1;  
      break;
      case ( TIM_CHANNEL_2 ):
          i = 2;
      break;
      case ( TIM_CHANNEL_3 ):
          i = 3;
      break;
      case ( TIM_CHANNEL_4 ):
          i = 4;
      break;
              
      default:
      break;
    } 

    #ifdef UART_DEBUG_STP
	printf("This is motor %d !\n",i);  
    printf("COLLISION!\n");
    #endif
}
//莽聰篓盲艧聨暮聢聠暮聫聭膰艣聢膰聛呕膹藕?
//莽钮聶STEP_SCAN_Task暮聫聭膰艣聢膰聛?膹藕職莽聰篓盲艧聨暮聬呕暮聤篓step scan膹藕聦茅聶聞暮聤聽膰艣聢膰聛?盲赂艧status莽钮聯膰聻聞盲藵?
//
void UART_in_STP_Handler(Stepper_TypeDef* pMotor,uint32_t queueMessage)
{
	int i=0;
    switch (pMotor->pul_channel)
    {
      case ( TIM_CHANNEL_1 ):
          i = 1;  
      break;
      case ( TIM_CHANNEL_2 ):
          i = 2;
      break;
      case ( TIM_CHANNEL_3 ):
          i = 3;
      break;
      case ( TIM_CHANNEL_4 ):
          i = 4;
      break;
              
      default:
      break;
    }
	
	#ifdef UART_DEBUG_STP

		SendBuffI[21] = (uint8_t)(i+0x30);
		while( HAL_DMA_GetState(&UART1TxDMA_Handler) == HAL_DMA_STATE_BUSY);
    
		__HAL_DMA_DISABLE(&UART1TxDMA_Handler);
		__HAL_DMA_ENABLE(&UART1TxDMA_Handler); 				
		__HAL_DMA_CLEAR_FLAG(&UART1TxDMA_Handler,DMA_FLAG_TCIF3_7);   		
		HAL_UART_Transmit_DMA (&UartHandle,(uint8_t *)SendBuffI,22);
   
  	    while( HAL_DMA_GetState(&UART3TxDMA_Handler) == HAL_DMA_STATE_BUSY); 
        __HAL_DMA_DISABLE(&UART3TxDMA_Handler);
		__HAL_DMA_ENABLE(&UART3TxDMA_Handler); 				
		__HAL_DMA_CLEAR_FLAG(&UART3TxDMA_Handler,DMA_FLAG_TCIF3_7);   		
		HAL_UART_Transmit_DMA (&Uart3Handle,(uint8_t *)SendBuffI,22);	 							
	#endif
		
		if(queueMessage == 0x03)
		{
		#ifdef UART_DEBUG_STP
			printf("preparing scanning!"); 
		#endif
		xQueueSend(Queue_STEPPER_to_STPSCAN[i-1], /* 膰艣聢膰聛呕茅聵聼暮聢聴莽職聞暮聫慕膰聼? */
				       &queueMessage,
							 0);	/* 暮聫聭茅聙聛莽職聞膰艣聢膰聛呕暮聠聟暮?? */
		}
}


//if encoder exists: check encoder counts vs PWM counts
//if encoder doesn't exist,but index exists, check index signal counts when pwm over one circle.
//
void checkMissingSteps(uint8_t motorId)
{
     static unsigned long long int  ull_PWM_difference     = 0;

     int                     int_Encoder_difference = 0;
     float                   f_distance_encoder     = 0.0;
     float                   f_distance_PWM         = 0.0;
     float                   f_ratio                = 0.0;
    // if this motor is equipped with encoder,and this motor is running
    if( ( ENCODER_AVAILABLE_HCONF1 == ( ee_conFile[motorId].this_HCONF.hconf1 & ENCODER_AVAILABLE_HCONF1)  )&&
        ((STATE_RUN_OR_NOT         == ( step_motor[motorId].this_state->miniState.state & STATE_RUN_OR_NOT) ))){
           CurrentCountInPWM_IRQ[motorId] = state_motor_struct[motorId].state_struct.countInPWM_IRQ;
           CurrentValueEncoder[motorId]   = (int)__HAL_TIM_GET_COUNTER(&TIM_EncoderHandle[motorId]) + (Encoder_Overflow_Count[motorId] * ENCODER_TIM_PERIOD);
               
           ull_PWM_difference     =  lastCountInPWM_IRQ[motorId] - CurrentCountInPWM_IRQ[motorId] ;
           int_Encoder_difference =  abs(CurrentValueEncoder[motorId]   - lastValueEncoder[motorId]);
       
           f_ratio             =   ee_conFile[motorId].fullStep*ee_conFile[motorId].microStep/ee_conFile[motorId].gearRatio;
           f_distance_encoder  = (float)(( (float)(int_Encoder_difference)/(float)(ee_conFile[motorId].encoderCounts)));
           f_distance_PWM      = (float)(ull_PWM_difference)*0.5f/f_ratio;
           
      
           if(( (fabs(f_distance_encoder - f_distance_PWM)) > ee_conFile[motorId].resolution)){
              state_motor_struct[motorId].state_struct.miniState.state |= STATE_POS_WRONG_OR_NOT;
              ull_PWM_difference = 0;
              LED3_TOGGLE;
             /* #ifdef UART_DEBUG_STP
	      		printf("c: %llu\n",ull_PWM_difference);  
  	      		printf("En_d: %d\n",int_Encoder_difference);                   
	      		printf("pos err at %d\n",motorId); 
	      		printf("f_distance %f\n",f_distance_PWM); 
	      		printf("f_distance_encoder %f\n",f_distance_encoder); 
	      		printf("fabs %f\n",fabs(f_distance_encoder - f_distance_PWM)); 
  	      		printf("dif %f\n",f_distance_encoder - f_distance_PWM);           
 	      		printf("res %f\n",ee_conFile[motorId].resolution);      
  	      		printf("1\n");                  
	      	#endif */ 
           }
           lastValueEncoder[motorId]   = CurrentValueEncoder[motorId]   ;
           lastCountInPWM_IRQ[motorId] = CurrentCountInPWM_IRQ[motorId] ;
       }
}
void checkMissingSteps_index_only(uint8_t motorId)
{
    int64_t i64_PWM_difference     = 0;

    uint32_t result     = 0xffffffff;
    uint32_t tempHong   = STATE_RUN_OR_NOT; 
    result = step_motor[motorId].this_state->miniState.state & tempHong;
    /*if(0 == motorId){
        printf("result: %d\n",result); 
    }*/
    uint32_t encoderHong   = ENCODER_AVAILABLE_HCONF1;
    uint32_t resultEncoder = 0xffffffff;
    resultEncoder          = ee_conFile[motorId].this_HCONF.hconf1 & encoderHong;

    uint32_t indexHong   = INDEX_AVAILABLE_HCONF1;
    uint32_t resultIndex = 0xffffffff;
    resultIndex          = ee_conFile[motorId].this_HCONF.hconf1 & indexHong;


    //if( (ENCODER_AVAILABLE_HCONF1 !=( ee_conFile[motorId].this_HCONF.hconf1 & ENCODER_AVAILABLE_HCONF1) )&&
    //    (INDEX_AVAILABLE_HCONF1   ==( ee_conFile[motorId].this_HCONF.hconf1 & INDEX_AVAILABLE_HCONF1) ) ){
    if( ( encoderHong != resultEncoder ) && ( indexHong  == resultIndex ) ){

            if( result == tempHong ){
                
                //step_motor[motorId].this_state->miniState.state |= STATE_RUN_OR_NOT;
                CurrentCountInPWM_IRQ[motorId] = countInPWM_noIndex[motorId];//update in PWM intterrupt
                i64_PWM_difference             = lastCountInPWM_IRQ[motorId] - CurrentCountInPWM_IRQ[motorId] ;
                //printf("D: %lld\n",i64_PWM_difference); 
                //if pwm is greater than a whole circle
                if( abs(i64_PWM_difference) >= (int64_t)(ee_conFile[motorId].microStep*ee_conFile[motorId].fullStep*2) ){
                    /*#ifdef UART_DEBUG_STP
                        printf("D: %lld\n",i64_PWM_difference); 
                        printf("T:  %d\n",indexTrigerd4MissingCecck[motorId]); 
                    #endif
                    if( indexTrigerd4MissingCecck[motorId] < 1){
                        state_motor_struct[motorId].state_struct.miniState.state |= STATE_POS_WRONG_OR_NOT;
                        printf("POS WR\n"); 
                        stepper_Stop(step_motor[motorId].pul_channel);
                        stop_state(motorId);
                        step_motor[motorId].this_state->stateMachine      = STEP_STOP;
                    }else{*/
                        indexTrigerd4MissingCecck[motorId] = 0;
                        lastCountInPWM_IRQ[motorId]        = CurrentCountInPWM_IRQ[motorId];
                    //}
                }
            }  
        }          
}
void initialParasForMissingstep(void)
{
    int i;
    for(i = 0; i < MOTOR_IN_USE; i ++){
        CurrentCountInPWM_IRQ[ i ]     = state_motor_struct[i].state_struct.countInPWM_IRQ;
        lastCountInPWM_IRQ[ i ]        = CurrentCountInPWM_IRQ[ i ];
        CurrentValueEncoder[ i ]       = 0;
        lastValueEncoder[ i ]          = CurrentValueEncoder[ i ];
        indexTrigerd4MissingCecck[ i ] = 0;

    }
}
