#ifndef __STP_TASK_H
#define	__STP_TASK_H

#include "stm32h7xx.h"
#include "stm32h7xx_hal.h"
#include "./exti/bsp_exti.h"

#include "stm32h7xx.h"
#include "main.h"
#include "bsp_led.h"
#include "bsp_key.h" 
#include "core_delay.h"   
#include "bsp_debug_usart.h"
#include "bsp_exti.h"
//#include "./i2c/bsp_i2c_ee.h"
#include "bsp_basic_tim.h"
#include "./stepper/bsp_stepper_init.h"

/* FreeRTOS头文�? */
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"
#include "event_groups.h"

#define POSITIVE_LIM       			    0x0001//
#define NEGITIVE_LIM       			    0x0002//
#define HOME       			            0x0004//
#define INDEX       			        0x0008//
#define COLLISION       			    0x0010//

extern QueueHandle_t Queue_IRQ_to_STP[MOTOR_IN_USE];
	

//暂时用一个TASK
void STEPPER1_Task(void* parameter);
//后面两个task备用
void STEPPER2_Task(void* parameter);
void STEPPER3_Task(void* parameter);

void EXIT_to_STP_Handler( Stepper_TypeDef* pMotor,uint32_t temp );


void positiveLimHandler(Stepper_TypeDef* pMotor );
void negtiveLimHandler(Stepper_TypeDef* pMotor );
void homeHandler(Stepper_TypeDef* pMotor);
void indexHandler(Stepper_TypeDef* pMotor);
void collisionHandler(Stepper_TypeDef* pMotor);
void UART_in_STP_Handler(Stepper_TypeDef* pMotor,uint32_t queueMessage);
void Scan_in_STP_Handler(Stepper_TypeDef* pMotor,uint32_t queueMessage);

void checkMissingSteps(uint8_t motorId);
void initialParasForMissingstep(void);
void checkMissingSteps_index_only(uint8_t motorId);

#endif /* __EXTI_H */
