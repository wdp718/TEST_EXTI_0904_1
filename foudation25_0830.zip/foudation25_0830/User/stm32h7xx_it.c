/**
  ******************************************************************************
  * @file    stm32h7xx_it.c
  * @brief   Interrupt Service Routines.
  ******************************************************************************
  *
  * COPYRIGHT(c) 2018 STMicroelectronics
  *
  * Redistribution and use in source and binary forms, with or without modification,
  * are permitted provided that the following conditions are met:
  *   1. Redistributions of source code must retain the above copyright notice,
  *      this list of conditions and the following disclaimer.
  *   2. Redistributions in binary form must reproduce the above copyright notice,
  *      this list of conditions and the following disclaimer in the documentation
  *      and/or other materials provided with the distribution.
  *   3. Neither the name of STMicroelectronics nor the names of its contributors
  *      may be used to endorse or promote products derived from this software
  *      without specific prior written permission.
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */
/* Includes ------------------------------------------------------------------*/
#include "stm32h7xx_hal.h"
#include "stm32h7xx.h"
#include "stm32h7xx_it.h"
/* ������Ӳ��bspͷ�ļ� */
#include "bsp_led.h"
#include "bsp_debug_usart.h"
#include "bsp_key.h"
#include "bsp_exti.h"
#include "bsp_basic_tim.h"
#include "./stepper/bsp_stepper_init.h"
#include "./stepper/stepper_task.h"
#include "./stepper/bsp_scan.h"
#include "./Encoder/bsp_encoder2.h"
/* FreeRTOSͷ�ļ� */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "semphr.h"
#include "./control/bsp_ctrl.h"
#include "./i2c_io/bsp_i2c_ee.h"
#include "./i2c_io/bsp_i2c_gpio.h"
/* External variables --------------------------------------------------------*/
extern Stepper_TypeDef step_motor[3] ;
extern QueueHandle_t Queue_IRQ_to_STP[3];
/* �������ö�ֵ�ź��� */
extern SemaphoreHandle_t BinarySem_Handle;
/* ���������ⲿ���� & ��ֵ�ź��� */
extern QueueHandle_t Test_Queue;
//static uint32_t send_data1 = 1;
static uint32_t send_data2 = 2;

static uint32_t send_limP1 = POSITIVE_LIM;
static uint32_t send_limN1 = NEGITIVE_LIM;
static uint32_t send_Home1 = HOME;
static uint32_t send_Index1 = INDEX;
static uint32_t send_Collision1 = COLLISION;

static uint32_t send_limP2 = POSITIVE_LIM;
static uint32_t send_limN2 = NEGITIVE_LIM;
static uint32_t send_Home2 = HOME;
static uint32_t send_Index2 = INDEX;
static uint32_t send_Collision2 = COLLISION;

static uint32_t send_limP3 = POSITIVE_LIM;
static uint32_t send_limN3 = NEGITIVE_LIM;
static uint32_t send_Home3 = HOME;
static uint32_t send_Index3 = INDEX;
static uint32_t send_Collision3 = COLLISION;

int capture_count_current[MOTOR_IN_USE ] = {0,0,0};
int capture_count_last[   MOTOR_IN_USE ] = {0,0,0};
int capture_per_unit[     MOTOR_IN_USE ] = {0,0,0};

int homeFinalStep[MOTOR_IN_USE ] = {0,0,0};
extern __IO int16_t Encoder_Overflow_Count[3] ;
extern _EEPROM_CONF_STEP   ee_conFile[MOTOR_IN_USE];
extern HOME_SIGNALS_STRUCT motor_Home_Sig_Sturct[MOTOR_IN_USE];
extern _EEPROM_STATE_STEP state_motor_struct[MOTOR_IN_USE];
extern volatile uint32_t indexTime_current[MOTOR_IN_USE];

// for flash bulk eraser
extern  uint8_t flag_LowePower ;

/******************************************************************************/
/*            Cortex Processor Interruption and Exception Handlers         */ 
/******************************************************************************/

/**
* @brief This function handles Non maskable interrupt.
*/
void NMI_Handler(void)
{
  /* USER CODE BEGIN NonMaskableInt_IRQn 0 */

  /* USER CODE END NonMaskableInt_IRQn 0 */
  /* USER CODE BEGIN NonMaskableInt_IRQn 1 */

  /* USER CODE END NonMaskableInt_IRQn 1 */
}

/**
* @brief This function handles Hard fault interrupt.
*/
void HardFault_Handler(void)
{
  /* USER CODE BEGIN HardFault_IRQn 0 */

  /* USER CODE END HardFault_IRQn 0 */
  while (1)
  {
  }
  /* USER CODE BEGIN HardFault_IRQn 1 */

  /* USER CODE END HardFault_IRQn 1 */
}

/**
* @brief This function handles Memory management fault.
*/
void MemManage_Handler(void)
{
  /* USER CODE BEGIN MemoryManagement_IRQn 0 */

  /* USER CODE END MemoryManagement_IRQn 0 */
  while (1)
  {
  }
  /* USER CODE BEGIN MemoryManagement_IRQn 1 */

  /* USER CODE END MemoryManagement_IRQn 1 */
}

/**
* @brief This function handles Pre-fetch fault, memory access fault.
*/
void BusFault_Handler(void)
{
  /* USER CODE BEGIN BusFault_IRQn 0 */

  /* USER CODE END BusFault_IRQn 0 */
  while (1)
  {
  }
  /* USER CODE BEGIN BusFault_IRQn 1 */

  /* USER CODE END BusFault_IRQn 1 */
}

/**
* @brief This function handles Undefined instruction or illegal state.
*/
void UsageFault_Handler(void)
{
  /* USER CODE BEGIN UsageFault_IRQn 0 */

  /* USER CODE END UsageFault_IRQn 0 */
  while (1)
  {
  }
  /* USER CODE BEGIN UsageFault_IRQn 1 */

  /* USER CODE END UsageFault_IRQn 1 */
}




/**
* @brief This function handles Debug monitor.
*/
void DebugMon_Handler(void)
{
  /* USER CODE BEGIN DebugMonitor_IRQn 0 */

  /* USER CODE END DebugMonitor_IRQn 0 */
  /* USER CODE BEGIN DebugMonitor_IRQn 1 */

  /* USER CODE END DebugMonitor_IRQn 1 */
}
/**
* @brief This function handles System tick timer.
*/
extern void xPortSysTickHandler(void);
//systick�жϷ�����
void SysTick_Handler(void)
{	
    #if (INCLUDE_xTaskGetSchedulerState  == 1 )
      if (xTaskGetSchedulerState() != taskSCHEDULER_NOT_STARTED)
      {
    #endif  /* INCLUDE_xTaskGetSchedulerState */  
        xPortSysTickHandler();
    #if (INCLUDE_xTaskGetSchedulerState  == 1 )
      }
    #endif  /* INCLUDE_xTaskGetSchedulerState */
}
/*********************************************************************************
  * @ ������  �� DEBUG_USART_IRQHandler
  * @ ����˵���� �����жϷ�����
  * @ ����    �� ��  
  * @ ����ֵ  �� ��
  ********************************************************************************/
void DEBUG_USART_IRQHandler(void)
{
  uint32_t ulReturn;
  /* �����ٽ�Σ��ٽ�ο���Ƕ�� */
  ulReturn = taskENTER_CRITICAL_FROM_ISR();

  if((READ_REG(UartHandle.Instance->ISR)& USART_ISR_IDLE) != RESET)
  {
			UART_IdelCallback();
      __HAL_UART_CLEAR_IT(&UartHandle, UART_CLEAR_IDLEF);
		  __HAL_UART_CLEAR_IT(&UartHandle, USART_ICR_TXFECF);

  }
  
  /* �˳��ٽ�� */
  taskEXIT_CRITICAL_FROM_ISR( ulReturn );
}


/*********************************************************************************
  * @ ������  �� KEY1_IRQHandler
  * @ ����˵���� �жϷ�����
  * @ ����    �� ��  
  * @ ����ֵ  �� ��
  ********************************************************************************/
void KEY2_IRQHandler(void)
{
	BaseType_t pxHigherPriorityTaskWoken;
  uint32_t ulReturn;
  /* �����ٽ�Σ��ٽ�ο���Ƕ�� */
  ulReturn = taskENTER_CRITICAL_FROM_ISR();
  //ȷ���Ƿ������EXTI Line�ж�
	if(__HAL_GPIO_EXTI_GET_IT(KEY2_INT_GPIO_PIN) != RESET) 
	{
    /* ������д�루���ͣ��������У��ȴ�ʱ��Ϊ 0  */
		xQueueSendFromISR(Test_Queue, /* ��Ϣ���еľ�� */
											&send_data2,/* ���͵���Ϣ���� */
											&pxHigherPriorityTaskWoken);
		
		//�����Ҫ�Ļ�����һ�������л�
		portYIELD_FROM_ISR(pxHigherPriorityTaskWoken);
		
    //����жϱ�־λ
		__HAL_GPIO_EXTI_CLEAR_IT(KEY2_INT_GPIO_PIN);     
	}  
  /* �˳��ٽ�� */
  taskEXIT_CRITICAL_FROM_ISR( ulReturn );
}

//EXTI0_IRQn MOTOR_POS2_PIN
void 	MOTOR_POS2_IRQHandler(void)
{
	BaseType_t pxHigherPriorityTaskWoken;
  //ȷ���Ƿ������EXTI Line�ж�
  uint32_t ulReturn;
  /* �����ٽ�Σ��ٽ�ο���Ƕ�� */
  ulReturn = taskENTER_CRITICAL_FROM_ISR();
  
	if(__HAL_GPIO_EXTI_GET_IT(MOTOR_POS2_PIN) != RESET) 
	{
    /* ������д�루���ͣ��������У��ȴ�ʱ��Ϊ 0  */
		xQueueSendFromISR(Queue_IRQ_to_STP[1], /* ��Ϣ���еľ�� */
											&send_limP2,/* ���͵���Ϣ���� */
											&pxHigherPriorityTaskWoken);
		
		portYIELD_FROM_ISR(pxHigherPriorityTaskWoken);

		__HAL_GPIO_EXTI_CLEAR_IT(MOTOR_POS2_PIN);     
	}   
  taskEXIT_CRITICAL_FROM_ISR( ulReturn );
}
//EXTI1_IRQn MOTOR_INDEX2_PIN
void MOTOR_INDEX2_IRQHandler(void)
{	BaseType_t pxHigherPriorityTaskWoken;
  //ȷ���Ƿ������EXTI Line�ж�
  uint32_t ulReturn;
  /* �����ٽ�Σ��ٽ�ο���Ƕ�� */
  ulReturn = taskENTER_CRITICAL_FROM_ISR();
  
	if(__HAL_GPIO_EXTI_GET_IT(MOTOR_INDEX2_PIN) != RESET) 
	{

		if( ( STEP_HOME | STEP_DIRECTION_SECOND ) == step_motor[1].this_state->stateMachine){
			stepper_Stop(step_motor[1].pul_channel);
			homeFinalStep[1] =1;	
		} 
		/*if( (STEP_FINDINGHOME | STEP_DIRECTION_FIRST | STEP_STOP )== step_motor[1].this_state->stateMachine){
			stepper_Stop(step_motor[1].pul_channel);
			homeFinalStep[1] =1;		
		}*/			  		
    /* ������д�루���ͣ��������У��ȴ�ʱ��Ϊ 0  */
		xQueueSendFromISR(Queue_IRQ_to_STP[1], /* ��Ϣ���еľ�� */
											&send_Index2,/* ���͵���Ϣ���� */
											&pxHigherPriorityTaskWoken);	
		indexTime_current[1] = CPU_RunTime;
		//�����Ҫ�Ļ�����һ�������л�
		portYIELD_FROM_ISR(pxHigherPriorityTaskWoken);	
    //����жϱ�־λ
		__HAL_GPIO_EXTI_CLEAR_IT(MOTOR_INDEX2_PIN);     
	}    
  /* �˳��ٽ�� */
  taskEXIT_CRITICAL_FROM_ISR( ulReturn );	
}
//EXTI3_IRQn MOTOR_COLLISION2_PIN
void 	MOTOR_COLLISION2_IRQHandler(void)
{
	BaseType_t pxHigherPriorityTaskWoken;
  //ȷ���Ƿ������EXTI Line�ж�
  uint32_t ulReturn;
  /* �����ٽ�Σ��ٽ�ο���Ƕ�� */
  ulReturn = taskENTER_CRITICAL_FROM_ISR();
  
  //ȷ���Ƿ������EXTI Line�ж�
	if(__HAL_GPIO_EXTI_GET_IT(MOTOR_COLLISION2_PIN) != RESET) 
	{
    /* ������д�루���ͣ��������У��ȴ�ʱ��Ϊ 0  */
		xQueueSendFromISR(Queue_IRQ_to_STP[1], /* ��Ϣ���еľ�� */
											&send_Collision2,/* ���͵���Ϣ���� */
											&pxHigherPriorityTaskWoken);
		
		//�����Ҫ�Ļ�����һ�������л�
		portYIELD_FROM_ISR(pxHigherPriorityTaskWoken);
		
    //����жϱ�־λ
		__HAL_GPIO_EXTI_CLEAR_IT(MOTOR_COLLISION2_PIN);     
	}  
  
  /* �˳��ٽ�� */
  taskEXIT_CRITICAL_FROM_ISR( ulReturn );
}
//EXTI4_IRQn MOTOR_NEG1_PIN
void 	MOTOR_NEG1_IRQHandler(void)
{
	BaseType_t pxHigherPriorityTaskWoken;
  //ȷ���Ƿ������EXTI Line�ж�
  uint32_t ulReturn;
  /* �����ٽ�Σ��ٽ�ο���Ƕ�� */
  ulReturn = taskENTER_CRITICAL_FROM_ISR();
	if(__HAL_GPIO_EXTI_GET_IT(MOTOR_NEG1_PIN) != RESET) 
	{
		xQueueSendFromISR(Queue_IRQ_to_STP[0], /* ��Ϣ���еľ�� */
											&send_limN1,/* ���͵���Ϣ���� */
											&pxHigherPriorityTaskWoken);
		portYIELD_FROM_ISR(pxHigherPriorityTaskWoken);
    //����жϱ�־λ
		__HAL_GPIO_EXTI_CLEAR_IT(MOTOR_NEG1_PIN);     
	}    
  /* �˳��ٽ�� */
  taskEXIT_CRITICAL_FROM_ISR( ulReturn );
}
// 9-5���ú���
//MOTOR_POS1_PIN
//MOTOR_INDEX1_PIN
//MOTOR_HOME1_PIN
//MOTOR_HOME1_PIN	
//MOTOR_HOME2_PIN PE7
void 	MOTOR_POS1_IRQHandler(void)
{
	BaseType_t pxHigherPriorityTaskWoken;
  //ȷ���Ƿ������EXTI Line�ж�
  uint32_t ulReturn;
  /* �����ٽ�Σ��ٽ�ο���Ƕ�� */
  ulReturn = taskENTER_CRITICAL_FROM_ISR();
  //MOTOR_POS1_PIN
	if(__HAL_GPIO_EXTI_GET_IT(MOTOR_POS1_PIN) != RESET) 
	{
		xQueueSendFromISR(Queue_IRQ_to_STP[0], /* ��Ϣ���еľ�� */
											&send_limP1,/* ���͵���Ϣ���� */
											&pxHigherPriorityTaskWoken);
		portYIELD_FROM_ISR(pxHigherPriorityTaskWoken);
    //����жϱ�־λ
		__HAL_GPIO_EXTI_CLEAR_IT(MOTOR_POS1_PIN);     
	}  
  //MOTOR_INDEX1_PIN
	if(__HAL_GPIO_EXTI_GET_IT(MOTOR_INDEX1_PIN) != RESET) 
	{
		if( ( STEP_HOME | STEP_DIRECTION_SECOND ) == step_motor[0].this_state->stateMachine){
			stepper_Stop(step_motor[0].pul_channel);
			homeFinalStep[0] =1;	
		}
		/*if( (STEP_FINDINGHOME | STEP_DIRECTION_FIRST | STEP_STOP )== step_motor[0].this_state->stateMachine){
			stepper_Stop(step_motor[0].pul_channel);
			homeFinalStep[0] =1;		
		}*/		   
		xQueueSendFromISR(Queue_IRQ_to_STP[0], /* ��Ϣ���еľ�� */
											&send_Index1,/* ���͵���Ϣ���� */
											&pxHigherPriorityTaskWoken);
		indexTime_current[0] = CPU_RunTime;
		portYIELD_FROM_ISR(pxHigherPriorityTaskWoken);
    //����жϱ�־λ
		__HAL_GPIO_EXTI_CLEAR_IT(MOTOR_INDEX1_PIN); 
		
 
	} 
  //MOTOR_HOME1_PIN	
	if(__HAL_GPIO_EXTI_GET_IT(MOTOR_HOME1_PIN) != RESET) 
	{
		xQueueSendFromISR(Queue_IRQ_to_STP[0], /* ��Ϣ���еľ�� */
											&send_Home1,/* ���͵���Ϣ���� */
											&pxHigherPriorityTaskWoken);
		portYIELD_FROM_ISR(pxHigherPriorityTaskWoken);
		__HAL_GPIO_EXTI_CLEAR_IT(MOTOR_HOME1_PIN);     
	} 
  //MOTOR_COLLISION1_PIN		
	if(__HAL_GPIO_EXTI_GET_IT(MOTOR_COLLISION1_PIN) != RESET) 
	{
		checkCollision(0);
		xQueueSendFromISR(Queue_IRQ_to_STP[0], /* ��Ϣ���еľ�� */
											&send_Collision1,/* ���͵���Ϣ���� */
											&pxHigherPriorityTaskWoken);		
		portYIELD_FROM_ISR(pxHigherPriorityTaskWoken);	
		__HAL_GPIO_EXTI_CLEAR_IT(MOTOR_COLLISION1_PIN);     
	}	 
	//PE7 send_Home2
		if(__HAL_GPIO_EXTI_GET_IT(MOTOR_HOME2_PIN) != RESET) 
	{
		xQueueSendFromISR(Queue_IRQ_to_STP[1], /* ��Ϣ���еľ�� */
											&send_Home2,/* ���͵���Ϣ���� */
											&pxHigherPriorityTaskWoken);
		
		portYIELD_FROM_ISR(pxHigherPriorityTaskWoken);
				__HAL_GPIO_EXTI_CLEAR_IT(MOTOR_HOME2_PIN);     
	}	
  /* �˳��ٽ�� */
  taskEXIT_CRITICAL_FROM_ISR( ulReturn );
}
//15-10����//
//MOTOR_POS3_PIN
//MOTOR_NEG3_PIN
//MOTOR_INDEX3_PIN
//MOTOR_NEG2_PIN
//MOTOR_HOME3_PIN
//MOTOR_COLLISION3_PIN
void MOTOR_NEG2_IRQHandler(void)
{
	BaseType_t pxHigherPriorityTaskWoken;
  //ȷ���Ƿ������EXTI Line�ж�
  uint32_t ulReturn;
  /* �����ٽ�Σ��ٽ�ο���Ƕ�� */
  ulReturn = taskENTER_CRITICAL_FROM_ISR();

	if(__HAL_GPIO_EXTI_GET_IT(MOTOR_POS3_PIN) != RESET) 
	{
		xQueueSendFromISR(Queue_IRQ_to_STP[2], 
											&send_limP3,
											&pxHigherPriorityTaskWoken);
		portYIELD_FROM_ISR(pxHigherPriorityTaskWoken);	
		__HAL_GPIO_EXTI_CLEAR_IT(MOTOR_POS3_PIN);     
	}
	
	if(__HAL_GPIO_EXTI_GET_IT(MOTOR_NEG3_PIN) != RESET) 
	{
		xQueueSendFromISR(Queue_IRQ_to_STP[2], 
											&send_limN3,
											&pxHigherPriorityTaskWoken);
		portYIELD_FROM_ISR(pxHigherPriorityTaskWoken);	
		__HAL_GPIO_EXTI_CLEAR_IT(MOTOR_NEG3_PIN);     
	}
	
	if(__HAL_GPIO_EXTI_GET_IT(MOTOR_INDEX3_PIN) != RESET) 
	{
		if( ( STEP_HOME | STEP_DIRECTION_SECOND ) == step_motor[2].this_state->stateMachine){
			stepper_Stop(step_motor[2].pul_channel);
			homeFinalStep[2] =1;
		}
		/*if( (STEP_FINDINGHOME | STEP_DIRECTION_FIRST | STEP_STOP )== step_motor[2].this_state->stateMachine){
			stepper_Stop(step_motor[2].pul_channel);
			homeFinalStep[2] =1;		
		}*/

		xQueueSendFromISR(Queue_IRQ_to_STP[2], 
											&send_Index3,
											&pxHigherPriorityTaskWoken);
		indexTime_current[2] = CPU_RunTime;
		portYIELD_FROM_ISR(pxHigherPriorityTaskWoken);	
		__HAL_GPIO_EXTI_CLEAR_IT(MOTOR_INDEX3_PIN);     
	}
	if(__HAL_GPIO_EXTI_GET_IT(MOTOR_NEG2_PIN) != RESET) 
	{
		xQueueSendFromISR(Queue_IRQ_to_STP[1], 
											&send_limN2,
											&pxHigherPriorityTaskWoken);
				portYIELD_FROM_ISR(pxHigherPriorityTaskWoken);
		__HAL_GPIO_EXTI_CLEAR_IT(MOTOR_NEG2_PIN);     
	}  
	if(__HAL_GPIO_EXTI_GET_IT(MOTOR_HOME3_PIN) != RESET) 
	{
		xQueueSendFromISR(Queue_IRQ_to_STP[2], 
											&send_Home3,
											&pxHigherPriorityTaskWoken);
		
		portYIELD_FROM_ISR(pxHigherPriorityTaskWoken);
				__HAL_GPIO_EXTI_CLEAR_IT(MOTOR_HOME3_PIN);     
	}
	if(__HAL_GPIO_EXTI_GET_IT(MOTOR_COLLISION3_PIN) != RESET) 
	{
		xQueueSendFromISR(Queue_IRQ_to_STP[2], 
											&send_Collision3,
											&pxHigherPriorityTaskWoken);
		portYIELD_FROM_ISR(pxHigherPriorityTaskWoken);
		
		__HAL_GPIO_EXTI_CLEAR_IT(MOTOR_COLLISION3_PIN);     
	}
  taskEXIT_CRITICAL_FROM_ISR( ulReturn );
}

/* ����ͳ������ʱ�� */
volatile uint32_t CPU_RunTime = 0UL;
extern TIM_HandleTypeDef TIM_Base;
void BASIC_TIM_IRQHandler(void)
{
    HAL_TIM_IRQHandler(&TIM_Base);
}
/**
  * @brief  ��ʱ�������жϻص�����
  * @param  htim : TIM���
  * @retval ��
  */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
	static int i = 0;
	BaseType_t pxHigherPriorityTaskWoken;
  //ȷ���Ƿ������EXTI Line�ж�
  uint32_t ulReturn;

  switch ((uint32_t)(htim->Instance))
  {
  	case (uint32_t)TIM6:
  		{
  		  CPU_RunTime++;
  		  i ++;
  		  if(i == 20){
			if(( motor_Home_Sig_Sturct[0].homeMode != HOME_LIMT_LIMT ) && ( ENCODER_AVAILABLE_HCONF1 == ( ENCODER_AVAILABLE_HCONF1 & ee_conFile[0].this_HCONF.hconf1) ) ){
                capture_count_current[0] = (int)__HAL_TIM_GET_COUNTER(&TIM_EncoderHandle[0]) + (Encoder_Overflow_Count[0] * ENCODER_TIM_PERIOD);
                if(0 == ee_conFile[0].encoderCounts){
	                ee_conFile[0].encoderCounts = ENCODER_TOTAL_RESOLUTION;
                }
				capture_per_unit[0]                                       = capture_count_current[0] - capture_count_last[0];
                step_motor[0].this_state->miniState.valueActual          += (float)(capture_count_current[0]-capture_count_last[0])/ee_conFile[0].encoderCounts;
				step_motor[0].this_state->miniState.valueEncoder         += (capture_count_current[0] - capture_count_last[0]);	                
				capture_count_last[0]                                     = capture_count_current[0];
  		  	}else{
			  if(motor_Home_Sig_Sturct[0].homeMode == HOME_LIMT_LIMT){	
	             if(HAL_GPIO_ReadPin(motor_Home_Sig_Sturct[0].gpio_sig1_port,motor_Home_Sig_Sturct[0].gpio_sig1_pin) == motor_Home_Sig_Sturct[0].sig1_level){//signal1,then valueActual = 1.
                    step_motor[0].this_state->miniState.valueActual = 1;
			     }else{
			        if(HAL_GPIO_ReadPin(motor_Home_Sig_Sturct[0].gpio_sig2_port,motor_Home_Sig_Sturct[0].gpio_sig2_pin) == motor_Home_Sig_Sturct[0].sig2_level){//signal2,then valueActual = 2.
                      step_motor[0].this_state->miniState.valueActual = 2;
			        }else{
                      step_motor[0].this_state->miniState.valueActual = 0;				
			        }	
			     }
			   }	  	
			}
			if(( motor_Home_Sig_Sturct[1].homeMode != HOME_LIMT_LIMT ) && ( ENCODER_AVAILABLE_HCONF1 == ( ENCODER_AVAILABLE_HCONF1 & ee_conFile[1].this_HCONF.hconf1) ) ){
                capture_count_current[1] = (int)__HAL_TIM_GET_COUNTER(&TIM_EncoderHandle[1]) + (Encoder_Overflow_Count[1] * ENCODER_TIM_PERIOD);
                if(0 == ee_conFile[1].encoderCounts){
	                ee_conFile[1].encoderCounts = ENCODER_TOTAL_RESOLUTION;
                }
				capture_per_unit[1]                                       = capture_count_current[1] - capture_count_last[1];
                step_motor[1].this_state->miniState.valueActual           += (float)(capture_count_current[1]-capture_count_last[1])/ee_conFile[1].encoderCounts;
				step_motor[1].this_state->miniState.valueEncoder         += (capture_count_current[1] - capture_count_last[1]);	                
				capture_count_last[1]                                     = capture_count_current[1];
  		  	 }else{
			  if(motor_Home_Sig_Sturct[1].homeMode == HOME_LIMT_LIMT){	
	             if(HAL_GPIO_ReadPin(motor_Home_Sig_Sturct[1].gpio_sig1_port,motor_Home_Sig_Sturct[1].gpio_sig1_pin) == motor_Home_Sig_Sturct[1].sig1_level){//signal1,then valueActual = 1.
                     step_motor[1].this_state->miniState.valueActual = 1;
			     }else{
			         if(HAL_GPIO_ReadPin(motor_Home_Sig_Sturct[1].gpio_sig2_port,motor_Home_Sig_Sturct[1].gpio_sig2_pin) == motor_Home_Sig_Sturct[1].sig2_level){//signal2,then valueActual = 2.
                         step_motor[1].this_state->miniState.valueActual = 2;
			         }else{
                        step_motor[1].this_state->miniState.valueActual = 0;				
			         }	
			     }	
			  }   	
			 }			 		
			if(( motor_Home_Sig_Sturct[2].homeMode != HOME_LIMT_LIMT ) && ( ENCODER_AVAILABLE_HCONF1 == ( ENCODER_AVAILABLE_HCONF1 & ee_conFile[2].this_HCONF.hconf1) ) ){
                capture_count_current[2] = (int)__HAL_TIM_GET_COUNTER(&TIM_EncoderHandle[2]) + (Encoder_Overflow_Count[2] * ENCODER_TIM_PERIOD);
                if(0 == ee_conFile[2].encoderCounts){
	                ee_conFile[2].encoderCounts = ENCODER_TOTAL_RESOLUTION;
                }
				capture_per_unit[2]                                       = capture_count_current[2] - capture_count_last[2];
                step_motor[2].this_state->miniState.valueActual          += (float)(capture_count_current[2]-capture_count_last[2])/ee_conFile[2].encoderCounts;
				step_motor[2].this_state->miniState.valueEncoder         += (capture_count_current[2] - capture_count_last[2]);	
                capture_count_last[2]                                     = capture_count_current[2];
			
  		  	 }else{
			  if(motor_Home_Sig_Sturct[2].homeMode == HOME_LIMT_LIMT){	
	            if(HAL_GPIO_ReadPin(motor_Home_Sig_Sturct[2].gpio_sig1_port,motor_Home_Sig_Sturct[2].gpio_sig1_pin) == motor_Home_Sig_Sturct[2].sig1_level){//signal1,then valueActual = 1.
                    step_motor[2].this_state->miniState.valueActual = 1;
			    }else{
			        if(HAL_GPIO_ReadPin(motor_Home_Sig_Sturct[2].gpio_sig2_port,motor_Home_Sig_Sturct[2].gpio_sig2_pin) == motor_Home_Sig_Sturct[2].sig2_level){//signal2,then valueActual = 2.
                        step_motor[2].this_state->miniState.valueActual = 2;
			        }else{
                       step_motor[2].this_state->miniState.valueActual = 0;				
			        }	
			    }	
			  }  	
			 }
												
  		  	if(STEP_MOVE2_POSITION == (STEP_MOVE2_POSITION & step_motor[0].this_state->stateMachine))
  		  		{Stepper_Ctrl(0);}
  		  	if(STEP_MOVE2_POSITION == (STEP_MOVE2_POSITION & step_motor[1].this_state->stateMachine))
  		  		{Stepper_Ctrl(1);}										
  		  	if(STEP_MOVE2_POSITION == (STEP_MOVE2_POSITION & step_motor[2].this_state->stateMachine))
  		  		{Stepper_Ctrl(2);}
  		  	i = 0;
  		  }		
  		  if( SCAN_MODE_TIME == step_motor[0].this_state->scanMode){ 
  		  	step_motor[0].this_state->scanTime_2_wait_ms --;
  		  	if( 0 == step_motor[0].this_state->scanTime_2_wait_ms ){
  		  	// �����ٽ�Σ��ٽ�ο���Ƕ�� 
  		  	ulReturn = taskENTER_CRITICAL_FROM_ISR();
  		  	// ������д�루���ͣ��������У��ȴ�ʱ��Ϊ 0  
  		  	xQueueSendFromISR(Queue_STEPPER_to_STPSCAN[0], // ��Ϣ���еľ�� 
  		  									&i,//  ���͵���Ϣ���� 
  		  									&pxHigherPriorityTaskWoken);			
  		  	portYIELD_FROM_ISR(pxHigherPriorityTaskWoken);
  		  	//  �˳��ٽ�� 
  		  	taskEXIT_CRITICAL_FROM_ISR( ulReturn );		
  		  	step_motor[0].this_state->scanMode =0;					
  		  	}
  		  }
  		  if( SCAN_MODE_TIME == step_motor[1].this_state->scanMode){ 
  		  step_motor[1].this_state->scanTime_2_wait_ms --;
  		  if( 0 == step_motor[1].this_state->scanTime_2_wait_ms ) {
  		  		ulReturn = taskENTER_CRITICAL_FROM_ISR();
  		  		xQueueSendFromISR(Queue_STEPPER_to_STPSCAN[1], 
  		  										&i,
  		  										&pxHigherPriorityTaskWoken);			
  		  		portYIELD_FROM_ISR(pxHigherPriorityTaskWoken);
  		  		
  		  		taskEXIT_CRITICAL_FROM_ISR( ulReturn );	
  		  		step_motor[1].this_state->scanMode = 0;					
  		  		}  		  		
  		  }
  		  if( SCAN_MODE_TIME == step_motor[2].this_state->scanMode){ 
  		  	step_motor[2].this_state->scanTime_2_wait_ms --;
  		  	if( 0 == step_motor[2].this_state->scanTime_2_wait_ms ){
  		  	ulReturn = taskENTER_CRITICAL_FROM_ISR(); 		  	
  		  	xQueueSendFromISR(Queue_STEPPER_to_STPSCAN[2], 
  		  									&i,
  		  									&pxHigherPriorityTaskWoken);			
  		  	portYIELD_FROM_ISR(pxHigherPriorityTaskWoken);
  		  	
  		  	taskEXIT_CRITICAL_FROM_ISR( ulReturn );
  		  	step_motor[2].this_state->scanMode = 0;					
  		  	}
  		  }	
  		}
    break;
  	  case (uint32_t)ENCODER_TIM:{
  			// �жϵ�ǰ�������������� 
  			if(__HAL_TIM_IS_TIM_COUNTING_DOWN(htim))
  				// ���� 
  				Encoder_Overflow_Count[0]--;
  			else
  				// ���� 
  				Encoder_Overflow_Count[0]++;
  		break;}
  		case (uint32_t)ENCODER2_TIM:{
  			// �жϵ�ǰ�������������� 
  			if(__HAL_TIM_IS_TIM_COUNTING_DOWN(htim))
  				// ���� 
  				Encoder_Overflow_Count[1]--;
  			else
  				// ���� 
  				Encoder_Overflow_Count[1]++;
		break;}
  		case (uint32_t)ENCODER3_TIM:{
			// �жϵ�ǰ�������������� 
  			if(__HAL_TIM_IS_TIM_COUNTING_DOWN(htim))
  				// ���� 
  				Encoder_Overflow_Count[2]--;
  			else
  				// ���� 
  				Encoder_Overflow_Count[2]++;		
  		break;} 				
  	default:
  		break;
  }	
}

extern  DMA_HandleTypeDef UART1TxDMA_Handler;
void DMA2_Stream7_IRQHandler()
{
	UartHandle.gState = HAL_UART_STATE_READY;
	UART1TxDMA_Handler.State = HAL_DMA_STATE_READY;
	__HAL_DMA_CLEAR_FLAG(&UART1TxDMA_Handler, DMA_FLAG_TCIF3_7);
	__HAL_DMA_CLEAR_FLAG(&UART1TxDMA_Handler, DMA_FLAG_HTIF3_7);
	__HAL_DMA_CLEAR_FLAG(&UART1TxDMA_Handler, DMA_FLAG_FEIF3_7 );
	__HAL_UNLOCK(&UART1TxDMA_Handler);
}

extern  DMA_HandleTypeDef UART3TxDMA_Handler;
void DMA1_Stream7_IRQHandler()
{
	Uart3Handle.gState = HAL_UART_STATE_READY;
	UART3TxDMA_Handler.State = HAL_DMA_STATE_READY;
	__HAL_DMA_CLEAR_FLAG(&UART3TxDMA_Handler, DMA_FLAG_TCIF3_7);
	__HAL_DMA_CLEAR_FLAG(&UART3TxDMA_Handler, DMA_FLAG_HTIF3_7);
	__HAL_DMA_CLEAR_FLAG(&UART3TxDMA_Handler, DMA_FLAG_FEIF3_7 );
	__HAL_UNLOCK(&UART3TxDMA_Handler);
}

extern uint8_t Rxflag_UART3;
extern uint8_t ucTemp_UART3;

void RS232_USART_IRQHandler(void)
{
  uint32_t ulReturn;
  // �����ٽ�Σ��ٽ�ο���Ƕ�� 
   ulReturn = taskENTER_CRITICAL_FROM_ISR();
  if((READ_REG(Uart3Handle.Instance->ISR)& USART_ISR_IDLE) != RESET)
  {
	UART3_IdelCallback();
    __HAL_UART_CLEAR_IT(&Uart3Handle, UART_CLEAR_IDLEF);
	__HAL_UART_CLEAR_IT(&Uart3Handle, USART_ICR_TXFECF);
  } 
  // �˳��ٽ�� 
    taskEXIT_CRITICAL_FROM_ISR( ulReturn );
}
//extern TIM_HandleTypeDef TIM_EncoderHandle;
void PVD_IRQHandler(void)
{
  HAL_PWR_PVD_IRQHandler();//

}