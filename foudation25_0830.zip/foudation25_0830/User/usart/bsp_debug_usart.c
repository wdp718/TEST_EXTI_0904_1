/**
  ******************************************************************************
  * @file    bsp_debug_usart.c
  * @author  fire
  * @version V1.0
  * @date    2016-xx-xx
  * @brief   ʹ�ô���1���ض���c��printf������usart�˿ڣ��жϽ���ģʽ
  ******************************************************************************
  * @attention
  *
  * ʵ��ƽ̨:Ұ��  STM32 H743 ������  
  * ��̳    :http://www.firebbs.cn
  * �Ա�    :http://firestm32.taobao.com
  *
  ******************************************************************************
  */ 
#include "./usart/bsp_debug_usart.h"
#include<string.h>
#include "./stepper/bsp_stepper_init.h"
/* FreeRTOSͷ�ļ� */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "semphr.h"
#include "./control/bsp_ctrl.h"
#include "./i2c_io/bsp_i2c_ee.h"
#include "./i2c_io/bsp_i2c_gpio.h"
UART_HandleTypeDef UartHandle;
UART_HandleTypeDef Uart3Handle;

DMA_HandleTypeDef DMA_Handle;
DMA_HandleTypeDef DMA_TX_Handle;
DMA_HandleTypeDef UART1TxDMA_Handler;

DMA_HandleTypeDef DMA_Handle_UART3RX;
DMA_HandleTypeDef UART3TxDMA_Handler;
extern uint8_t ucTemp_UART3;


extern _EEPROM_CONF_STEP   ee_conFile[MOTOR_IN_USE];
extern HCONF               motor_hconf[MOTOR_IN_USE];
extern _EEPROM_STATE_STEP  state_motor_struct[MOTOR_IN_USE];
extern HOME_SIGNALS_STRUCT motor_Home_Sig_Sturct[MOTOR_IN_USE];

extern uint16_t      GPIO_signal1_pin[MOTOR_IN_USE];
extern GPIO_TypeDef* GPIO_signal1_port[MOTOR_IN_USE] ;
extern uint16_t      GPIO_signal2_pin[MOTOR_IN_USE];
extern GPIO_TypeDef* GPIO_signal2_port[MOTOR_IN_USE] ;
extern master_slave_struct      masterSlaveStruct;


//__attribute__ ((at(0x30000000))) 
uint8_t RX_BUFF[USART_RBUFF_SIZE]={0};
uint8_t RX3_BUFF[USART_RBUFF_SIZE]={0};
uint8_t TX_BUFF[USART_RBUFF_SIZE]={0};
uint8_t u8_flag_rebooting = 0;
 /**
  * @brief  DEBUG_USART GPIO ����,����ģʽ���á�115200 8-N-1
  * @param  ��
  * @retval ��
  */  
void DEBUG_USART_Config(void)
{
    GPIO_InitTypeDef GPIO_InitStruct;

    RCC_PeriphCLKInitTypeDef RCC_PeriphClkInit;
        
    DEBUG_USART_RX_GPIO_CLK_ENABLE();
    DEBUG_USART_TX_GPIO_CLK_ENABLE();
    
    /* ���ô���1ʱ��Դ*/
		RCC_PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_USART1;
		RCC_PeriphClkInit.Usart16ClockSelection = RCC_USART16CLKSOURCE_D2PCLK2;
		HAL_RCCEx_PeriphCLKConfig(&RCC_PeriphClkInit);
    /* ʹ�ܴ���1ʱ�� */
    DEBUG_USART_CLK_ENABLE();

    /* ����Tx����Ϊ���ù���  */
    GPIO_InitStruct.Pin = DEBUG_USART_TX_PIN;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_PULLUP;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
    GPIO_InitStruct.Alternate = DEBUG_USART_TX_AF;
    HAL_GPIO_Init(DEBUG_USART_TX_GPIO_PORT, &GPIO_InitStruct);
    
    /* ����Rx����Ϊ���ù��� */
    GPIO_InitStruct.Pin = DEBUG_USART_RX_PIN;
    GPIO_InitStruct.Alternate = DEBUG_USART_RX_AF;
    HAL_GPIO_Init(DEBUG_USART_RX_GPIO_PORT, &GPIO_InitStruct); 
    
    /* ���ô�DEBUG_USART ģʽ */
    UartHandle.Instance = DEBUG_USART;
    UartHandle.Init.BaudRate = 115200;
    UartHandle.Init.WordLength = UART_WORDLENGTH_8B;
    UartHandle.Init.StopBits = UART_STOPBITS_1;
    UartHandle.Init.Parity = UART_PARITY_NONE;
    UartHandle.Init.Mode = UART_MODE_TX_RX;
    UartHandle.Init.HwFlowCtl = UART_HWCONTROL_NONE;
    UartHandle.Init.OverSampling = UART_OVERSAMPLING_16;
    UartHandle.Init.OneBitSampling = UART_ONEBIT_SAMPLING_DISABLED;
    UartHandle.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
    HAL_UART_Init(&UartHandle);

    /*����1�жϳ�ʼ�� */
    //HAL_NVIC_SetPriority(DEBUG_USART_IRQ, 0, 0);
    HAL_NVIC_SetPriority(DEBUG_USART_IRQ, 7, 0);
    HAL_NVIC_EnableIRQ(DEBUG_USART_IRQ);
		
}

void USART_DMA_Config(void)
{
  /*����DMAʱ��*/
  DEBUG_USART_DMA_CLK_ENABLE();

  DMA_Handle.Instance = DEBUG_USART_DMA_STREAM;
  /*usart1 tx��Ӧdma2��ͨ��4��������7*/	
  DMA_Handle.Init.Request = DMA_REQUEST_USART1_RX; 
  /*���򣺴��ڴ浽����*/		
  DMA_Handle.Init.Direction= DMA_PERIPH_TO_MEMORY;	
  /*�����ַ����*/	    
  DMA_Handle.Init.PeriphInc = DMA_PINC_DISABLE; 
  /*�ڴ��ַ����*/
  DMA_Handle.Init.MemInc = DMA_MINC_ENABLE;	
  /*�������ݵ�λ*/	
  DMA_Handle.Init.PeriphDataAlignment = DMA_PDATAALIGN_BYTE;
  /*�ڴ����ݵ�λ 8bit*/
  DMA_Handle.Init.MemDataAlignment = DMA_MDATAALIGN_BYTE;	
  /*DMAģʽ������ѭ��*/
  DMA_Handle.Init.Mode = DMA_CIRCULAR;	 
  /*���ȼ�����*/	
  DMA_Handle.Init.Priority = DMA_PRIORITY_MEDIUM;      
  /*����FIFO*/
  DMA_Handle.Init.FIFOMode = DMA_FIFOMODE_DISABLE;        
  DMA_Handle.Init.FIFOThreshold = DMA_FIFO_THRESHOLD_FULL;    
  /*�洢��ͻ������ 1������*/
  DMA_Handle.Init.MemBurst = DMA_MBURST_SINGLE;    
  /*����ͻ������ 1������*/
  DMA_Handle.Init.PeriphBurst = DMA_PBURST_SINGLE;    
  /*����DMA2��������7*/		   
//  /* Deinitialize the stream for new transfer */
  HAL_DMA_DeInit(&DMA_Handle);
  /* Configure the DMA stream */
  HAL_DMA_Init(&DMA_Handle); 
  
//	__HAL_DMA_ENABLE(&UartHandle);  
	
   /* Associate the DMA handle */
  __HAL_LINKDMA(&UartHandle, hdmarx, DMA_Handle);
	
	HAL_UART_Receive_DMA(&UartHandle, RX_BUFF, USART_RBUFF_SIZE);
  
	/*���ô��ڽ����жϣ��ڴ��ڳ�ʼ�����õĻ������һ���жϵ��´������ⲿʹ�ܼ��� */
	__HAL_UART_CLEAR_IT(&UartHandle, UART_CLEAR_IDLEF);
	__HAL_UART_ENABLE_IT(&UartHandle,UART_IT_IDLE);  
  
}

extern SemaphoreHandle_t BinarySem_Handle_fromPROTOCOL;
void Uart_DMA_Rx_Data(void)
{
  BaseType_t pxHigherPriorityTaskWoken;
  
  // �ر�DMA ����ֹ����
  __HAL_DMA_DISABLE(&DMA_Handle);      
	// ��DMA��־λ
  __HAL_DMA_CLEAR_FLAG(&DMA_Handle,DMA_FLAG_TCIF2_6);   
  //  ���¸�ֵ����ֵ��������ڵ��������ܽ��յ�������֡��Ŀ   
  WRITE_REG(((DMA_Stream_TypeDef   *)DMA_Handle.Instance)->NDTR , USART_RBUFF_SIZE);

  __HAL_DMA_ENABLE(&DMA_Handle);  

  //������ֵ�ź��� �����ͽ��յ������ݱ�־����ǰ̨�����ѯ
  xSemaphoreGiveFromISR(BinarySem_Handle_fromPROTOCOL,&pxHigherPriorityTaskWoken);	//�ͷŶ�ֵ�ź��� 
  //�����Ҫ�Ļ�����һ�������л���ϵͳ���ж��Ƿ���Ҫ�����л�
  portYIELD_FROM_ISR(pxHigherPriorityTaskWoken);
	
}


/*****************  �����ַ��� **********************/
void Usart_SendString(uint8_t *str)
{
	unsigned int k=0;
  do 
  {
      HAL_UART_Transmit( &UartHandle,(uint8_t *)(str + k) ,1,1000);
      k++;
  } while(*(str + k)!='\0');
  
}
///�ض���c�⺯��printf������DEBUG_USART���ض�����ʹ��printf����
int fputc(int ch, FILE *f)
{
	/* ����һ���ֽ����ݵ�����DEBUG_USART */
	HAL_UART_Transmit(&UartHandle, (uint8_t *)&ch, 1, 1000);	

	//HAL_UART_Transmit(&Uart3Handle, (uint8_t *)&ch, 1, 1000);
	return (ch);
}

///�ض���c�⺯��scanf������DEBUG_USART����д����ʹ��scanf��getchar�Ⱥ���
int fgetc(FILE *f)
{
		
	int ch;
	HAL_UART_Receive(&UartHandle, (uint8_t *)&ch, 1, 1000);	
	return (ch);
}


void UART_IdelCallback(void)
{
  Uart_DMA_Rx_Data();       /* �ͷ�һ���ź�������ʾ�����ѽ��� */
}



// DMA ����
void USART_TX_DMA_Config(void)
{
  /*����DMAʱ��*/
  DEBUG_USART_DMA_CLK_ENABLE();

	DMA_TX_Handle.Instance = DEBUG_USART_DMA_STREAM_TX;
  /* Deinitialize the stream for new transfer */
  HAL_DMA_DeInit(&DMA_TX_Handle);
	
  //DMA_TX_Handle.Instance = DEBUG_USART_DMA_STREAM_TX;
  /*usart1 tx��Ӧdma2��ͨ��4��������7*/	
  DMA_TX_Handle.Init.Request = DMA_REQUEST_USART1_TX; 
  /*���򣺴��ڴ浽����*/		
  DMA_TX_Handle.Init.Direction= DMA_MEMORY_TO_PERIPH;	
  /*�����ַ����*/	    
  DMA_TX_Handle.Init.PeriphInc = DMA_PINC_DISABLE; 
  /*�ڴ��ַ����*/
  DMA_TX_Handle.Init.MemInc = DMA_MINC_ENABLE;	
  /*�������ݵ�λ*/	
  DMA_TX_Handle.Init.PeriphDataAlignment = DMA_PDATAALIGN_BYTE;
  /*�ڴ����ݵ�λ 8bit*/
  DMA_TX_Handle.Init.MemDataAlignment = DMA_MDATAALIGN_BYTE;	
  /*DMAģʽ������ѭ��*/
  DMA_TX_Handle.Init.Mode = DMA_NORMAL;	 
  /*���ȼ�����*/	
  DMA_TX_Handle.Init.Priority = DMA_PRIORITY_MEDIUM;      
  /*����FIFO*/
  DMA_TX_Handle.Init.FIFOMode = DMA_FIFOMODE_DISABLE;        
  DMA_TX_Handle.Init.FIFOThreshold = DMA_FIFO_THRESHOLD_FULL;    
  /*�洢��ͻ������ 16������*/
  DMA_TX_Handle.Init.MemBurst = DMA_MBURST_SINGLE;    
  /*����ͻ������ 1������*/
  DMA_TX_Handle.Init.PeriphBurst = DMA_PBURST_SINGLE;    
  /*����DMA2��������7*/		   
//  /* Deinitialize the stream for new transfer */
 // HAL_DMA_DeInit(&DMA_TX_Handle);
  /* Configure the DMA stream */
  HAL_DMA_Init(&DMA_TX_Handle); 
  
   /* Associate the DMA handle */
  __HAL_LINKDMA(&UartHandle, hdmatx, DMA_TX_Handle);
}

// DMA ����
void USART_TXRX_DMA_Config(void)
{
        __HAL_RCC_DMA2_CLK_ENABLE();//DMA2ʱ��ʹ��       
       
       HAL_NVIC_SetPriority(DMA2_Stream7_IRQn,0,0);
       //HAL_NVIC_SetPriority(DMA2_Stream7_IRQn,7,0);
	     HAL_NVIC_EnableIRQ(DMA2_Stream7_IRQn);
       
      /*   HAL_NVIC_SetPriority(DMA2_Stream6_IRQn,0,0);
        HAL_NVIC_EnableIRQ(DMA2_Stream6_IRQn);
       */
        //Tx DMA����
        UART1TxDMA_Handler.Instance=DEBUG_USART_DMA_STREAM_TX;                            //������ѡ��
        UART1TxDMA_Handler.Init.Request=DMA_REQUEST_USART1_TX;                                //USART1����DMA
        UART1TxDMA_Handler.Init.Direction=DMA_MEMORY_TO_PERIPH;             //�洢��������
        UART1TxDMA_Handler.Init.PeriphInc=DMA_PINC_DISABLE;                 //���������ģʽ
        UART1TxDMA_Handler.Init.MemInc=DMA_MINC_ENABLE;                     //�洢������ģʽ
        UART1TxDMA_Handler.Init.PeriphDataAlignment=DMA_PDATAALIGN_BYTE;    //�������ݳ���:8λ
        UART1TxDMA_Handler.Init.MemDataAlignment=DMA_MDATAALIGN_BYTE;       //�洢�����ݳ���:8λ
        UART1TxDMA_Handler.Init.Mode=DMA_NORMAL;                            //��������ģʽ
        UART1TxDMA_Handler.Init.Priority=DMA_PRIORITY_MEDIUM;               //�е����ȼ�
        UART1TxDMA_Handler.Init.FIFOMode=DMA_FIFOMODE_DISABLE;              
        UART1TxDMA_Handler.Init.FIFOThreshold=DMA_FIFO_THRESHOLD_FULL;      
        UART1TxDMA_Handler.Init.MemBurst=DMA_MBURST_SINGLE;                 //�洢��ͻ�����δ���
        UART1TxDMA_Handler.Init.PeriphBurst=DMA_PBURST_SINGLE;              //����ͻ�����δ���
        HAL_DMA_DeInit(&UART1TxDMA_Handler);   
        HAL_DMA_Init(&UART1TxDMA_Handler);
        __HAL_LINKDMA(&UartHandle,hdmatx,UART1TxDMA_Handler);    //��DMA��USART1��ϵ����(����DMA)
       
			 
				
        //Rx DMA����
        DMA_Handle.Instance=DMA2_Stream6;                            //������ѡ��
        DMA_Handle.Init.Request=DMA_REQUEST_USART1_RX;
        DMA_Handle.Init.Direction=DMA_PERIPH_TO_MEMORY;             //���赽�洢��
        DMA_Handle.Init.PeriphInc=DMA_PINC_DISABLE;                 //���������ģʽ
        DMA_Handle.Init.MemInc=DMA_MINC_ENABLE;                     //�洢������ģʽ
        DMA_Handle.Init.PeriphDataAlignment=DMA_PDATAALIGN_BYTE;    //�������ݳ���:8λ
        DMA_Handle.Init.MemDataAlignment=DMA_MDATAALIGN_BYTE;       //�洢�����ݳ���:8λ
        DMA_Handle.Init.Mode=DMA_NORMAL;                            //��������ģʽ
        DMA_Handle.Init.Priority=DMA_PRIORITY_MEDIUM;               //�е����ȼ�
        DMA_Handle.Init.FIFOMode=DMA_FIFOMODE_DISABLE;              
        DMA_Handle.Init.FIFOThreshold=DMA_FIFO_THRESHOLD_FULL;      
        DMA_Handle.Init.MemBurst=DMA_MBURST_SINGLE;                 //�洢��ͻ�����δ���
        DMA_Handle.Init.PeriphBurst=DMA_PBURST_SINGLE;              //����ͻ�����δ���
        HAL_DMA_DeInit(&DMA_Handle);   
        HAL_DMA_Init(&DMA_Handle);
        __HAL_LINKDMA(&UartHandle,hdmarx,DMA_Handle);    //��DMA��USART1��ϵ����(����DMA)
				
				
				 HAL_UART_Receive_DMA(&UartHandle, RX_BUFF, USART_RBUFF_SIZE);
  
		/*���ô��ڽ����жϣ��ڴ��ڳ�ʼ�����õĻ������һ���жϵ��´������ⲿʹ�ܼ��� */
				__HAL_UART_CLEAR_IT(&UartHandle, UART_CLEAR_IDLEF);
			  __HAL_UART_ENABLE_IT(&UartHandle,UART_IT_IDLE);  
		}
//UART 3
void RS232_USART_Config(void)
{
    GPIO_InitTypeDef GPIO_InitStruct;

    RCC_PeriphCLKInitTypeDef RCC_PeriphClkInit;
        
    RS232_USART_RX_GPIO_CLK_ENABLE();
    RS232_USART_TX_GPIO_CLK_ENABLE();
    
    /* ���ô���2ʱ��Դ*/
    RCC_PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_UARTx;
    RCC_PeriphClkInit.Usart234578ClockSelection = RCC_UARTxCLKSOURCE_SYSCLK;
    HAL_RCCEx_PeriphCLKConfig(&RCC_PeriphClkInit);
    /* ʹ�� UART ʱ�� */
    RS232_USART_CLK_ENABLE();
 
    /* ����Tx����Ϊ���ù���  */
    GPIO_InitStruct.Pin = RS232_USART_TX_PIN;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_PULLUP;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
    GPIO_InitStruct.Alternate = RS232_USART_TX_AF;
    HAL_GPIO_Init(RS232_USART_TX_GPIO_PORT, &GPIO_InitStruct);
    
    /* ����Rx����Ϊ���ù��� */
    GPIO_InitStruct.Pin = RS232_USART_RX_PIN;
    GPIO_InitStruct.Alternate = RS232_USART_RX_AF;
    HAL_GPIO_Init(RS232_USART_RX_GPIO_PORT, &GPIO_InitStruct); 
    
    /* ���ô�RS232_USART ģʽ */
    Uart3Handle.Instance = RS232_USART;
    Uart3Handle.Init.BaudRate = 115200;
    Uart3Handle.Init.WordLength = UART_WORDLENGTH_8B;
    Uart3Handle.Init.StopBits = UART_STOPBITS_1;
    Uart3Handle.Init.Parity = UART_PARITY_NONE;
    Uart3Handle.Init.Mode = UART_MODE_TX_RX;
    HAL_UART_Init(&Uart3Handle);

    /*�����жϳ�ʼ�� */
    //HAL_NVIC_SetPriority(RS232_USART_IRQ, 0, 0);
    HAL_NVIC_SetPriority(RS232_USART_IRQ, 7, 0);
    HAL_NVIC_EnableIRQ(RS232_USART_IRQ);
    /*���ô��ڽ����ж� */
    __HAL_UART_ENABLE_IT(&Uart3Handle,UART_IT_RXNE);  
}

void Usart3_SendString(uint8_t *str)
{
	unsigned int k=0;
  do 
  {
      HAL_UART_Transmit( &Uart3Handle,(uint8_t *)(str + k) ,1,1000);
      k++;
  } while(*(str + k)!='\0');
  
}


void USART3_TXRX_DMA_Config(void)
{
        __HAL_RCC_DMA1_CLK_ENABLE();//DMA2ʱ��ʹ��       
       
       HAL_NVIC_SetPriority(DMA1_Stream7_IRQn,7,0);
       //HAL_NVIC_SetPriority(DMA1_Stream7_IRQn,7,0);	
       HAL_NVIC_EnableIRQ(DMA1_Stream7_IRQn);
       
      //   HAL_NVIC_SetPriority(DMA2_Stream6_IRQn,0,0);
      //  HAL_NVIC_EnableIRQ(DMA2_Stream6_IRQn);
       
        //Tx3 DMA����
        UART3TxDMA_Handler.Instance=DMA1_Stream7;                            //������ѡ��
        UART3TxDMA_Handler.Init.Request=DMA_REQUEST_USART3_TX;                                //USART1����DMA
        UART3TxDMA_Handler.Init.Direction=DMA_MEMORY_TO_PERIPH;             //�洢��������
        UART3TxDMA_Handler.Init.PeriphInc=DMA_PINC_DISABLE;                 //���������ģʽ
        UART3TxDMA_Handler.Init.MemInc=DMA_MINC_ENABLE;                     //�洢������ģʽ
        UART3TxDMA_Handler.Init.PeriphDataAlignment=DMA_PDATAALIGN_BYTE;    //�������ݳ���:8λ
        UART3TxDMA_Handler.Init.MemDataAlignment=DMA_MDATAALIGN_BYTE;       //�洢�����ݳ���:8λ
        UART3TxDMA_Handler.Init.Mode=DMA_NORMAL;                            //��������ģʽ
        UART3TxDMA_Handler.Init.Priority=DMA_PRIORITY_MEDIUM;               //�е����ȼ�
        UART3TxDMA_Handler.Init.FIFOMode=DMA_FIFOMODE_DISABLE;              
        UART3TxDMA_Handler.Init.FIFOThreshold=DMA_FIFO_THRESHOLD_FULL;      
        UART3TxDMA_Handler.Init.MemBurst=DMA_MBURST_SINGLE;                 //�洢��ͻ�����δ���
        UART3TxDMA_Handler.Init.PeriphBurst=DMA_PBURST_SINGLE;              //����ͻ�����δ���
        HAL_DMA_DeInit(&UART3TxDMA_Handler);   
        HAL_DMA_Init(&UART3TxDMA_Handler);
        __HAL_LINKDMA(&Uart3Handle,hdmatx,UART3TxDMA_Handler);    //��DMA��USART1��ϵ����(����DMA)
       
        //Rx3 DMA����
        DMA_Handle_UART3RX.Instance=DMA1_Stream6;                            //������ѡ��
        DMA_Handle_UART3RX.Init.Request=DMA_REQUEST_USART3_RX;
        DMA_Handle_UART3RX.Init.Direction=DMA_PERIPH_TO_MEMORY;             //���赽�洢��
        DMA_Handle_UART3RX.Init.PeriphInc=DMA_PINC_DISABLE;                 //���������ģʽ
        DMA_Handle_UART3RX.Init.MemInc=DMA_MINC_ENABLE;                     //�洢������ģʽ
        DMA_Handle_UART3RX.Init.PeriphDataAlignment=DMA_PDATAALIGN_BYTE;    //�������ݳ���:8λ
        DMA_Handle_UART3RX.Init.MemDataAlignment=DMA_MDATAALIGN_BYTE;       //�洢�����ݳ���:8λ
        DMA_Handle_UART3RX.Init.Mode=DMA_NORMAL;                            //��������ģʽ
        DMA_Handle_UART3RX.Init.Priority=DMA_PRIORITY_MEDIUM;               //�е����ȼ�
        DMA_Handle_UART3RX.Init.FIFOMode=DMA_FIFOMODE_DISABLE;              
        DMA_Handle_UART3RX.Init.FIFOThreshold=DMA_FIFO_THRESHOLD_FULL;      
        DMA_Handle_UART3RX.Init.MemBurst=DMA_MBURST_SINGLE;                 //�洢��ͻ�����δ���
        DMA_Handle_UART3RX.Init.PeriphBurst=DMA_PBURST_SINGLE;              //����ͻ�����δ���
        HAL_DMA_DeInit(&DMA_Handle_UART3RX);   
        HAL_DMA_Init(&DMA_Handle_UART3RX);
        __HAL_LINKDMA(&Uart3Handle,hdmarx,DMA_Handle_UART3RX);    //��DMA��USART1��ϵ����(����DMA)
				
				
				 HAL_UART_Receive_DMA(&Uart3Handle, RX_BUFF, USART_RBUFF_SIZE);
  
		//���ô��ڽ����жϣ��ڴ��ڳ�ʼ�����õĻ������һ���жϵ��´������ⲿʹ�ܼ��� 
				__HAL_UART_CLEAR_IT(&Uart3Handle, UART_CLEAR_IDLEF);
			  __HAL_UART_ENABLE_IT(&Uart3Handle,UART_IT_IDLE);  
		}

void  Uart3_DMA_Rx_Data(void )       // �ͷ�һ���ź�������ʾ�����ѽ��� /

{  BaseType_t pxHigherPriorityTaskWoken;
  
  // �ر�DMA ����ֹ����
  __HAL_DMA_DISABLE(&DMA_Handle_UART3RX);      
	// ��DMA��־λ
  __HAL_DMA_CLEAR_FLAG(&DMA_Handle_UART3RX,DMA_FLAG_TCIF2_6);   
  //  ���¸�ֵ����ֵ��������ڵ��������ܽ��յ�������֡��Ŀ   
  WRITE_REG(((DMA_Stream_TypeDef   *)DMA_Handle_UART3RX.Instance)->NDTR , USART_RBUFF_SIZE);

  __HAL_DMA_ENABLE(&DMA_Handle_UART3RX);  

  //������ֵ�ź��� �����ͽ��յ������ݱ�־����ǰ̨�����ѯ
  xSemaphoreGiveFromISR(BinarySem_Handle_fromPROTOCOL,&pxHigherPriorityTaskWoken);	//�ͷŶ�ֵ�ź��� 
 
  //�����Ҫ�Ļ�����һ�������л���ϵͳ���ж��Ƿ���Ҫ�����л�
  portYIELD_FROM_ISR(pxHigherPriorityTaskWoken);
}
void UART3_IdelCallback(void)
{
  Uart3_DMA_Rx_Data();       //�ͷ�һ���ź�������ʾ�����ѽ��� 
}

__IO uint16_t headpointer = 0;
__IO uint8_t  headChecked = 0;
__IO uint16_t memPointer = 0;
__IO uint16_t len_Comand  = 0;
uint8_t comd_buff[USART_RBUFF_SIZE]={0};

__IO uint8_t  reply = 0x55;
__IO uint16_t  len_reply = 0;
void commandParse(void)
{

   uint16_t i = 0;
   uint8_t sum = 0;
   uint16_t j = 0;
   uint8_t tempPointer = 0;
	 uint8_t commandConfirmed = 0;
 	 memcpy( (void*)comd_buff ,(void*)RX_BUFF , USART_RBUFF_SIZE);		  
   
	 for( i = 0; i < USART_RBUFF_SIZE; i++ )
   {
    if( 1 == headChecked)
    {

         tempPointer = memPointer;
  		   len_Comand = (comd_buff[tempPointer]&0x00ff) << 8;
         tempPointer ++ ;
         len_Comand += (comd_buff[tempPointer]&0x00ff);

         for(j = 0; j < len_Comand - 2; j ++  )
         {
            sum += comd_buff[2+j];
            tempPointer ++;
         }
	       #ifdef UART_DEBUG_STP
          printf("sum is %d \n",sum);  
          #endif			 
         if( (sum == comd_buff[tempPointer -1 ] )&&(0X0C == comd_buff[tempPointer ]))
         {
          //ȷ������������
          #ifdef UART_DEBUG_STP
          printf("command copy! \n");  
          #endif
					 commandConfirmed = 1;
					 headChecked = 0;
					 headpointer = 0;
					 memPointer = 0;
					 sum = 0;
           break;
         }
         else if(sum != comd_buff[tempPointer -1 ] )
				 {
           common_FillReplyArray((uint8_t)REPLY_FAIL_SUM);
           common_Reply(TX_BUFF,(uint16_t*)(&len_reply));
            #ifdef UART_DEBUG_STP
            printf("wrong SUM ! \n");  
            #endif
           break; 
         }
				 else{
           common_FillReplyArray((uint8_t)REPLY_FAIL_TAIL);
           common_Reply(TX_BUFF,(uint16_t*)(&len_reply));	
            #ifdef UART_DEBUG_STP
            printf("wrong TAIL ! \n");  
            #endif
           	}
        break;
    }
    else
    {
      if(headpointer == 0 )
      {
        if (comd_buff[memPointer] == 0x55)
        {
          headpointer ++;
          memPointer ++;
          continue;
        } 
      }
      if(headpointer == 1 )
      {
        if (comd_buff[memPointer] == 0xaa)
        {
          headpointer = 0;
          memPointer ++ ;
          headChecked = 1;
          continue;
        } 
      }    
    }//end of else
	}//END OF for()
	 
	if(1 == commandConfirmed)
	{
    switch (comd_buff[COMMAND_OFFSET])
    {
      case COMMAND_DRCF:
           commandReply_DriverConFileReadWrite( );
      break;
      case COMMAND_REBT:
           commandReply_REboot();
           common_Reply(TX_BUFF,(uint16_t*)(&len_reply));
           u8_flag_rebooting = 1;
           HAL_NVIC_SystemReset();          // ��λϵͳ
      break;

      case COMMAND_RECF://��ȡ��Ӧport��Ȼ�󿪻�������
           commondReply_RECF();
      break;  
      case COMMAND_STOP://
            commandReply_STOP();     
      break; 

      case COMMAND_REPR://
            commandReply_REPR();     
      break;  
      case COMMAND_CLPS://
            commandReply_CLPS();    
      break;       
      case COMMAND_HMPS://
            commandReply_HMPS();    
      break; 
      
      case COMMAND_CLER://
            commandReply_CLER();    
      break; 

      case COMMAND_ACPS:
           commandReply_ACPS();
      break;   

      case COMMAND_RDST:
           commandReply_RDST();
           //common_Reply(TX_BUFF,(uint16_t*)(&len_reply));
 
      break;      
      case COMMAND_WAIT:
           commandReply_WAIT(); 
           common_Reply(TX_BUFF,(uint16_t*)(&len_reply));
      break;  
      case COMMAND_ENAB:
           commandReply_ENAB(); 
           common_Reply(TX_BUFF,(uint16_t*)(&len_reply));
      break; 
      case COMMAND_HOME:
           commandReply_HOME(); 
      break; 
      case COMMAND_FDHM:
           commandReply_FDHM(); 
      break; 
      case COMMAND_MVPS:
           commandReply_MVPS(); 
      break;
      case COMMAND_STEP:
           commandReply_STEP(); 
      break;    
      case COMMAND_SPED:
           commandReply_SPED(); 
      break;    
      
      case COMMAND_PLMT:
           commandReply_PLMT(); 
      break;  

      case COMMAND_VLMT:
           commandReply_VLMT(); 
           //common_Reply(TX_BUFF,(uint16_t*)(&len_reply));
      break;  

      case COMMAND_SSCN:
           commandReply_SSCN(); 
      break; 
       case COMMAND_CSCN:
           commandReply_CSCN(); 
      break;      
    default:
      break;
    }
   commandConfirmed = 0;
	}
}

//ÿһ��Ӧ��ʵ����ʵ��׼�����飬�����Ϻ󣬽������ͺ���
void commandReply_DriverConFileReadWrite(void)
{
  uint8_t subCommand = comd_buff[SUBCOMMAND_OFFSET];
  uint8_t i = 0,  sum = 0; 
  uint16_t k = 0; 
  uint16_t len_struct = (uint16_t)(sizeof(_EEPROM_CONF_STEP)) - 2 + 1;//00240925 add 1
	//uint16_t len_struct = (uint16_t)(sizeof(_EEPROM_CONF_STEP)) - 2 ;//20250426 minus 1

  uint8_t* pbuff = NULL;
  //����ͨ�� 
  uint8_t port = subCommand >> 4;
  //������д
  uint8_t opreation = subCommand & 0x0f;

    if(0 == checkPortsAvailable(port, MOTOR_IN_USE))
    {
      common_FillReplyArray((uint8_t)REPLY_CHNANEL_FAIL); 
      common_Reply(TX_BUFF,(uint16_t*)(&len_reply));
        #ifdef UART_DEBUG_STP
          printf("WRONG PORT. \n ");
        #endif      
      return;
    }

    len_reply = len_struct + 5 ;//20240925 add 1

    if(  SUBCOMMAND_WRITE == opreation )
    {
   	  // memcpy( (void*)&ee_conFile[port-1].motorindex,(void*)&comd_buff[6], (sizeof(_EEPROM_CONF_STEP)-1));
      // I2C_EE_WriteConfigFiles((port-1),&ee_conFile[port-1]);   
			
			//20250429,д��ʱ����.motorName ��ʼ��
    	 memcpy( (void*)&ee_conFile[port-1].motorName,(void*)&comd_buff[6], (sizeof(_EEPROM_CONF_STEP)-2));
       I2C_EE_WriteConfigFiles((port-1),&ee_conFile[port-1]);  
			
			 i = 0;
       len_reply = 6;
       TX_BUFF[ i ++] =  0X55;
       TX_BUFF[ i ++ ] = 0XAA;
   
       TX_BUFF[ i ] = (uint8_t)( (len_reply & 0XFF00) >>8 );
       sum += TX_BUFF[ i ];
       i++;
       TX_BUFF[ i ] = (uint8_t)(len_reply & 0X00FF);
       sum += TX_BUFF[ i ];
       i++;
       TX_BUFF[i] = comd_buff[COMMAND_OFFSET];
       sum += TX_BUFF[ i ];
       i++;
       TX_BUFF[i] = REPLY_SUCCESS;
       sum += TX_BUFF[ i ];
       i++;  
       TX_BUFF[i++] = sum;
       TX_BUFF[i] = 0X0C;
       common_Reply(TX_BUFF,(uint16_t*)(&len_reply));
       sum = 0;          
       // added 20221008: if new confile is writing,then, the state should be refresh to default values.
       clearErrors(port-1); 
       #ifdef UART_DEBUG_STP
          printf("clear state! \n ");
       #endif  
    }
    else
    {
        i = 0;
        TX_BUFF[ i ++] =  0X55;
        TX_BUFF[ i ++ ] = 0XAA;

        TX_BUFF[ i ] = (uint8_t)( (len_reply & 0XFF00) >>8 );
        sum += TX_BUFF[ i ];
        i++;
        TX_BUFF[ i ] = (uint8_t)(len_reply & 0X00FF);
        sum += TX_BUFF[ i ];
        i++;
        TX_BUFF[i] = comd_buff[COMMAND_OFFSET];
        sum += TX_BUFF[ i ];
        i++;
        pbuff = (uint8_t*)(&ee_conFile[port-1].motorindex);
        TX_BUFF[i] = comd_buff[COMMAND_OFFSET+1];
        sum += TX_BUFF[ i ];
			  i++;
			   //pbuff = (uint8_t*)(&ee_conFile[port-1].motorName);
			//���״ֵ̬�����ͻ�����
			
        for(k = 1; k < len_struct  ; k ++)
        {
          TX_BUFF[i] = pbuff[k];
          sum += TX_BUFF[ i ];
          i ++;
        }
        TX_BUFF[i++] = sum;
        TX_BUFF[i] = 0x0c;
        common_Reply(TX_BUFF,(uint16_t*)(&len_reply));
        sum = 0;    
    }

  #ifdef UART_DEBUG_STP
    printf("DriverConFileReadWrite! \n"); 
    
    if(0 == port) { printf("all "); }
    else{ printf("motor %d is ",port); }

		//printf("ports");
		
    if( SUBCOMMAND_WRITE == opreation) { printf("writing "); }
    else{ printf(" reading "); }

    printf(" config files. \n");

  #endif 
  //����λ����Ӧ��

}
void commandReply_REboot(void)
{
    uint16_t i = 0;
    uint8_t sum = 0;
    len_reply = 6;
    TX_BUFF[ i ++] =  0X55;
    TX_BUFF[ i ++ ] = 0XAA;

    TX_BUFF[ i ] = (uint8_t)( (len_reply & 0XFF00) >>8 );
    sum += TX_BUFF[ i ];
    i++;
    TX_BUFF[ i ] = (uint8_t)(len_reply & 0X00FF);
    sum += TX_BUFF[ i ];
    i++;
    TX_BUFF[i] = comd_buff[COMMAND_OFFSET];
    sum += TX_BUFF[ i ];
    i++;
    TX_BUFF[i] = REPLY_SUCCESS;
    sum += TX_BUFF[ i ];
    i++;  

    TX_BUFF[i++] = sum;
    TX_BUFF[i] = 0X0C;
  #ifdef UART_DEBUG_STP
    printf(" Reboot... \n");
  #endif 
}
void commondReply_RECF(void)
{    
  uint16_t i = 0;
  uint8_t sum = 0;
  //���ж��Ǽ���ͨ�� ����ͨ��   
  uint8_t ports  = getPortsParce(comd_buff,SUBCOMMAND_OFFSET);
  if(0 == checkPortsAvailable_0_permission(ports, MOTOR_IN_USE)){
    common_FillReplyArray((uint8_t)REPLY_CHNANEL_FAIL); 
    common_Reply(TX_BUFF,(uint16_t*)(&len_reply));
    #ifdef UART_DEBUG_STP
      printf("WRONG PORT. \n ");
    #endif 
    return;
  }
  if (0 == ports) {  
    for(i = 0; i < MOTOR_IN_USE; i ++){
      I2C_EE_ReadConfigFiles(i, &ee_conFile[i]);
      //check home value and actual value.
      homeValueControl_permenant(i,ee_conFile[i].resolution);
      // set the state of motor to the initial state        
      initial_step_motor(i);
      initialParasForMissingstep();
    }
    #ifdef UART_DEBUG_STP
      printf("All ports'confile are reloaded. \n ");
    #endif
  }
  else{
    I2C_EE_ReadConfigFiles((ports-1), &ee_conFile[(ports-1)]);  
    //check home value and actual value.      
    homeValueControl_permenant(ports-1,ee_conFile[ports-1].resolution);        
    initial_step_motor(ports-1);
    initialParasForMissingstep();
    #ifdef UART_DEBUG_STP
      printf("motor %d's confile is reloaded. \n ",(ports -1));
    #endif
  }
    len_reply = 6;
    TX_BUFF[ i ++] =  0X55;
    TX_BUFF[ i ++ ] = 0XAA;    
    TX_BUFF[ i ] = (uint8_t)( (len_reply & 0XFF00) >>8 );
    sum += TX_BUFF[ i ];
    i++;
    TX_BUFF[ i ] = (uint8_t)(len_reply & 0X00FF);
    sum += TX_BUFF[ i ];
    i++;
    TX_BUFF[i] = comd_buff[COMMAND_OFFSET];
    sum += TX_BUFF[ i ];
    i++;
    TX_BUFF[i] = REPLY_SUCCESS;
    sum += TX_BUFF[ i ];
    i++;     
    TX_BUFF[i++] = sum;
    TX_BUFF[i] = 0X0C;
    common_Reply(TX_BUFF,(uint16_t*)(&len_reply));

}
void commandReply_RDST(void)
{
    uint16_t i = 0;
    uint8_t j = 0 , k,sum = 0;
      //���ж��Ǽ���ͨ�� ����ͨ��   
    uint8_t subCommand = comd_buff[SUBCOMMAND_OFFSET];
    uint8_t ports = subCommand >> 4;
    uint8_t* pbuff = NULL;
    //uint16_t len_struct = (uint16_t)(sizeof(State_paras_STEP));
    uint16_t len_struct = (uint16_t)(sizeof(State_mini_paras_STEP));
    len_reply = len_struct + 5;
    if(0 == checkPortsAvailable_0_permission(ports, MOTOR_IN_USE))
    {
      common_FillReplyArray((uint8_t)REPLY_CHNANEL_FAIL); 
      common_Reply(TX_BUFF,(uint16_t*)(&len_reply));
        #ifdef UART_DEBUG_STP
          printf("WRONG PORT. \n ");
        #endif      
      return;
    }

    if(0 == ports)
    {
      for(j = 0; j < MOTOR_IN_USE; j ++)
      {
        i =0;
        TX_BUFF[ i ++] =  0X55;
        TX_BUFF[ i ++ ] = 0XAA;

        TX_BUFF[ i ] = (uint8_t)( (len_reply & 0XFF00) >>8 );
        sum += TX_BUFF[ i ];
        i++;
        TX_BUFF[ i ] = (uint8_t)(len_reply & 0X00FF);
        sum += TX_BUFF[ i ];
        i++;
        TX_BUFF[i] = comd_buff[COMMAND_OFFSET];
        sum += TX_BUFF[ i ];
        i++;
        pbuff = (uint8_t*)(&state_motor_struct[j].state_struct);
        //���״ֵ̬�����ͻ�����
        for(k = 0; k < len_struct; k ++)
        {
          TX_BUFF[i] = pbuff[k];
          sum += TX_BUFF[ i ];
          i ++;
        }
        TX_BUFF[i++] = sum;
        TX_BUFF[i] = 0x0c;
        common_Reply(TX_BUFF,(uint16_t*)(&len_reply));
        sum = 0;
      }
    }
    else
    {
        i =0;
        TX_BUFF[ i ++] =  0X55;
        TX_BUFF[ i ++ ] = 0XAA;

        TX_BUFF[ i ] = (uint8_t)( (len_reply & 0XFF00) >>8 );
        sum += TX_BUFF[ i ];
        i++;
        TX_BUFF[ i ] = (uint8_t)(len_reply & 0X00FF);
        sum += TX_BUFF[ i ];
        i++;
        TX_BUFF[i] = comd_buff[COMMAND_OFFSET];
        sum += TX_BUFF[ i ];
        i++;
        pbuff = (uint8_t*)(&state_motor_struct[ports-1].state_struct);
        //���״ֵ̬�����ͻ�����
        for(k = 0; k < len_struct; k ++)
        {
          TX_BUFF[i] = pbuff[k];
          sum += TX_BUFF[ i ];
          i ++;
        }
        TX_BUFF[i++] = sum;
        TX_BUFF[i] = 0x0c;
        common_Reply(TX_BUFF,(uint16_t*)(&len_reply));
    }
} 
void commandReply_WAIT(void)
{
    uint16_t i = 0;
    uint8_t sum = 0;
    len_reply = 6;
    TX_BUFF[ i ++] =  0X55;
    TX_BUFF[ i ++ ] = 0XAA;

    TX_BUFF[ i ] = (uint8_t)( (len_reply & 0XFF00) >>8 );
    sum += TX_BUFF[ i ];
    i++;
    TX_BUFF[ i ] = (uint8_t)(len_reply & 0X00FF);
    sum += TX_BUFF[ i ];
    i++;
    TX_BUFF[i] = comd_buff[COMMAND_OFFSET];
    sum += TX_BUFF[ i ];
    i++;
    TX_BUFF[i] = REPLY_SUCCESS;
    sum += TX_BUFF[ i ];
    i++;  

    TX_BUFF[i++] = sum;
    TX_BUFF[i] = 0X0C;

    for(i = 0; i < MOTOR_IN_USE; i ++)
    {//miniState is for PC communicaiton, wait_or_not is for maintaing the machinestate.
      if(1 ==  comd_buff[COMMAND_OFFSET+1]){
        state_motor_struct[i].state_struct.miniState.state |= STATE_WAIT_OR_NOT;
      }
      else{
        state_motor_struct[i].state_struct.miniState.state &= ~STATE_WAIT_OR_NOT;
      }
      state_motor_struct[i].state_struct.wait_or_not = comd_buff[COMMAND_OFFSET+1];
      #ifdef UART_DEBUG_STP
       if( ( state_motor_struct[i].state_struct.miniState.state&STATE_WAIT_OR_NOT )== STATE_WAIT_OR_NOT ){   
         printf(" motor %d's WAIT is ON. \n ",i); 
        printf(" wait or not is %d:\n" ,state_motor_struct[i].state_struct.wait_or_not); 
       }else{
         printf(" motor %d's WAIT is Off. \n ",i); 
        printf(" wait or not is %d:\n" ,state_motor_struct[i].state_struct.wait_or_not); 
       }   
      #endif 
    }
 
    
}
void commandReply_ENAB(void)
{
    uint16_t i = 0;
    //check ports
    //uint8_t subCommand = comd_buff[SUBCOMMAND_OFFSET];
    uint8_t ports  = getPortsParce(comd_buff,SUBCOMMAND_OFFSET);

    if(0 == checkPortsAvailable_0_permission(ports, MOTOR_IN_USE))
    {
      common_FillReplyArray((uint8_t)REPLY_CHNANEL_FAIL); 
      common_Reply(TX_BUFF,(uint16_t*)(&len_reply));
        #ifdef UART_DEBUG_STP
          printf("WRONG PORT. \n ");
        #endif      
      return;
    }
    if (0 == ports)
    {  
        for(i = 0; i < MOTOR_IN_USE; i ++)
        {
        state_motor_struct[i].state_struct.miniState.state |= STATE_ENAB_OR_NOT;
        state_motor_struct[i].state_struct.enable_or_not = comd_buff[SUBCOMMAND_OFFSET+1];
        }
        #ifdef UART_DEBUG_STP
          printf("All ports are %d. \n ", comd_buff[SUBCOMMAND_OFFSET+1]);
        #endif
    }
    else{
        i = ports - 1;
        state_motor_struct[i].state_struct.miniState.state |= STATE_ENAB_OR_NOT;
        state_motor_struct[i].state_struct.enable_or_not = comd_buff[SUBCOMMAND_OFFSET+1];
        #ifdef UART_DEBUG_STP
          printf(" Port %d is %d. \n ", i,comd_buff[SUBCOMMAND_OFFSET+1]);
        #endif
    }
    common_FillReplyArray((uint8_t)REPLY_SUCCESS); 
}
void commandReply_STOP(void)
{
    uint16_t i = 0;
    //���ж��Ǽ���ͨ�� ����ͨ��   
    uint8_t ports  = getPortsParce(comd_buff,SUBCOMMAND_OFFSET);

    if(0 == checkPortsAvailable_0_permission(ports, MOTOR_IN_USE))
    {
      common_FillReplyArray((uint8_t)REPLY_CHNANEL_FAIL); 
      common_Reply(TX_BUFF,(uint16_t*)(&len_reply));
        #ifdef UART_DEBUG_STP
          printf("WRONG PORT. \n ");
        #endif      
      return;
    }
    if (0 == ports){  
        for(i = 0; i < MOTOR_IN_USE; i ++){
          stepper_Stop(step_motor[i].pul_channel); 
          step_motor[i].this_state->stateMachine = STEP_STOP;
          stop_state(i);
        }
        #ifdef UART_DEBUG_STP
          printf("All ports are STOP. \n ");
        #endif
    }
    else{
        stepper_Stop(step_motor[ ports-1 ].pul_channel);  
        step_motor[ ports-1].this_state->stateMachine = STEP_STOP;
        stop_state(ports-1);
        #ifdef UART_DEBUG_STP
          printf(" Ports %d  STOP. \n ", ports-1);
        #endif
    } 
    common_FillReplyArray((uint8_t)REPLY_SUCCESS);   
    common_Reply(TX_BUFF,(uint16_t *) (&len_reply));

}
//this function is reserved for further development
void commandReply_REPR(void)
{
    uint8_t ports  = getPortsParce(comd_buff,SUBCOMMAND_OFFSET);
    if(0 == checkPortsAvailable_0_permission(ports, MOTOR_IN_USE))
    {
      common_FillReplyArray((uint8_t)REPLY_CHNANEL_FAIL); 
      common_Reply(TX_BUFF,(uint16_t*)(&len_reply));
        #ifdef UART_DEBUG_STP
          printf("WRONG PORT. \n ");
        #endif      
      return;
    }
  #ifdef UART_DEBUG_STP
  printf("This function is reserved.");
  #endif
  common_FillReplyArray((uint8_t)REPLY_SUCCESS); 
  common_Reply(TX_BUFF,(uint16_t*)(&len_reply));   
}
void commandReply_CLER(void)
{
    uint8_t ports  = getPortsParce(comd_buff,SUBCOMMAND_OFFSET);
    uint8_t i = 0;
    if(0 == checkPortsAvailable_0_permission(ports, MOTOR_IN_USE))
    {
      common_FillReplyArray((uint8_t)REPLY_CHNANEL_FAIL); 
      common_Reply(TX_BUFF,(uint16_t*)(&len_reply));
        #ifdef UART_DEBUG_STP
          printf("WRONG PORT. \n ");
        #endif      
      return;
    }

    if(0 == ports){
      for(i = 0; i < MOTOR_IN_USE; i ++){
        clearErrors(i);      
      }
    }else{
        clearErrors(ports-1); 
    }
    common_FillReplyArray((uint8_t)REPLY_SUCCESS); 
    common_Reply(TX_BUFF,(uint16_t*)(&len_reply));
}
void commandReply_CLPS(void)
{
    //���ж��Ǽ���ͨ�� ����ͨ��   
    uint8_t ports  = getPortsParce(comd_buff,SUBCOMMAND_OFFSET);

    if(0 == checkPortsAvailable(ports, MOTOR_IN_USE))
    {
      common_FillReplyArray((uint8_t)REPLY_CHNANEL_FAIL); 
      common_Reply(TX_BUFF,(uint16_t*)(&len_reply));
        #ifdef UART_DEBUG_STP
          printf("WRONG PORT. \n ");
        #endif      
      return;
    }
    // Set the actual value = 0, clear the state home=1 and the state homeapproximate = 1.usually the COMMAND FIND HOME is followd.
      step_motor[ports-1].this_state->miniState.valueActual  = 0.0;
      actualValue_encoderAlignment(ports-1);
      step_motor[ports-1].this_state->miniState.state       &= ~STATE_HOME_OR_NOT;
      step_motor[ports-1].this_state->miniState.state       &= ~STATE_APPRO_HOME_OR_NOT;
      #ifdef UART_DEBUG_STP
          printf("port %d's vlaue = %f \n ",(int)(ports-1) , step_motor[ports-1].this_state->miniState.valueActual);
          printf("port %d's vlaue = %x \n ",(int)(ports-1) ,step_motor[ports-1].this_state->miniState.state );
          printf("port %d's vlaue = %x \n ",(int)(ports-1) ,step_motor[ports-1].this_state->miniState.state );
          print_ee_miniState_Motor(ports-1);
      #endif  
     common_FillReplyArray((uint8_t)REPLY_SUCCESS); 
     common_Reply(TX_BUFF,(uint16_t*)(&len_reply));

}
void commandReply_HMPS(void)
{
    //���ж��Ǽ���ͨ�� ����ͨ��   
    uint8_t ports  = getPortsParce(comd_buff,SUBCOMMAND_OFFSET);
    uint8_t subCommand = comd_buff[SUBCOMMAND_OFFSET];
    uint8_t permenant =  subCommand &0x0f; 
    float *pf = NULL;
    float f_newHome = 0.0;
    uint8_t u8_TempArray[4];
    memcpy( (void*)u8_TempArray ,(void*)&comd_buff[SUBCOMMAND_OFFSET + 1    ] , 4);
    pf = (float*)u8_TempArray;
    f_newHome = *pf;

    if(0 == checkPortsAvailable(ports, MOTOR_IN_USE)){
      common_FillReplyArray((uint8_t)REPLY_CHNANEL_FAIL);
      common_Reply(TX_BUFF,(uint16_t*)(&len_reply));
      #ifdef UART_DEBUG_STP
        printf("WRONG PORT. \n ");
      #endif 
      return;
    } 

    #ifdef UART_DEBUG_STP
      printf("newHome       : %f. \n ",f_newHome);
      printf("actual before : %f. \n ",state_motor_struct[ports - 1].state_struct.miniState.valueActual);
      printf("home before   : %f. \n ",ee_conFile[ports - 1].home);
      if( permenant > 0){
        printf("op is permenant. \n ");
      }
      else{
        printf("op is temp. \n ");
      }
    #endif 
    // to check whether the new home and new actual beyonds the upper and lower Position limitation!
    if( permenant > 0 ){ //�ж��Ƿ���Ҫд��EEPROM
        ee_conFile[ports - 1].home = f_newHome;
        I2C_EE_WriteConfigFiles( (ports - 1), &ee_conFile[ports - 1]); 
        homeValueControl_permenant((ports - 1),ee_conFile[ports - 1].resolution);
        actualValue_encoderAlignment(ports - 1);
    }
    else{
        homeValueControl_temporary((ports - 1), f_newHome);
        actualValue_encoderAlignment(ports - 1);
        #ifdef UART_DEBUG_STP
          printf("actual after : %f. \n ",state_motor_struct[ports - 1].state_struct.miniState.valueActual);
          printf("home after   : %f. \n ",ee_conFile[ports - 1].home);
        #endif  
    }
    common_FillReplyArray((uint8_t)REPLY_SUCCESS); 
    common_Reply(TX_BUFF,(uint16_t*)(&len_reply));
}
void commandReply_ACPS(void)
{
    uint16_t i = 0;
    uint8_t j = 0 , k,sum = 0;
    //���ж��Ǽ���ͨ�� ����ͨ��   
    uint8_t subCommand = comd_buff[SUBCOMMAND_OFFSET];
    uint8_t ports = subCommand >> 4;
    uint8_t tempLen = 0;
    uint8_t* pbuff = NULL;
    uint8_t arrayTemp[4]  ;
	  float* pfTemp = NULL;
	
    if(0 == checkPortsAvailable_0_permission(ports, MOTOR_IN_USE))
    {
      common_FillReplyArray((uint8_t)REPLY_CHNANEL_FAIL); 
      common_Reply(TX_BUFF,(uint16_t*)(&len_reply));

      #ifdef UART_DEBUG_STP
        printf("WRONG PORT. \n ");
      #endif 
      return;
    }
    tempLen = len_Comand - 2;
    if(tempLen < 5 )//û��valueֵ������£����ص�ǰʵ��ֵ
    {     
          len_reply = 9;
          if(ports == 0){ 
              for(j = 0; j < MOTOR_IN_USE; j ++)
              {  
                 i =0;
                 TX_BUFF[ i ++] =  0X55;
                 TX_BUFF[ i ++ ] = 0XAA;
                 TX_BUFF[ i ] = (uint8_t)( (len_reply & 0XFF00) >>8 );
                 sum += TX_BUFF[ i ];
                 i++;
                 TX_BUFF[ i ] = (uint8_t)(len_reply & 0X00FF);
                 sum += TX_BUFF[ i ];
                 i++;
                 TX_BUFF[i] = comd_buff[COMMAND_OFFSET];
                 sum += TX_BUFF[ i ];
                 i++;
                 pbuff = (uint8_t*)(&state_motor_struct[j].state_struct.miniState.valueActual);
                //���״ֵ̬�����ͻ�����
                for(k = 0; k < 4; k ++)
                {
                  TX_BUFF[i] = pbuff[k];
                  sum += TX_BUFF[ i ];
                  i ++;
                }
                TX_BUFF[i++] = sum;
                TX_BUFF[i] = 0x0c;
                common_Reply(TX_BUFF,(uint16_t*)(&len_reply));
              } 
              #ifdef UART_DEBUG_STP
			          printf("All port are returning actucal valuse.  \n");	
                for(i = 0; i < MOTOR_IN_USE; i ++)
                printf(" motor %d's actualValue is %f.  \n" ,i,state_motor_struct[i].state_struct.miniState.valueActual);	
		          #endif 	    
          }
          else{
                 i = 0;
                 TX_BUFF[ i ++] =  0X55;
                 TX_BUFF[ i ++ ] = 0XAA;
                 TX_BUFF[ i ] = (uint8_t)( (len_reply & 0XFF00) >>8 );
                 sum += TX_BUFF[ i ];
                 i++;
                 TX_BUFF[ i ] = (uint8_t)(len_reply & 0X00FF);
                 sum += TX_BUFF[ i ];
                 i++;
                 TX_BUFF[i] = comd_buff[COMMAND_OFFSET];
                 sum += TX_BUFF[ i ];
                 i++;
                 pbuff = (uint8_t*)(&state_motor_struct[ ports - 1 ].state_struct.miniState.valueActual);
                //���״ֵ̬�����ͻ�����
                for(k = 0; k < 4; k ++)
                {
                  TX_BUFF[ i ] = pbuff[k];
                  sum += TX_BUFF[ i ];
                  i ++;
                }
                TX_BUFF[i++] = sum;
                TX_BUFF[i] = 0x0c;
                common_Reply(TX_BUFF,(uint16_t*)(&len_reply));
              
              #ifdef UART_DEBUG_STP
			          printf("all port are returning actucal valuse.  \n");	
                printf(" motor %d's actualValue is %f.  \n" ,ports-1 ,state_motor_struct[ports - 1].state_struct.miniState.valueActual);	
		          #endif 	   

          }
    }// end of if(len < 5 )
    else{//��ָ��ͨ��д��ʵ��ֵ
          if(ports == 0){
              for(j = 0; j < MOTOR_IN_USE; j ++)
              {  
                
                 memcpy( (void*)arrayTemp ,(void*)&comd_buff[SUBCOMMAND_OFFSET + 1 ] , 4);
                 pfTemp = (float*)arrayTemp;
                 if(0 == chekLimis(*pfTemp, ee_conFile[j].lowerLimitation,ee_conFile[j].upperLimitation ))
                 {
                      common_FillReplyArray((uint8_t)REPLY_CHNANEL_FAIL); 
                      common_Reply(TX_BUFF,(uint16_t*)(&len_reply));
                      return;
                 }
			           state_motor_struct[j].state_struct.miniState.valueActual = *pfTemp;
                 actualValue_encoderAlignment(j);
              } 
              common_FillReplyArray(REPLY_SUCCESS );
              common_Reply(TX_BUFF,(uint16_t *) (&len_reply));

              #ifdef UART_DEBUG_STP
			          printf("all port are writing new  actucal values.  \n");	
                for(i = 0; i < MOTOR_IN_USE; i ++)
                printf(" motor %d's actualValue is %f.  \n" ,i,state_motor_struct[i].state_struct.miniState.valueActual);	
		          #endif 
          }
          else{
                 memcpy( (void*)arrayTemp ,(void*)&comd_buff[SUBCOMMAND_OFFSET + 1 ] , 4);
                 pfTemp = (float*)arrayTemp;
                 if(0 == chekLimis(*pfTemp, ee_conFile[ports -1].lowerLimitation,ee_conFile[ports -1].upperLimitation ))
                 {
                      common_FillReplyArray((uint8_t)REPLY_CHNANEL_FAIL); 
                      common_Reply(TX_BUFF,(uint16_t*)(&len_reply));
                      return;
                 }                
			           state_motor_struct[ports -1].state_struct.miniState.valueActual = *pfTemp;	
                 actualValue_encoderAlignment(ports -1);					
                 common_FillReplyArray(REPLY_SUCCESS );
                 common_Reply(TX_BUFF,(uint16_t *) (&len_reply));                
                 #ifdef UART_DEBUG_STP
                  printf(" motor %d's actualValue is %f.  \n" ,ports -1,state_motor_struct[ports -1].state_struct.miniState.valueActual);	
		            #endif 
          }

    }
}
void commandReply_PLMT(void)
{
    uint16_t i = 0;
    uint8_t j = 0 , k,sum = 0,tempLen;
    //���ж��Ǽ���ͨ�� ����ͨ��   
    uint8_t subCommand = comd_buff[SUBCOMMAND_OFFSET];
    uint8_t ports  = getPortsParce(comd_buff,SUBCOMMAND_OFFSET);
    uint8_t permenant =  subCommand &0x0f; 
    uint8_t* pbuff = NULL;
    float* pupper,*plower;
    uint8_t upper[4]  ;
    uint8_t lower[4]  ;
    float tempupper,templower;
    
    if(0 == checkPortsAvailable(ports, MOTOR_IN_USE))
    {
      common_FillReplyArray((uint8_t)REPLY_CHNANEL_FAIL);
      common_Reply(TX_BUFF,(uint16_t*)(&len_reply));
      #ifdef UART_DEBUG_STP
        printf("WRONG PORT. \n ");
      #endif 
      return;
    }    
    
    memcpy( (void*)upper ,(void*)&comd_buff[SUBCOMMAND_OFFSET + 1    ] , 4);
    memcpy( (void*)lower ,(void*)&comd_buff[SUBCOMMAND_OFFSET + 1 + 4] , 4);
    pupper = (float*)upper;
    plower = (float*)lower;
    tempupper = *pupper;
    templower = *plower;
    #ifdef UART_DEBUG_STP
    printf("new lower is %f \n",tempupper);  
    printf("new upper is %f \n",templower);  
    #endif

    tempLen = len_Comand - 2;

    if(tempLen > 5){
      if (0 == ports)//0 is denied. so this will never be true.
      {  
          for(i = 0; i < MOTOR_IN_USE; i ++)
          {
              ee_conFile[i].upperLimitation = tempupper;
              ee_conFile[i].lowerLimitation = templower;
              if( permenant > 0 )//�ж��Ƿ���Ҫд��EEPROM
              { I2C_EE_WriteConfigFiles( i, &ee_conFile[i]); }
          }
          #ifdef UART_DEBUG_STP
          printf("All ports are ");
          if( permenant > 0 ){printf(" permernant \n");}  
          else{printf(" temporary. \n");  }
          #endif
      }
      else
      {
          ee_conFile[ports-1].upperLimitation = tempupper;
          ee_conFile[ports-1].lowerLimitation = templower;
          if( permenant == 1 )//�ж��Ƿ���Ҫд��EEPROM
          { 
            I2C_EE_WriteConfigFiles( (uint8_t)(ports -1), &ee_conFile[ports-1]);
          } 
          positionLim_statusCheck((ports -1));
          #ifdef UART_DEBUG_STP
            printf("port %d is ",ports);
            if( permenant > 0 ){printf(" permernant \n");}  
            else{printf(" temporary. \n");  }
          #endif       
      } 
      common_FillReplyArray((uint8_t)REPLY_SUCCESS);
      common_Reply(TX_BUFF,(uint16_t*)(&len_reply));

    }
    else{//���ض�Ӧͨ����������ֵ��      
          len_reply = 5 + 4 + 4;//
          if(ports == 0){
              for(j = 0; j < MOTOR_IN_USE; j ++)
              {  
                 i =0;
                 TX_BUFF[ i ++] =  0X55;
                 TX_BUFF[ i ++ ] = 0XAA;
                 TX_BUFF[ i ] = (uint8_t)( (len_reply & 0XFF00) >>8 );
                 sum += TX_BUFF[ i ];
                 i++;
                 TX_BUFF[ i ] = (uint8_t)(len_reply & 0X00FF);
                 sum += TX_BUFF[ i ];
                 i++;
                 TX_BUFF[i] = comd_buff[COMMAND_OFFSET];
                 sum += TX_BUFF[ i ];
                 i++;
                 pbuff = (uint8_t*)(&ee_conFile[j].upperLimitation);
                for(k = 0; k < 4; k ++)
                {
                  TX_BUFF[i] = pbuff[k];
                  sum += TX_BUFF[ i ];
                  i ++;
                }
                pbuff = (uint8_t*)(&ee_conFile[j].lowerLimitation);
                for(k = 0; k < 4; k ++)
                {
                  TX_BUFF[i] = pbuff[k];
                  sum += TX_BUFF[ i ];
                  i ++;
                }               
                TX_BUFF[i++] = sum;
                TX_BUFF[i] = 0x0c;
                common_Reply(TX_BUFF,(uint16_t*)(&len_reply));
              } 
              #ifdef UART_DEBUG_STP
			          printf("All port are returning upperLimitation vlowerLimitationaluse.  \n");	
                for(i = 0; i < MOTOR_IN_USE; i ++)
                printf(" motor %d's upperLimitation is %f,lowerLimitation is %f.\n" ,i,ee_conFile[i].upperLimitation,ee_conFile[i].lowerLimitation);	
		          #endif 	    
          } 
          else{
                 i =0;
                 TX_BUFF[ i ++] =  0X55;
                 TX_BUFF[ i ++ ] = 0XAA;
                 TX_BUFF[ i ] = (uint8_t)( (len_reply & 0XFF00) >>8 );
                 sum += TX_BUFF[ i ];
                 i++;
                 TX_BUFF[ i ] = (uint8_t)(len_reply & 0X00FF);
                 sum += TX_BUFF[ i ];
                 i++;
                 TX_BUFF[i] = comd_buff[COMMAND_OFFSET];
                 sum += TX_BUFF[ i ];
                 i++;
                 pbuff = (uint8_t*)(&ee_conFile[ports - 1 ].upperLimitation);
                for(k = 0; k < 4; k ++)
                {
                  TX_BUFF[i] = pbuff[k];
                  sum += TX_BUFF[ i ];
                  i ++;
                }
                pbuff = (uint8_t*)(&ee_conFile[ports - 1 ].lowerLimitation);
                for(k = 0; k < 4; k ++)
                {
                  TX_BUFF[i] = pbuff[k];
                  sum += TX_BUFF[ i ];
                  i ++;
                }               
                TX_BUFF[i++] = sum;
                TX_BUFF[i] = 0x0c;
                common_Reply(TX_BUFF,(uint16_t*)(&len_reply));  
               #ifdef UART_DEBUG_STP
			          printf(" Port %d is returning upperLimitation vlowerLimitationaluse.  \n",(int)(ports - 1 ));	
                printf(" motor %d's upperLimitation is %f,lowerLimitation is %f.\n" ,(int)(ports - 1 ),ee_conFile[ports - 1 ].upperLimitation,ee_conFile[ports - 1 ].lowerLimitation);	
		          #endif                         
          } 
         
    }
}//end of  commandReply_COMMAND_PLMT
void commandReply_VLMT(void)
{
   uint16_t i = 0;
	 uint8_t j = 0 , k,sum = 0,tempLen;
    //���ж��Ǽ���ͨ�� ����ͨ��   
    uint8_t subCommand = comd_buff[SUBCOMMAND_OFFSET];
    uint8_t ports = subCommand >> 4;
    uint8_t permenant =  subCommand &0x0f; 
    uint8_t* pbuff = NULL;
    float* pupper,*plower;

    uint8_t upper[4]  ;
    uint8_t lower[4]  ;
    float tempupper,templower;
    if(0 == checkPortsAvailable(ports, MOTOR_IN_USE))
    {
      common_FillReplyArray((uint8_t)REPLY_CHNANEL_FAIL);
      common_Reply(TX_BUFF,(uint16_t*)(&len_reply));
      #ifdef UART_DEBUG_STP
        printf("WRONG PORT. \n ");
      #endif 
      return;
    }   

    tempLen = len_Comand - 2;
    if(tempLen > 5){
      memcpy( (void*)upper ,(void*)&comd_buff[SUBCOMMAND_OFFSET + 1    ] , 4);
      memcpy( (void*)lower ,(void*)&comd_buff[SUBCOMMAND_OFFSET + 1 + 4] , 4);
      pupper = (float*)upper;
      plower = (float*)lower;
      tempupper = *pupper;
      templower = *plower;
      #ifdef UART_DEBUG_STP
        printf("new upper  velocity is %f \n",tempupper);  
        printf("new lower velocity is %f \n",templower);  
      #endif
      if (0 == ports)//0 is denied. so this will never be true.
      {  
          for(i = 0; i < MOTOR_IN_USE; i ++)
          {
            ee_conFile[i].maxSpeedFast = tempupper;
            ee_conFile[i].minSpeedSlow = templower;
            if( permenant > 0 )//ͬʱд�����üĴ���
            { I2C_EE_WriteConfigFiles( i, &ee_conFile[i]); }
          }
          #ifdef UART_DEBUG_STP
          printf("All ports are ");
          if( permenant > 0 ){printf(" permernant \n");}  
          else{printf(" temporary. \n");  }
          #endif
      }
      else
      {
          ee_conFile[ports-1].maxSpeedFast = tempupper;
          ee_conFile[ports-1].minSpeedSlow = templower; 
          if( permenant == 1 ) {//�ж��Ƿ���Ҫд��EEPROM
            I2C_EE_WriteConfigFiles( (uint8_t)(ports -1), &ee_conFile[ports-1]);
          } 
          positionLim_statusCheck((ports -1));
          #ifdef UART_DEBUG_STP
            printf("port %d is ",ports);
            if( permenant > 0 ){printf(" permernant \n");}  
            else{printf(" temporary. \n");  }
          #endif       
      } 
      common_FillReplyArray((uint8_t)REPLY_SUCCESS);
      common_Reply(TX_BUFF,(uint16_t*)(&len_reply));
    }
    else{//���ض�Ӧͨ����������ֵ��      
          len_reply = 5 + 4 + 4;//
          if(ports == 0){
              for(j = 0; j < MOTOR_IN_USE; j ++)
              {  
                 i =0;
                 TX_BUFF[ i ++] =  0X55;
                 TX_BUFF[ i ++ ] = 0XAA;
                 TX_BUFF[ i ] = (uint8_t)( (len_reply & 0XFF00) >>8 );
                 sum += TX_BUFF[ i ];
                 i++;
                 TX_BUFF[ i ] = (uint8_t)(len_reply & 0X00FF);
                 sum += TX_BUFF[ i ];
                 i++;
                 TX_BUFF[i] = comd_buff[COMMAND_OFFSET];
                 sum += TX_BUFF[ i ];
                 i++;
                 pbuff = (uint8_t*)(&ee_conFile[j].maxSpeedFast);
                for(k = 0; k < 4; k ++)
                {
                  TX_BUFF[i] = pbuff[k];
                  sum += TX_BUFF[ i ];
                  i ++;
                }
                pbuff = (uint8_t*)(&ee_conFile[j].minSpeedSlow);
                for(k = 0; k < 4; k ++)
                {
                  TX_BUFF[i] = pbuff[k];
                  sum += TX_BUFF[ i ];
                  i ++;
                }               
                TX_BUFF[i++] = sum;
                TX_BUFF[i] = 0x0c;
                common_Reply(TX_BUFF,(uint16_t*)(&len_reply));
              } 
              #ifdef UART_DEBUG_STP
			          printf("All port are returning upperLimitation vlowerLimitationaluse.  \n");	
                for(i = 0; i < MOTOR_IN_USE; i ++)
                printf(" motor %d's upperLimitation is %f,lowerLimitation is %f.\n" ,i,ee_conFile[i].maxSpeedFast,ee_conFile[i].minSpeedSlow);	
		          #endif 	    
          } 
          else{
                 i =0;
                 TX_BUFF[ i ++] =  0X55;
                 TX_BUFF[ i ++ ] = 0XAA;
                 TX_BUFF[ i ] = (uint8_t)( (len_reply & 0XFF00) >>8 );
                 sum += TX_BUFF[ i ];
                 i++;
                 TX_BUFF[ i ] = (uint8_t)(len_reply & 0X00FF);
                 sum += TX_BUFF[ i ];
                 i++;
                 TX_BUFF[i] = comd_buff[COMMAND_OFFSET];
                 sum += TX_BUFF[ i ];
                 i++;
                 pbuff = (uint8_t*)(&ee_conFile[ports - 1 ].maxSpeedFast);
                for(k = 0; k < 4; k ++)
                {
                  TX_BUFF[i] = pbuff[k];
                  sum += TX_BUFF[ i ];
                  i ++;
                }
                pbuff = (uint8_t*)(&ee_conFile[ports - 1 ].minSpeedSlow);
                for(k = 0; k < 4; k ++)
                {
                  TX_BUFF[i] = pbuff[k];
                  sum += TX_BUFF[ i ];
                  i ++;
                }               
                TX_BUFF[i++] = sum;
                TX_BUFF[i] = 0x0c;
                common_Reply(TX_BUFF,(uint16_t*)(&len_reply));  
               #ifdef UART_DEBUG_STP
			          printf(" Port %d is returning maxSpeedFast minSpeedSlow.  \n",(int)(ports - 1 ));	
                printf(" motor %d's maxSpeedFast is %f,minSpeedSlow is %f.\n" ,(int)(ports - 1 ),ee_conFile[ports - 1 ].maxSpeedFast,ee_conFile[ports - 1 ].minSpeedSlow);	
		          #endif                         
          } 
         
    }
  
}
void commandReply_HOME(void)
{
  uint16_t i = 0;
    //���ж��Ǽ���ͨ�� ����ͨ��   
  uint8_t ports  = getPortsParce(comd_buff,SUBCOMMAND_OFFSET);
  if(0 == checkPortsAvailable_0_permission(ports, MOTOR_IN_USE))
  {
    common_FillReplyArray((uint8_t)REPLY_CHNANEL_FAIL); 
    common_Reply(TX_BUFF,(uint16_t*)(&len_reply));
    #ifdef UART_DEBUG_STP
      printf("WRONG PORT. \n ");
    #endif 
    return;
  }
  common_FillReplyArray((uint8_t)REPLY_SUCCESS); 
  
  //check if homeapprox is set 
  if (0 == ports)
  {  
    for(i = 0; i < MOTOR_IN_USE; i ++){// if up/low as home ,then FDHM may be not necessary.
      getHomeMode_fill_HOME_STRUCT(i);      
      if( motor_Home_Sig_Sturct[i].homeMode & (FDHM_FREE_COMMAND)){
      }else{
          if( (STATE_APPRO_HOME_OR_NOT & step_motor[i].this_state->miniState.state) != STATE_APPRO_HOME_OR_NOT ){
             common_FillReplyArray((uint8_t)REPLY_NOT_HOMEAPP_FAIL); 
             common_Reply(TX_BUFF,(uint16_t*)(&len_reply));
             printf(" first FDHM! \n ");
             return;
          }
      }
    }
    for(i = 0; i < MOTOR_IN_USE; i ++){
      if(STEP_STOP == step_motor[i].this_state->stateMachine){
        getHomeMode_fill_HOME_STRUCT(i);
        step_motor[ i ].this_state->stateMachine  |= STEP_HOME;
        #ifdef UART_DEBUG_STP
           disPlayHOME_SIGNALS_STRUCT(i);
          printf(" port %dis homing. \n ",i);
        #endif
      }else{
        common_FillReplyArray((uint8_t)REPLY_BUSY); 
        #ifdef UART_DEBUG_STP
          printf(" mort %d is Busy! \n ", (i) );
        #endif       
      }
    }
  }else{
      if( motor_Home_Sig_Sturct[ports-1].homeMode & (FDHM_FREE_COMMAND) ){
      }else{
         if( (STATE_APPRO_HOME_OR_NOT & step_motor[ports-1].this_state->miniState.state) != STATE_APPRO_HOME_OR_NOT ){
            common_FillReplyArray((uint8_t)REPLY_NOT_HOMEAPP_FAIL); 
            common_Reply(TX_BUFF,(uint16_t*)(&len_reply));
            printf(" frist FDHM! \n ");
            return;
         }
      }  
    if(STEP_STOP == step_motor[ports-1].this_state->stateMachine){
        getHomeMode_fill_HOME_STRUCT(ports-1);
        step_motor[ ports-1 ].this_state->stateMachine  |= STEP_HOME;
        #ifdef UART_DEBUG_STP
          printf(" port %d is  homing. \n ",(ports - 1));
          disPlayHOME_SIGNALS_STRUCT(ports - 1);
        #endif
      }else{
        common_FillReplyArray((uint8_t)REPLY_BUSY); 
        #ifdef UART_DEBUG_STP
          printf(" mort %d is Busy! \n ", (ports-1) );
        #endif       
      }  
  }
  common_Reply(TX_BUFF,(uint16_t*)(&len_reply));
}
void commandReply_FDHM(void)
{
  uint8_t ports     = getPortsParce(comd_buff,SUBCOMMAND_OFFSET);
  uint8_t direction = comd_buff[SUBCOMMAND_OFFSET]&0x0f;

  if(0 == checkPortsAvailable(ports, MOTOR_IN_USE)) {
    common_FillReplyArray((uint8_t)REPLY_CHNANEL_FAIL); 
    common_Reply(TX_BUFF,(uint16_t*)(&len_reply));
    #ifdef UART_DEBUG_STP
      printf("WRONG PORT. \n ");
    #endif 
    return;
  }

  if( STEP_STOP == step_motor[ports-1].this_state->stateMachine ){
    step_motor[ports-1].this_state->stateMachine  |= STEP_FINDINGHOME;
    getHomeMode_fill_HOME_STRUCT(ports - 1);  
    motor_Home_Sig_Sturct[ports - 1].direction     = direction;
    common_FillReplyArray((uint8_t)REPLY_SUCCESS); 
    #ifdef UART_DEBUG_STP
      printf("FDHM: on port %d.  ",ports - 1);
      printf(" direction is ");       
      if(UP == direction){
        printf("to UP. \n");
      }else{
        printf("to DOWN. \n");
      } 
      disPlayHOME_SIGNALS_STRUCT(ports - 1);     
    #endif 
  }else{
    common_FillReplyArray((uint8_t)REPLY_BUSY); 
    #ifdef UART_DEBUG_STP
      printf(" Busy! \n ");
    #endif   
  }
  common_Reply(TX_BUFF,(uint16_t*)(&len_reply));
}
void commandReply_MVPS(void)
{

  uint8_t ports       = getPortsParce(comd_buff,SUBCOMMAND_OFFSET);
  uint8_t speed_exist = comd_buff[SUBCOMMAND_OFFSET]&0x0f;
  float   f_position  = 0.0;
  float   f_speed       = 0.0;
  float   *pf         = NULL;
  uint8_t u8_TempArray[4];

  if(0 == checkPortsAvailable(ports, MOTOR_IN_USE)) {
    common_FillReplyArray((uint8_t)REPLY_CHNANEL_FAIL); 
    common_Reply(TX_BUFF,(uint16_t*)(&len_reply));
    #ifdef UART_DEBUG_STP
      printf("WRONG PORT. \n ");
    #endif 
    return;
  }

  memcpy( (void*)u8_TempArray ,(void*)&comd_buff[SUBCOMMAND_OFFSET + 1    ] , 4);
  pf = (float*)u8_TempArray;
  f_position = *pf;
  state_motor_struct[ports - 1].state_struct.miniState.valueSet = f_position;
 //check limitation 
  if(0 == chekLimis(f_position,ee_conFile[ports - 1].lowerLimitation,ee_conFile[ports - 1].upperLimitation)) {
      common_FillReplyArray((uint8_t)REPLY_FAIL);
      common_Reply(TX_BUFF,(uint16_t*)(&len_reply));
      return;
  } 
  if(1 == speed_exist){
   memcpy( (void*)u8_TempArray ,(void*)&comd_buff[SUBCOMMAND_OFFSET + 1 + 4    ] , 4);
   pf = (float*)u8_TempArray;
   f_speed = *pf; 
   state_motor_struct[ports - 1].state_struct.miniState.speedSet =  f_speed;
    #ifdef UART_DEBUG_STP
      printf("f_speed:%f\n ",f_speed);
    #endif    
    if(0 == chekLimis(f_speed,ee_conFile[ports - 1].minSpeedSlow,ee_conFile[ports - 1].maxSpeedFast)){
        common_FillReplyArray((uint8_t)REPLY_FAIL);
        common_Reply(TX_BUFF,(uint16_t*)(&len_reply));
        return;
    }
  }else{
    state_motor_struct[ports - 1].state_struct.miniState.speedSet =  ee_conFile[ports - 1].maxSpeedFast;
  }
  if( STEP_STOP == step_motor[ports-1].this_state->stateMachine ){
    step_motor[ports-1].this_state->stateMachine  |= STEP_MOVE2_POSITION;
    common_FillReplyArray((uint8_t)REPLY_SUCCESS); 
  }else{
    common_FillReplyArray((uint8_t)REPLY_BUSY); 
    common_Reply(TX_BUFF,(uint16_t*)(&len_reply));
    #ifdef UART_DEBUG_STP
      printf("busy.\n"); 
    #endif
    return;
  }
  #ifdef UART_DEBUG_STP
      printf("MVPS: on port      %d.\n ", ports - 1);
      printf("Target position is %f.\n"  , state_motor_struct[ports - 1].state_struct.miniState.valueSet);       
      if(0 == speed_exist){
        printf("speed is max. %f\n", ee_conFile[ports - 1].maxSpeedFast);
      }else{
        printf("speed is %f\n",state_motor_struct[ports - 1].state_struct.miniState.speedSet);
      } 
  #endif   
  common_Reply(TX_BUFF,(uint16_t*)(&len_reply));
}
void commandReply_STEP(void)
{

  uint8_t  ports                 = getPortsParce(comd_buff,SUBCOMMAND_OFFSET);
  uint8_t  direction             = comd_buff[SUBCOMMAND_OFFSET]&0x0f;
  uint32_t stepsToRun_resolution = 0;
  uint32_t *pu32                 = NULL;
  uint8_t u8_TempArray[4];
  
  if(0 == checkPortsAvailable(ports, MOTOR_IN_USE))
  {
    common_FillReplyArray((uint8_t)REPLY_CHNANEL_FAIL); 
    common_Reply(TX_BUFF,(uint16_t*)(&len_reply));
    #ifdef UART_DEBUG_STP
      printf("WRONG PORT. \n ");
    #endif 
    return;
  }
  if( STEP_STOP == step_motor[ports-1].this_state->stateMachine ){
    step_motor[ports-1].this_state->stateMachine  |= STEP_STEPPING;
    step_motor[ports-1].this_state->miniState.state |= STATE_RUN_OR_NOT;
    common_FillReplyArray((uint8_t)REPLY_SUCCESS); 
  }
  else{
    common_FillReplyArray((uint8_t)REPLY_BUSY); 
    common_Reply(TX_BUFF,(uint16_t*)(&len_reply));
    #ifdef UART_DEBUG_STP
      printf("busy.\n"); 
    #endif
    return;
  }

  memcpy( (void*)u8_TempArray ,(void*)&comd_buff[SUBCOMMAND_OFFSET + 1    ] , 4);
  pu32 = (uint32_t*)u8_TempArray;
  stepsToRun_resolution = *pu32;
  if(stepsToRun_resolution > 5000){
     stepsToRun_resolution = 5000;    
  }
  state_motor_struct[ports - 1].state_struct.scan_step = stepsToRun_resolution; 
  #ifdef UART_DEBUG_STP
    printf(" stepsToRun_resolution is %d. \n ",state_motor_struct[ports - 1].state_struct.scan_step);
  #endif 
  //direction 
  setDirectionForStep((ports-1),direction);
  if(0 == direction){//up
   step_motor[ports-1].this_state->miniState.valueSet = step_motor[ports-1].this_state->miniState.valueActual + state_motor_struct[ports - 1].state_struct.scan_step* ee_conFile[ports - 1].resolution;
  }
  else{
   step_motor[ports-1].this_state->miniState.valueSet = step_motor[ports-1].this_state->miniState.valueActual - state_motor_struct[ports - 1].state_struct.scan_step* ee_conFile[ports - 1].resolution;
  }
  common_Reply(TX_BUFF,(uint16_t*)(&len_reply));
}
void commandReply_SPED(void)
{

  uint8_t  ports                 = getPortsParce(comd_buff,SUBCOMMAND_OFFSET);
  uint8_t  direction             = comd_buff[SUBCOMMAND_OFFSET]&0x0f;
  float    fSpeed                = 0;
  float    *pf                   = NULL;
  uint8_t u8_TempArray[4];
  
  if(0 == checkPortsAvailable(ports, MOTOR_IN_USE)){
    common_FillReplyArray((uint8_t)REPLY_CHNANEL_FAIL); 
    common_Reply(TX_BUFF,(uint16_t*)(&len_reply));
    #ifdef UART_DEBUG_STP
      printf("WRONG PORT. \n ");
    #endif 
    return;
  } 
  memcpy( (void*)u8_TempArray ,(void*)&comd_buff[SUBCOMMAND_OFFSET + 1    ] , 4);
  pf        = (float*)u8_TempArray;
  fSpeed    = *pf;
  state_motor_struct[ports - 1].state_struct.miniState.speedSet = fSpeed;
  setDirectionForStep((ports - 1),direction);

  if( STEP_STOP == step_motor[ports-1].this_state->stateMachine ){
    step_motor[ports-1].this_state->stateMachine    |= STEP_STEPPING_WITH_SPEED;
    step_motor[ports-1].this_state->miniState.state |= STATE_RUN_OR_NOT;
    step_motor[ports-1].this_state->miniState.state &= ~STATE_HOME_OR_NOT;  // set home status =false
    common_FillReplyArray((uint8_t)REPLY_SUCCESS); 
    if(fSpeed < ee_conFile[ports-1].minSpeedSlow){
      state_motor_struct[ports - 1].state_struct.miniState.speedSet = ee_conFile[ports-1].minSpeedSlow; 
      common_FillReplyArray((uint8_t)REPLY_SPEED_FAIL); 
    }  
    if(fSpeed > ee_conFile[ports-1].maxSpeedFast){
      common_FillReplyArray((uint8_t)REPLY_SPEED_FAIL);     
      state_motor_struct[ports - 1].state_struct.miniState.speedSet = ee_conFile[ports-1].maxSpeedFast;
    }
  }else{
    common_FillReplyArray((uint8_t)REPLY_BUSY); 
    #ifdef UART_DEBUG_STP
      printf(" Busy! \n ");
    #endif   
  } 
  common_Reply(TX_BUFF,(uint16_t*)(&len_reply));
  #ifdef UART_DEBUG_STP
    printf(" fSpeed   : %f. \n ",state_motor_struct[ports - 1].state_struct.miniState.speedSet);
    printf(" direction: %d. \n ",direction);
  #endif 
}
void commandReply_SSCN(void)
{
  	uint8_t tempOffset = 0;
    uint8_t tempLen = 0;
    //���ж�������
    uint8_t subCommand = comd_buff[SUBCOMMAND_OFFSET];
    uint8_t master_port = (subCommand >> 6) - 1;
    uint8_t slave_port = ( (subCommand & 0x30)  >> 4) - 1;
    uint8_t slave_exist = subCommand & COMMAND_SSCN_SLAV_EXST;
    //����ģʽ
    uint8_t time_or_enable = subCommand & COMMAND_SSCN_MODE_ENAB;
    //��ʼλ�á�ֹͣλ�á�����
    uint8_t arrayTemp[4]  ;
    float start_masterPort = 0.0;
    float stop_masterPort = 0.0;
    float start_slavePort = 0.0;
    float step_slavePort = 0.0;
    uint32_t step = 0;
	  float  tempFloat;
    uint32_t time_ms = 0;
    float* pfTemp = NULL;
    uint32_t* pu32 = NULL;

    uint32_t u32_Steps2Move = 0;

  if(0 == checkPortsAvailable_0_permission(master_port, MOTOR_IN_USE)){
    common_FillReplyArray((uint8_t)REPLY_CHNANEL_FAIL); 
    common_Reply(TX_BUFF,(uint16_t*)(&len_reply));
    #ifdef UART_DEBUG_STP
      printf("WRONG PORT. \n ");
    #endif 
    return;
  }
  if(STEP_STOP != step_motor[master_port].this_state->stateMachine){
    common_FillReplyArray((uint8_t)REPLY_BUSY); 
    common_Reply(TX_BUFF,(uint16_t*)(&len_reply));
    #ifdef UART_DEBUG_STP
      printf("busy.\n"); 
    #endif
    return;
  } 
    memcpy( (void*)arrayTemp ,(void*)&comd_buff[SUBCOMMAND_OFFSET + 1    ] , 4);
    pfTemp = (float*)arrayTemp;
    start_masterPort = *pfTemp;

    memcpy( (void*)arrayTemp ,(void*)&comd_buff[SUBCOMMAND_OFFSET + 1 + 4] , 4);
    pfTemp = (float*)arrayTemp;
    stop_masterPort = *pfTemp;  
    // 20220916 check stop>=start
  if(stop_masterPort <= start_masterPort){
    common_FillReplyArray((uint8_t)REPLY_DIRECTION_WRONG); 
    common_Reply(TX_BUFF,(uint16_t*)(&len_reply));
    #ifdef UART_DEBUG_STP
      printf("master's stop is smaller than start. \n ");
    #endif 
    return;
  }

    memcpy( (void*)arrayTemp ,(void*)&comd_buff[SUBCOMMAND_OFFSET + 1 + 8] , 4);
    pu32 = (uint32_t*)arrayTemp;
    step = *pu32;  
    
    if(slave_port == master_port) 
    {
      common_FillReplyArray((uint8_t)REPLY_FAIL); 
      return ;
    }

    step_motor[master_port].this_state->scan_start = start_masterPort;
    step_motor[master_port].this_state->scan_stop  = stop_masterPort;
    step_motor[master_port].this_state->scan_step  = step;
    //
    tempOffset = 8;
    if( COMMAND_SSCN_MODE_ENAB != time_or_enable){
      tempOffset += 4;
      memcpy( (void*)arrayTemp ,(void*)&comd_buff[SUBCOMMAND_OFFSET + 1 + tempOffset] , 4);
      pfTemp = (float*)arrayTemp;
			tempFloat = (*pfTemp) * 1000;
			#ifdef UART_DEBUG_STP
      /*  printf("time float is  %f  \n", *pfTemp);			
			  printf("pfTemp is  %f  \n", tempFloat);		
				printf("time_ms  %d  \n", (unsigned int)tempFloat);	*/	
			#endif 
			
      time_ms = (unsigned int)tempFloat;  
      if(time_ms <= 0)
      {
        common_FillReplyArray((uint8_t)REPLY_FAIL_TIME_IS_0);    
       return;
      }
      //���ṹ��  
      step_motor[master_port].this_state->scanMode_Shadow = SCAN_MODE_TIME;
      step_motor[master_port].this_state->scanTime_2_wait_ms_shadow = time_ms; 
      step_motor[master_port].this_state->stateMachine |= STEP_STEP_SCAN_TIME;  
    }
    else{
      step_motor[master_port].this_state->scanMode_Shadow = SCAN_MODE_ENABLE;
      step_motor[master_port].this_state->scanTime_2_wait_ms_shadow = 0;
      step_motor[master_port].this_state->stateMachine |= STEP_STEP_SCAN_ENAB;
    }
     step_motor[master_port].this_state->stateMachine |= STEP_STEP_SCAN | STEP_MOVE2_POSITION ;
     step_motor[master_port].this_state->miniState.speedSet = 0.5* ee_conFile[master_port].maxSpeedFast ;

    //������ڴӶ���
    if(COMMAND_SSCN_SLAV_EXST == slave_exist){
        tempLen = len_Comand - 2;
      if(tempLen > 20){
        tempOffset += 4;
        memcpy( (void*)arrayTemp ,(void*)&comd_buff[SUBCOMMAND_OFFSET + 1 + tempOffset] , 4);
        pfTemp = (float*)arrayTemp;
			  start_slavePort = *pfTemp;

        tempOffset += 4;
        memcpy( (void*)arrayTemp ,(void*)&comd_buff[SUBCOMMAND_OFFSET + 1 + tempOffset] , 4);
		  	pu32 = (uint32_t*)arrayTemp;
        step_slavePort = *pu32;
      
        step_motor[slave_port].this_state->scan_start   = start_slavePort;
        step_motor[slave_port].this_state->scan_step    = step_slavePort;
        step_motor[slave_port].this_state->stateMachine = step_motor[master_port].this_state->stateMachine;
      }else{
        step_motor[slave_port].this_state->scan_start   = step_motor[master_port].this_state->scan_start;
        step_motor[slave_port].this_state->scan_step    = step_motor[master_port].this_state->scan_step;
        step_motor[slave_port].this_state->stateMachine = step_motor[master_port].this_state->stateMachine;
      }
       step_motor[slave_port].this_state->scanMode_Shadow           = step_motor[master_port].this_state->scanMode_Shadow;
       step_motor[slave_port].this_state->scanTime_2_wait_ms_shadow = step_motor[master_port].this_state->scanTime_2_wait_ms_shadow ;
       step_motor[slave_port].this_state->slaveChanel               = 1;//if the chanel itself is a slave channel,to 
       step_motor[slave_port].this_state->slaveChanel              |= (master_port)<<8;
        // slave stop need to calculate:
       u32_Steps2Move = fabs(step_motor[master_port].this_state->scan_start - step_motor[master_port].this_state->scan_stop)/(step_motor[master_port].this_state->scan_step * ee_conFile[master_port].resolution);    
       u32_Steps2Move += 1;
        if(step_motor[master_port].this_state->scan_start - step_motor[master_port].this_state->scan_stop <=0){// up direction
          step_motor[slave_port].this_state->scan_stop =  step_motor[slave_port].this_state->scan_start + (float)(u32_Steps2Move * ee_conFile[slave_port].resolution*step_motor[slave_port].this_state->scan_step);
          if(step_motor[slave_port].this_state->scan_stop >=  ee_conFile[slave_port].upperLimitation){
             step_motor[slave_port].this_state->scan_stop  = ee_conFile[slave_port].upperLimitation;
          }
        }else{// down direction
          step_motor[slave_port].this_state->scan_stop =  step_motor[slave_port].this_state->scan_start - (float)(u32_Steps2Move * ee_conFile[slave_port].resolution*step_motor[slave_port].this_state->scan_step);
          if(step_motor[slave_port].this_state->scan_stop <=  ee_conFile[slave_port].lowerLimitation){
             step_motor[slave_port].this_state->scan_stop  = ee_conFile[slave_port].lowerLimitation;
          }
        }
      //check the upper or lower limitaiton in scan step miniSwich. instead of the "stop "
       step_motor[slave_port].this_state->stateMachine |= STEP_STEP_SCAN | STEP_MOVE2_POSITION ;
       // in SSCN, speed is set to 0.5*maxSpeed.
       step_motor[slave_port].this_state->miniState.speedSet = 0.5* ee_conFile[slave_port].maxSpeedFast ;

       masterSlaveStruct.slave_exist  = SLAVE_EXIST; 
       masterSlaveStruct.master_ch    = master_port;
       masterSlaveStruct.slave_ch     = slave_port;
       masterSlaveStruct.master_ready = CHANNEL_NOTREADY;
       masterSlaveStruct. slave_ready = CHANNEL_NOTREADY;
    }
  #ifdef UART_DEBUG_STP   
        printf("u32_Steps2Move:%d  ", u32_Steps2Move); 
        printf("master port is %d  ", master_port);
        if( slave_exist  !=  COMMAND_SSCN_SLAV_EXST ){printf(" , no slave port. \n");}  
        else{printf(", salve port is %x \n",slave_port);  }
        
        printf("start_masterPort is %f  \n", step_motor[master_port].this_state->scan_start);
        printf("stop_masterPort is %f  \n", step_motor[master_port].this_state->scan_stop);
        printf("step is %d  \n", step_motor[master_port].this_state->scan_step);

        if(time_or_enable == COMMAND_SSCN_MODE_ENAB){  
          printf("Mode is enable.\n");
          printf("scanMode_Shadow is %d\n", step_motor[master_port].this_state->scanMode_Shadow);

          }
        else{
          printf("Mode is time. scantime is %d\n", step_motor[master_port].this_state->scanTime_2_wait_ms);
          printf("Mode is time. scanTime_2_wait_ms_shadow is %d\n", step_motor[master_port].this_state->scanTime_2_wait_ms_shadow);
        }
        displayStateMachine(master_port); 
        if(COMMAND_SSCN_SLAV_EXST == slave_exist){
        printf("start_slavePort is %f  \n", step_motor[slave_port].this_state->scan_start);
        printf("stop_slavePort is %f  \n", step_motor[slave_port].this_state->scan_stop);
        printf("step_slavePort is %d  \n", step_motor[slave_port].this_state->scan_step);
        displayStateMachine(slave_port); 
        }
     
  #endif 
  common_FillReplyArray((uint8_t)REPLY_SUCCESS); 
  common_Reply(TX_BUFF,(uint16_t*)(&len_reply));

}
void commandReply_CSCN(void)
{
    uint8_t tempOffset = 0;
    uint8_t tempLen = 0;
    //���ж�������
    uint8_t subCommand = comd_buff[SUBCOMMAND_OFFSET];
    uint8_t master_port = (subCommand >> 6) - 1;
    uint8_t slave_port = ( (subCommand & 0x30)  >> 4) - 1;
    uint8_t slave_exist = subCommand & COMMAND_SSCN_SLAV_EXST;
    uint8_t pulse_out_or_not = subCommand & COMMAND_CSCN_PULSE;
  //��ʼλ�á�ֹͣλ�á�����
    uint8_t arrayTemp[4]  ;
    float start_masterPort = 0.0;
    float stop_masterPort = 0.0;
    float start_slavePort = 0.0;
    float velosity_slavePort = 0.0;
    uint32_t step = 0;
    uint32_t step2 = 0;
	  float  tempFloat;
    uint32_t time_ms = 0;
    float* pfTemp = NULL;
    uint32_t* pu32 = NULL;
    uint32_t u32_Steps2Move = 0;

    if(0 == checkPortsAvailable_0_permission(master_port, MOTOR_IN_USE)){
      common_FillReplyArray((uint8_t)REPLY_CHNANEL_FAIL); 
      common_Reply(TX_BUFF,(uint16_t*)(&len_reply));
      #ifdef UART_DEBUG_STP
        printf("WRONG PORT. \n ");
      #endif 
      return;
    } 
    if(STEP_STOP != step_motor[master_port].this_state->stateMachine){
      common_FillReplyArray((uint8_t)REPLY_BUSY); 
      common_Reply(TX_BUFF,(uint16_t*)(&len_reply));
      #ifdef UART_DEBUG_STP
        printf(" master is busy.\n"); 
      #endif
      return;
    } 
    if(slave_exist == COMMAND_SSCN_SLAV_EXST){
        if(master_port == slave_port){
          common_FillReplyArray((uint8_t)REPLY_FAIL); 
          return;
        }
        if(STEP_STOP != step_motor[slave_port].this_state->stateMachine){
          common_FillReplyArray((uint8_t)REPLY_BUSY); 
          common_Reply(TX_BUFF,(uint16_t*)(&len_reply));
          #ifdef UART_DEBUG_STP
             printf(" slave is busy.\n"); 
          #endif
          return;
        }
    }
    tempOffset = 0;
    memcpy( (void*)arrayTemp ,(void*)&comd_buff[SUBCOMMAND_OFFSET + 1    ] , 4);
    pfTemp = (float*)arrayTemp;
    start_masterPort = *pfTemp;
    
    tempOffset += 4;
    memcpy( (void*)arrayTemp ,(void*)&comd_buff[SUBCOMMAND_OFFSET + 1 + tempOffset] , 4);
    pfTemp = (float*)arrayTemp;
    stop_masterPort = *pfTemp; 

    // 20220916 check stop>=start
  if(stop_masterPort <= start_masterPort){
    common_FillReplyArray((uint8_t)REPLY_DIRECTION_WRONG); 
    common_Reply(TX_BUFF,(uint16_t*)(&len_reply));
    #ifdef UART_DEBUG_STP
      printf("master's stop is smaller than start. \n ");
    #endif 
    return;
  }
    tempOffset += 4;
    memcpy( (void*)arrayTemp ,(void*)&comd_buff[SUBCOMMAND_OFFSET + 1 + tempOffset] , 4);
    pu32 = (uint32_t*)arrayTemp;
    step = *pu32;  

    tempOffset += 4;
    memcpy( (void*)arrayTemp ,(void*)&comd_buff[SUBCOMMAND_OFFSET + 1 + tempOffset] , 4);
    pfTemp = (float*)arrayTemp;
		tempFloat = (*pfTemp) * 1000;
		time_ms =  (unsigned int)tempFloat;
    #ifdef UART_DEBUG_STP
			printf("time_ms  %d  \n", (unsigned int)tempFloat);		
		#endif 	
    time_ms = (unsigned int)tempFloat;       
    if(time_ms <= 0)
    {
      common_FillReplyArray((uint8_t)REPLY_FAIL_TIME_IS_0);    
      return;
    } 

    if (start_masterPort >  ee_conFile[master_port].upperLimitation ){
        start_masterPort =  ee_conFile[master_port].upperLimitation ;}
    if (start_masterPort <  ee_conFile[master_port].lowerLimitation ){
        start_masterPort =  ee_conFile[master_port].lowerLimitation ;}

    if (stop_masterPort >  ee_conFile[master_port].upperLimitation ){
        stop_masterPort =  ee_conFile[master_port].upperLimitation ;}
    if (stop_masterPort <  ee_conFile[master_port].lowerLimitation ){
        stop_masterPort =  ee_conFile[master_port].lowerLimitation ;}


    step_motor[master_port].this_state->scanMode_Shadow           = SCAN_MODE_CONTINUE;//this is not used in CSCN
    step_motor[master_port].this_state->scanTime_2_wait_ms_shadow = time_ms; 
    step_motor[master_port].this_state->stateMachine             |= STEP_STEP_CONTINUE_SCAN| STEP_MOVE2_POSITION;  
    step_motor[master_port].this_state->scan_start                = start_masterPort;     
    step_motor[master_port].this_state->scan_stop                 = stop_masterPort;
    step_motor[master_port].this_state->scan_step                 = step; 

    if(slave_exist == COMMAND_SSCN_SLAV_EXST){
        tempLen = len_Comand - 2;
      if(tempLen > 22){
        tempOffset += 4;
        memcpy( (void*)arrayTemp ,(void*)&comd_buff[SUBCOMMAND_OFFSET + 1 + tempOffset] , 4);
        pfTemp = (float*)arrayTemp;
			  start_slavePort = *pfTemp;

        tempOffset += 4;
        memcpy( (void*)arrayTemp ,(void*)&comd_buff[SUBCOMMAND_OFFSET + 1 + tempOffset] , 4);
		  	pu32 = (uint32_t*)arrayTemp;
        step2 = *pu32;
      
        step_motor[slave_port].this_state->scan_start   = start_slavePort;
        step_motor[slave_port].this_state->stateMachine = step_motor[master_port].this_state->stateMachine;
        step_motor[slave_port].this_state->scan_step    = step2;
      }else{
        step_motor[slave_port].this_state->scan_start   = step_motor[master_port].this_state->scan_start;
        step_motor[slave_port].this_state->scan_step    = step_motor[master_port].this_state->scan_step;
        step_motor[slave_port].this_state->stateMachine = step_motor[master_port].this_state->stateMachine;      
      }
       step_motor[slave_port].this_state->scanMode_Shadow           = step_motor[master_port].this_state->scanMode_Shadow;
       step_motor[slave_port].this_state->scanTime_2_wait_ms_shadow = step_motor[master_port].this_state->scanTime_2_wait_ms_shadow ;
       step_motor[slave_port].this_state->slaveChanel = 1;//if the chanel itself is a slave channel,to 
       // slave_stop need to be calculated:
       u32_Steps2Move = fabs(step_motor[master_port].this_state->scan_start - step_motor[master_port].this_state->scan_stop)/(step_motor[master_port].this_state->scan_step * ee_conFile[master_port].resolution);    
       u32_Steps2Move += 1;
        if(step_motor[master_port].this_state->scan_start - step_motor[master_port].this_state->scan_stop <=0){// up direction
          step_motor[slave_port].this_state->scan_stop =  step_motor[slave_port].this_state->scan_start + (float)(u32_Steps2Move * ee_conFile[slave_port].resolution*step_motor[slave_port].this_state->scan_step);
          if(step_motor[slave_port].this_state->scan_stop >=  ee_conFile[slave_port].upperLimitation){
             step_motor[slave_port].this_state->scan_stop  = ee_conFile[slave_port].upperLimitation;
          }
        }else{// down direction
          step_motor[slave_port].this_state->scan_stop =  step_motor[slave_port].this_state->scan_start - (float)(u32_Steps2Move * ee_conFile[slave_port].resolution*step_motor[slave_port].this_state->scan_step);
          if(step_motor[slave_port].this_state->scan_stop <=  ee_conFile[slave_port].lowerLimitation){
             step_motor[slave_port].this_state->scan_stop  = ee_conFile[slave_port].lowerLimitation;
          }
        }

       masterSlaveStruct.slave_exist  = SLAVE_EXIST; 
       masterSlaveStruct.master_ch    = master_port;
       masterSlaveStruct.slave_ch     = slave_port;
       masterSlaveStruct.master_ready = CHANNEL_NOTREADY;
       masterSlaveStruct. slave_ready = CHANNEL_NOTREADY;
    }
    if( pulse_out_or_not ==  COMMAND_CSCN_PULSE ){
      step_motor[master_port].this_state->pulse_out_or_not   = 1;      
      step_motor[slave_port].this_state->pulse_out_or_not   = 1;          
    }else{
      step_motor[master_port].this_state->pulse_out_or_not   = 0;
      step_motor[slave_port].this_state->pulse_out_or_not   = 0;      
    }

    common_FillReplyArray((uint8_t)REPLY_SUCCESS);
    common_Reply(TX_BUFF,(uint16_t*)(&len_reply));

    #ifdef UART_DEBUG_STP       
        printf("master port is %d  ", master_port);
        if( slave_exist  !=  COMMAND_SSCN_SLAV_EXST ){printf(" , no slave port. \n");}  
        else{printf(", salve port is %d \n",slave_port);  }
        
        printf("start_masterPort is %f  \n", step_motor[master_port].this_state->scan_start);
        printf("stop_masterPort is %f  \n", step_motor[master_port].this_state->scan_stop);
        printf("step is %d  \n", step);
        printf("pulse_out_or_not is %d  \n", step_motor[master_port].this_state->pulse_out_or_not);
        printf("scanTime_2_wait_ms is %d  \n", time_ms);

        displayStateMachine(master_port); 
        if(COMMAND_SSCN_SLAV_EXST == slave_exist){
        printf("start_slavePort is %f  \n", step_motor[slave_port].this_state->scan_start);
        printf("velosity_slavePort is %f  \n", step_motor[slave_port].this_state->scan_velosity);
        printf("slaveport'step is %d  ", step_motor[slave_port].this_state->scan_step);
        printf("slaveport'stop is %f  ", step_motor[slave_port].this_state->scan_stop);

        displayStateMachine(slave_port); 
        }
    #endif    
}
void commandReply_CSCN_velocity(void)
{
    uint8_t tempOffset = 0;
    uint8_t tempLen = 0;
    //���ж�������
    uint8_t subCommand = comd_buff[SUBCOMMAND_OFFSET];
    uint8_t master_port = (subCommand >> 6) - 1;
    uint8_t slave_port = ( (subCommand & 0x30)  >> 4) - 1;
    uint8_t slave_exist = subCommand & COMMAND_SSCN_SLAV_EXST;
    uint8_t pulse_out_or_not = subCommand & COMMAND_CSCN_PULSE;
  //��ʼλ�á�ֹͣλ�á�����
    uint8_t arrayTemp[4]  ;
    float start_masterPort = 0.0;
    float stop_masterPort = 0.0;
    float start_slavePort = 0.0;
    float velosity_slavePort = 0.0;
    uint32_t step = 0;
	  float  tempFloat;
    uint32_t time_ms = 0;
    float* pfTemp = NULL;
    uint32_t* pu32 = NULL;
    uint32_t u32_Steps2Move = 0;
    if(0 == checkPortsAvailable_0_permission(master_port, MOTOR_IN_USE)){
      common_FillReplyArray((uint8_t)REPLY_CHNANEL_FAIL); 
      common_Reply(TX_BUFF,(uint16_t*)(&len_reply));
      #ifdef UART_DEBUG_STP
        printf("WRONG PORT. \n ");
      #endif 
      return;
    } 
    if(STEP_STOP != step_motor[master_port].this_state->stateMachine){
      common_FillReplyArray((uint8_t)REPLY_BUSY); 
      common_Reply(TX_BUFF,(uint16_t*)(&len_reply));
      #ifdef UART_DEBUG_STP
        printf(" master is busy.\n"); 
      #endif
      return;
    } 
    if(slave_exist == COMMAND_SSCN_SLAV_EXST){
        if(master_port == slave_port){
          common_FillReplyArray((uint8_t)REPLY_FAIL); 
          return;
        }
        if(STEP_STOP != step_motor[slave_port].this_state->stateMachine){
          common_FillReplyArray((uint8_t)REPLY_BUSY); 
          common_Reply(TX_BUFF,(uint16_t*)(&len_reply));
          #ifdef UART_DEBUG_STP
             printf(" slave is busy.\n"); 
          #endif
          return;
        }
    }
    tempOffset = 0;
    memcpy( (void*)arrayTemp ,(void*)&comd_buff[SUBCOMMAND_OFFSET + 1    ] , 4);
    pfTemp = (float*)arrayTemp;
    start_masterPort = *pfTemp;
    
    tempOffset += 4;
    memcpy( (void*)arrayTemp ,(void*)&comd_buff[SUBCOMMAND_OFFSET + 1 + tempOffset] , 4);
    pfTemp = (float*)arrayTemp;
    stop_masterPort = *pfTemp; 

    tempOffset += 4;
    memcpy( (void*)arrayTemp ,(void*)&comd_buff[SUBCOMMAND_OFFSET + 1 + tempOffset] , 4);
    pu32 = (uint32_t*)arrayTemp;
    step = *pu32;  

    tempOffset += 4;
    memcpy( (void*)arrayTemp ,(void*)&comd_buff[SUBCOMMAND_OFFSET + 1 + tempOffset] , 4);
    pfTemp = (float*)arrayTemp;
		tempFloat = (*pfTemp) * 1000;
		time_ms =  (unsigned int)tempFloat;
    #ifdef UART_DEBUG_STP
			printf("time_ms  %d  \n", (unsigned int)tempFloat);		
		#endif 	
    time_ms = (unsigned int)tempFloat;       
    if(time_ms <= 0)
    {
      common_FillReplyArray((uint8_t)REPLY_FAIL_TIME_IS_0);    
      return;
    } 

    if (start_masterPort >  ee_conFile[master_port].upperLimitation ){
        start_masterPort =  ee_conFile[master_port].upperLimitation ;}
    if (start_masterPort <  ee_conFile[master_port].lowerLimitation ){
        start_masterPort =  ee_conFile[master_port].lowerLimitation ;}

    if (stop_masterPort >  ee_conFile[master_port].upperLimitation ){
        stop_masterPort =  ee_conFile[master_port].upperLimitation ;}
    if (stop_masterPort <  ee_conFile[master_port].lowerLimitation ){
        stop_masterPort =  ee_conFile[master_port].lowerLimitation ;}


    step_motor[master_port].this_state->scanMode_Shadow           = SCAN_MODE_CONTINUE;//this is not used in CSCN
    step_motor[master_port].this_state->scanTime_2_wait_ms_shadow = time_ms; 
    step_motor[master_port].this_state->stateMachine             |= STEP_STEP_CONTINUE_SCAN| STEP_MOVE2_POSITION;  
    step_motor[master_port].this_state->scan_start                = start_masterPort;     
    step_motor[master_port].this_state->scan_stop                 = stop_masterPort;
    step_motor[master_port].this_state->scan_step                 = step; 

    if(slave_exist == COMMAND_SSCN_SLAV_EXST){
        tempLen = len_Comand - 2;
      if(tempLen > 22){
        tempOffset += 4;
        memcpy( (void*)arrayTemp ,(void*)&comd_buff[SUBCOMMAND_OFFSET + 1 + tempOffset] , 4);
        pfTemp = (float*)arrayTemp;
			  start_slavePort = *pfTemp;

        tempOffset += 4;
        memcpy( (void*)arrayTemp ,(void*)&comd_buff[SUBCOMMAND_OFFSET + 1 + tempOffset] , 4);
		  	pfTemp = (float*)arrayTemp;
        velosity_slavePort = *pfTemp;
      
        step_motor[slave_port].this_state->scan_start    = start_slavePort;
        step_motor[slave_port].this_state->scan_velosity = velosity_slavePort;
        step_motor[slave_port].this_state->stateMachine  = step_motor[master_port].this_state->stateMachine;
        // Attention: step is calculated by velosity.
        step_motor[slave_port].this_state->scan_step    = (uint32_t)(step_motor[slave_port].this_state->scan_velosity/ee_conFile[slave_port].resolution );
        step_motor[slave_port].this_state->scan_step ++;
      }else{
        step_motor[slave_port].this_state->scan_start   = step_motor[master_port].this_state->scan_start;
        step_motor[slave_port].this_state->scan_step    = step_motor[master_port].this_state->scan_step;
        step_motor[slave_port].this_state->stateMachine = step_motor[master_port].this_state->stateMachine;      
      }
       step_motor[slave_port].this_state->scanMode_Shadow           = step_motor[master_port].this_state->scanMode_Shadow;
       step_motor[slave_port].this_state->scanTime_2_wait_ms_shadow = step_motor[master_port].this_state->scanTime_2_wait_ms_shadow ;
       step_motor[slave_port].this_state->slaveChanel = 1;//if the chanel itself is a slave channel,to 
       // slave_stop need to be calculated:
       u32_Steps2Move = fabs(step_motor[master_port].this_state->scan_start - step_motor[master_port].this_state->scan_stop)/(step_motor[master_port].this_state->scan_step * ee_conFile[master_port].resolution);    
       u32_Steps2Move += 1;
        if(step_motor[master_port].this_state->scan_start - step_motor[master_port].this_state->scan_stop <=0){// up direction
          step_motor[slave_port].this_state->scan_stop =  step_motor[slave_port].this_state->scan_start + (float)(u32_Steps2Move * ee_conFile[slave_port].resolution*step_motor[slave_port].this_state->scan_step);
          if(step_motor[slave_port].this_state->scan_stop >=  ee_conFile[slave_port].upperLimitation){
             step_motor[slave_port].this_state->scan_stop  = ee_conFile[slave_port].upperLimitation;
          }
        }else{// down direction
          step_motor[slave_port].this_state->scan_stop =  step_motor[slave_port].this_state->scan_start - (float)(u32_Steps2Move * ee_conFile[slave_port].resolution*step_motor[slave_port].this_state->scan_step);
          if(step_motor[slave_port].this_state->scan_stop <=  ee_conFile[slave_port].lowerLimitation){
             step_motor[slave_port].this_state->scan_stop  = ee_conFile[slave_port].lowerLimitation;
          }
        }
    }
    if( pulse_out_or_not ==  COMMAND_CSCN_PULSE )
      step_motor[master_port].this_state->pulse_out_or_not   = 1;
    else
      step_motor[master_port].this_state->pulse_out_or_not   = 0;
    common_FillReplyArray((uint8_t)REPLY_SUCCESS);
    common_Reply(TX_BUFF,(uint16_t*)(&len_reply));

    #ifdef UART_DEBUG_STP       
        printf("master port is %d  ", master_port);
        if( slave_exist  !=  COMMAND_SSCN_SLAV_EXST ){printf(" , no slave port. \n");}  
        else{printf(", salve port is %d \n",slave_port);  }
        
        printf("start_masterPort is %f  \n", step_motor[master_port].this_state->scan_start);
        printf("stop_masterPort is %f  \n", step_motor[master_port].this_state->scan_stop);
        printf("step is %d  \n", step);
        printf("pulse_out_or_not is %d  \n", step_motor[master_port].this_state->pulse_out_or_not);
        printf("scanTime_2_wait_ms is %d  \n", time_ms);

        displayStateMachine(master_port); 
        if(COMMAND_SSCN_SLAV_EXST == slave_exist){
        printf("start_slavePort is %f  \n", step_motor[slave_port].this_state->scan_start);
        printf("velosity_slavePort is %f  \n", step_motor[slave_port].this_state->scan_velosity);
        printf("slaveport'step is %d  ", step_motor[slave_port].this_state->scan_step);
        printf("slaveport'stop is %f  ", step_motor[slave_port].this_state->scan_stop);

        displayStateMachine(slave_port); 
        }
    #endif    
}
// function name :getHomeMode
// This function is employed to fill the HOME_SIGNALS_STRUCT
// then,the HOME_SIGNALS_STRUCT is the key for homing.
// HOME_SIGNALS_STRUCT
unsigned char getHomeMode_fill_HOME_STRUCT(uint8_t port)
{
  unsigned char homeMode = 0;
  uint16_t homeAvailable = 0;
  uint16_t limit_As_Home = 0;
  homeAvailable = BIT1_HOME_AVAILABLE_HCONF1|
                  BIT2_HOME_AVAILABLE_HCONF1|
                  BIT3_HOME_AVAILABLE_HCONF1|
                  BIT4_HOME_AVAILABLE_HCONF1;
  limit_As_Home = LOW_AS_HOME_AVAILABLE_HCONF1|
                  UP_AS_HOME_AVAILABLE_HCONF1;

    #ifdef UART_DEBUG_STP
      printf("homeAvailable : 0x%x \n ", homeAvailable);
      printf("limit_As_Home : 0x%x \n ", limit_As_Home);
    #endif
  if((ee_conFile[port].this_HCONF.hconf1 & homeAvailable) != 0){ //home exists.		   
      if((ee_conFile[port].this_HCONF.hconf1 & INDEX_AVAILABLE_HCONF1 ) == INDEX_AVAILABLE_HCONF1){
        // HOME + INDEX
        homeMode = HOME_HOME_INDEX;	
        motor_Home_Sig_Sturct[port].homeMode = homeMode;
        motor_Home_Sig_Sturct[port].pu16_signal1 = &step_motor[port].home_pin_interrupt;
        motor_Home_Sig_Sturct[port].pu16_signal2 = &step_motor[port].index_pin_interrupt;
				// determine the IO level
				if(ee_conFile[port].this_HCONF.hconf2 & HOME_HIGH_HCONF2){
           motor_Home_Sig_Sturct[port].sig1_level = 1;       
        }else{
           motor_Home_Sig_Sturct[port].sig1_level = 0;   
        }
        if(ee_conFile[port].this_HCONF.hconf2 & INDEX_HIGH_HCONF2){
	         motor_Home_Sig_Sturct[port].sig2_level = 1;
        }else{
	         motor_Home_Sig_Sturct[port].sig2_level = 0;          
        }       
        // In this mode ,the following 2 values are not used.
				motor_Home_Sig_Sturct[port].f_value_1 = ee_conFile[port].upperLimitation;
				motor_Home_Sig_Sturct[port].f_value_2 = ee_conFile[port].lowerLimitation;

 				motor_Home_Sig_Sturct[port].gpio_sig1_pin  = step_motor[port].home_pin;
				motor_Home_Sig_Sturct[port].gpio_sig1_port = step_motor[port].home_port;       
 				motor_Home_Sig_Sturct[port].gpio_sig2_pin  = step_motor[port].index_pin;
				motor_Home_Sig_Sturct[port].gpio_sig2_port = step_motor[port].index_port; 
        return homeMode;
			}
      else{// HOME + NONE
        homeMode = HOME_HOME_NONE;
        motor_Home_Sig_Sturct[port].homeMode = homeMode;
        motor_Home_Sig_Sturct[port].pu16_signal1 = &step_motor[port].home_pin_interrupt;
        motor_Home_Sig_Sturct[port].pu16_signal2 = NULL;
				// determine the IO level
				if(ee_conFile[port].this_HCONF.hconf2 & HOME_HIGH_HCONF2){
           motor_Home_Sig_Sturct[port].sig1_level = 1;       
        }else{
           motor_Home_Sig_Sturct[port].sig1_level = 0;   
        }

				motor_Home_Sig_Sturct[port].sig2_level = 0;        
        // In this mode ,the following 2 values are not used.
				motor_Home_Sig_Sturct[port].f_value_1 = ee_conFile[port].upperLimitation;
				motor_Home_Sig_Sturct[port].f_value_2 = ee_conFile[port].lowerLimitation;

  			motor_Home_Sig_Sturct[port].gpio_sig1_pin  = step_motor[port].home_pin;
				motor_Home_Sig_Sturct[port].gpio_sig1_port = step_motor[port].home_port;       
 				motor_Home_Sig_Sturct[port].gpio_sig2_pin  = 0;
				motor_Home_Sig_Sturct[port].gpio_sig2_port = NULL;        
				return homeMode;       
      }   
	}// end of home exists
  else {  
     // lower limitaion is home, and index exists, LOW + INDEX
		 if( LOW_AS_HOME_AVAILABLE_HCONF1 == (ee_conFile[port].this_HCONF.hconf1 & LOW_AS_HOME_AVAILABLE_HCONF1)) {
      if(INDEX_AVAILABLE_HCONF1 == (ee_conFile[port].this_HCONF.hconf1 & INDEX_AVAILABLE_HCONF1)){
        homeMode = HOME_LOW_INDEX;
        motor_Home_Sig_Sturct[port].homeMode = homeMode;

        motor_Home_Sig_Sturct[port].pu16_signal1 = &step_motor[port].limN_pin_interrupt;
        motor_Home_Sig_Sturct[port].pu16_signal2 = &step_motor[port].index_pin_interrupt;
				// determine the IO level
				if(ee_conFile[port].this_HCONF.hconf2 & LOW_LIMITIATION_HCONF2){
           motor_Home_Sig_Sturct[port].sig1_level = 1;       
        }else{
           motor_Home_Sig_Sturct[port].sig1_level = 0;   
        }
        if(ee_conFile[port].this_HCONF.hconf2 & INDEX_HIGH_HCONF2){
	         motor_Home_Sig_Sturct[port].sig2_level = 1;
        }else{
	         motor_Home_Sig_Sturct[port].sig2_level = 0;          
        }
        // In this mode ,the following 2 values are not used.
				motor_Home_Sig_Sturct[port].f_value_1 = ee_conFile[port].upperLimitation;
				motor_Home_Sig_Sturct[port].f_value_2 = ee_conFile[port].lowerLimitation;

 				motor_Home_Sig_Sturct[port].gpio_sig1_pin  = step_motor[port].limN_pin;
				motor_Home_Sig_Sturct[port].gpio_sig1_port = step_motor[port].limN_port;       
 				motor_Home_Sig_Sturct[port].gpio_sig2_pin  = step_motor[port].index_pin;
				motor_Home_Sig_Sturct[port].gpio_sig2_port = step_motor[port].index_port; 
        
				return homeMode;
      }
      if(UPLIM_AVAILABLE_HCONF1 == (ee_conFile[port].this_HCONF.hconf1 & UPLIM_AVAILABLE_HCONF1)){       
        //20241012 add: if uppervalue == lowervalue ,then homemod is limt and limt
        if(ee_conFile[port].upperLimitation == ee_conFile[port].lowerLimitation){
          homeMode = HOME_LIMT_LIMT;//show up 2 times
        }else{
          homeMode = HOME_LOLIMT_VALUE;
        }        
        
        motor_Home_Sig_Sturct[port].homeMode = homeMode;
        motor_Home_Sig_Sturct[port].pu16_signal1 = &step_motor[port].limN_pin_interrupt ;
        motor_Home_Sig_Sturct[port].pu16_signal2 = &step_motor[port].limP_pin_interrupt;
				// determine the IO level
				if(ee_conFile[port].this_HCONF.hconf2 & LOW_LIMITIATION_HCONF2){
           motor_Home_Sig_Sturct[port].sig1_level = 1;       
        }else{
           motor_Home_Sig_Sturct[port].sig1_level = 0;   
        }
        if(ee_conFile[port].this_HCONF.hconf2 & UP_LIMITIATION_HCONF2){
	         motor_Home_Sig_Sturct[port].sig2_level = 1;
        }else{
	         motor_Home_Sig_Sturct[port].sig2_level = 0;          
        }
        // In this mode ,the following 2 values are not used.
				motor_Home_Sig_Sturct[port].f_value_1 = ee_conFile[port].lowerLimitation ;
				motor_Home_Sig_Sturct[port].f_value_2 = ee_conFile[port].upperLimitation;

 				motor_Home_Sig_Sturct[port].gpio_sig1_pin  = step_motor[port].limN_pin;
				motor_Home_Sig_Sturct[port].gpio_sig1_port = step_motor[port].limN_port;       
 				motor_Home_Sig_Sturct[port].gpio_sig2_pin  = step_motor[port].limP_pin;
				motor_Home_Sig_Sturct[port].gpio_sig2_port = step_motor[port].limP_port;         
				return homeMode;
      }
      // if goes here ,must be the HOME_LOLIMT_VALUE mode, a signal and it's value
        homeMode = HOME_LOLIMT_VALUE;
        motor_Home_Sig_Sturct[port].homeMode = homeMode;
        motor_Home_Sig_Sturct[port].pu16_signal1 = &step_motor[port].limN_pin_interrupt;
				// determine the IO level
 				if(ee_conFile[port].this_HCONF.hconf2 & LOW_LIMITIATION_HCONF2){
           motor_Home_Sig_Sturct[port].sig1_level = 1;       
        }else{
           motor_Home_Sig_Sturct[port].sig1_level = 0;   
        }      
        motor_Home_Sig_Sturct[port].f_value_1 = ee_conFile[port].lowerLimitation;
        
        // In this mode ,the following three values of signal 2 are not used.
        motor_Home_Sig_Sturct[port].pu16_signal2 = NULL;
				motor_Home_Sig_Sturct[port].sig2_level = 0;
        motor_Home_Sig_Sturct[port].f_value_2 = ee_conFile[port].upperLimitation;

 				motor_Home_Sig_Sturct[port].gpio_sig1_pin  = step_motor[port].limN_pin;
				motor_Home_Sig_Sturct[port].gpio_sig1_port = step_motor[port].limN_port;       
 				motor_Home_Sig_Sturct[port].gpio_sig2_pin  = 0;
				motor_Home_Sig_Sturct[port].gpio_sig2_port = NULL;     

        return homeMode;
    }
     // upper limitaion is home, and index exists, HIGH + INDEX
		if( UP_AS_HOME_AVAILABLE_HCONF1 == (ee_conFile[port].this_HCONF.hconf1 & UP_AS_HOME_AVAILABLE_HCONF1)){
      if(INDEX_AVAILABLE_HCONF1 == (ee_conFile[port].this_HCONF.hconf1 & INDEX_AVAILABLE_HCONF1)){

        homeMode                                 = HOME_UPPER_INDEX;
        motor_Home_Sig_Sturct[port].homeMode     = homeMode;
        motor_Home_Sig_Sturct[port].pu16_signal1 = &step_motor[port].limP_pin_interrupt;
        motor_Home_Sig_Sturct[port].pu16_signal2 = &step_motor[port].index_pin_interrupt;
				// determine the IO level
				if(ee_conFile[port].this_HCONF.hconf2 & UP_LIMITIATION_HCONF2){
           motor_Home_Sig_Sturct[port].sig1_level = 1;       
        }else{
           motor_Home_Sig_Sturct[port].sig1_level = 0;   
        }
        if(ee_conFile[port].this_HCONF.hconf2 & INDEX_HIGH_HCONF2){
	         motor_Home_Sig_Sturct[port].sig2_level = 1;
        }else{
	         motor_Home_Sig_Sturct[port].sig2_level = 0;          
        }
        // In this mode ,the following 2 values are not used.
				motor_Home_Sig_Sturct[port].f_value_1 = ee_conFile[port].upperLimitation;
				motor_Home_Sig_Sturct[port].f_value_2 = ee_conFile[port].lowerLimitation;

  			motor_Home_Sig_Sturct[port].gpio_sig1_pin  = step_motor[port].limP_pin;
				motor_Home_Sig_Sturct[port].gpio_sig1_port = step_motor[port].limP_port;       
 				motor_Home_Sig_Sturct[port].gpio_sig2_pin  = step_motor[port].index_pin;
				motor_Home_Sig_Sturct[port].gpio_sig2_port = step_motor[port].index_port;         
				return homeMode;
      }
      //20240925 modified
      if(LOWLIM_AVAILABLE_HCONF1 == (ee_conFile[port].this_HCONF.hconf1 & LOWLIM_AVAILABLE_HCONF1)){
        
        if(ee_conFile[port].upperLimitation == ee_conFile[port].lowerLimitation){
          homeMode = HOME_LIMT_LIMT;//show up 2 times
        }else{
          homeMode = HOME_UPLIMT_VALUE;
        }

        motor_Home_Sig_Sturct[port].homeMode     = homeMode;
        motor_Home_Sig_Sturct[port].pu16_signal1 = &step_motor[port].limP_pin_interrupt  ;
        motor_Home_Sig_Sturct[port].pu16_signal2 = &step_motor[port].limN_pin_interrupt;
				// determine the IO level
				if(ee_conFile[port].this_HCONF.hconf2 & UP_LIMITIATION_HCONF2){
           motor_Home_Sig_Sturct[port].sig1_level = 1;       
        }else{
           motor_Home_Sig_Sturct[port].sig1_level = 0;   
        }
        if(ee_conFile[port].this_HCONF.hconf2 & LOW_LIMITIATION_HCONF2){
	         motor_Home_Sig_Sturct[port].sig2_level = 1;
        }else{
	         motor_Home_Sig_Sturct[port].sig2_level = 0;          
        }        
        // In this mode ,the following 2 values are not used.
				motor_Home_Sig_Sturct[port].f_value_1    = ee_conFile[port].upperLimitation;
				motor_Home_Sig_Sturct[port].f_value_2    = ee_conFile[port].lowerLimitation;

  			motor_Home_Sig_Sturct[port].gpio_sig1_pin  = step_motor[port].limP_pin;
				motor_Home_Sig_Sturct[port].gpio_sig1_port = step_motor[port].limP_port;       
 				motor_Home_Sig_Sturct[port].gpio_sig2_pin  = step_motor[port].limN_pin;
				motor_Home_Sig_Sturct[port].gpio_sig2_port = step_motor[port].limN_port;   
        
				return homeMode;
      }

      // if goes here ,must be the HOME_UPLIMT_VALUE mode, a signal and it's value
        homeMode = HOME_UPLIMT_VALUE;
        motor_Home_Sig_Sturct[port].homeMode = homeMode;
        motor_Home_Sig_Sturct[port].pu16_signal1 = &step_motor[port].limP_pin_interrupt;
				// determine the IO level
				if(ee_conFile[port].this_HCONF.hconf2 & UP_LIMITIATION_HCONF2){
           motor_Home_Sig_Sturct[port].sig1_level = 1;       
        }else{
           motor_Home_Sig_Sturct[port].sig1_level = 0;   
        }        
        motor_Home_Sig_Sturct[port].f_value_1 = ee_conFile[port].upperLimitation;
        // In this mode ,the following three values of signal 2 are not used.
        motor_Home_Sig_Sturct[port].pu16_signal2 = NULL;
				motor_Home_Sig_Sturct[port].sig2_level = 0;
        motor_Home_Sig_Sturct[port].f_value_2 = ee_conFile[port].upperLimitation;

  			motor_Home_Sig_Sturct[port].gpio_sig1_pin  = step_motor[port].limP_pin;
				motor_Home_Sig_Sturct[port].gpio_sig1_port = step_motor[port].limP_port;       
 				motor_Home_Sig_Sturct[port].gpio_sig2_pin  = 0;
				motor_Home_Sig_Sturct[port].gpio_sig2_port = NULL;   
        
        return homeMode;
     }else{
        homeMode = HOME_NONE_NONE;
        motor_Home_Sig_Sturct[port].homeMode = homeMode;       
        return homeMode;
     }
	}// end of else ,means that no home signal	
}

void disPlayHOME_SIGNALS_STRUCT(uint8_t port)
{
	 unsigned int   homeMode;

   printf("Port %d's HomeSturct: \n ",port);
   homeMode = motor_Home_Sig_Sturct[port].homeMode;
   printf("mode is ");

   switch (homeMode)
    {
      case HOME_HOME_INDEX:
            printf("HOME_HOME_INDEX \n ");       
      break;
      case HOME_LOW_INDEX:
            printf("HOME_LOW_INDEX \n ");       
      break;
      case HOME_UPPER_INDEX:
            printf("HOME_UPPER_INDEX \n ");           
      break;
      case HOME_HOME_NONE:
            printf("HOME_HOME_NONE \n ");          
      break;
      case HOME_UPLIMT_VALUE:
            printf("HOME_UPLIMT_VALUE \n ");           
      break;    
      case HOME_LOLIMT_VALUE:
            printf("HOME_LOLIMT_VALUE \n ");           
      break;
      case HOME_LIMT_LIMT:
            printf("HOME_LIMT_LIMT \n ");           
      break;
      case HOME_NONE_NONE:
            printf("HOME_NONE_NONE \n ");           
      break; 
      default:
              printf("\n ");        
      break;    
    }
    printf("pu16_signal1 : %d \n ", *motor_Home_Sig_Sturct[port].pu16_signal1);
    printf("pu16_signal2 : %d \n ", *motor_Home_Sig_Sturct[port].pu16_signal2);
    printf("sig1_level   : %d \n ",  motor_Home_Sig_Sturct[port].sig1_level);
    printf("sig2_level   : %d \n ",  motor_Home_Sig_Sturct[port].sig2_level);
    printf("f_value_2    : %f.\n ",  motor_Home_Sig_Sturct[port].f_value_1);
    printf("f_value_1    : %f.\n ",  motor_Home_Sig_Sturct[port].f_value_2);
    printf("direction    : %d.\n ",  motor_Home_Sig_Sturct[port].direction);
    switch (port)
    {
      case 0:
         displaySignalsInHomeSturct_port0();
      break;
     case 1:
         displaySignalsInHomeSturct_port1();
      break;
      case 2:
        displaySignalsInHomeSturct_port2();
      break;   
    default:
      break;
    }


} 
void displaySignalsInHomeSturct_port0(void)
{
  uint16_t     signal_pin = 0;
  
  signal_pin = motor_Home_Sig_Sturct[0].gpio_sig1_pin;
  printf("gpio_sig1_pin:  "); 
  switch (signal_pin)
  {
  case MOTOR_POS1_PIN:
    printf("uplimt\n"); 
    break;
  case MOTOR_NEG1_PIN:
    printf("lowlimt\n"); 
    break;
  case MOTOR_INDEX1_PIN:
    printf("index\n"); 
    break;
  case MOTOR_HOME1_PIN:
    printf("home\n"); 
    break;
  case MOTOR_COLLISION1_PIN:
    printf("collision\n"); 
    break;
  default:
    break;
  }
  
  signal_pin = motor_Home_Sig_Sturct[0].gpio_sig2_pin;
  printf("gpio_sig2_pin:  "); 
  switch (signal_pin)
  {
  case MOTOR_POS1_PIN:
    printf("uplimt\n"); 
    break;
  case MOTOR_NEG1_PIN:
    printf("lowlimt\n"); 
    break;
  case MOTOR_INDEX1_PIN:
    printf("index\n"); 
    break;
  case MOTOR_HOME1_PIN:
    printf("home\n"); 
    break;
  case MOTOR_COLLISION1_PIN:
    printf("collision\n"); 
    break;
  default:
    break;
  }
  
}
void displaySignalsInHomeSturct_port1(void)
{
  uint16_t     signal_pin = 0;
  
  signal_pin = motor_Home_Sig_Sturct[1].gpio_sig1_pin;
  printf("gpio_sig1_pin:  "); 
  switch (signal_pin)
  {
  case MOTOR_POS2_PIN:
    printf("uplimt\n"); 
    break;
  case MOTOR_NEG2_PIN:
    printf("lowlimt\n"); 
    break;
  case MOTOR_INDEX2_PIN:
    printf("index\n"); 
    break;
  case MOTOR_HOME2_PIN:
    printf("home\n"); 
    break;
  case MOTOR_COLLISION2_PIN:
    printf("collision\n"); 
    break;
  default:
    break;
  }
  
  signal_pin = motor_Home_Sig_Sturct[1].gpio_sig2_pin;
  printf("gpio_sig2_pin:  "); 
  switch (signal_pin)
  {
  case MOTOR_POS2_PIN:
    printf("uplimt\n"); 
    break;
  case MOTOR_NEG2_PIN:
    printf("lowlimt\n"); 
    break;
  case MOTOR_INDEX2_PIN:
    printf("index\n"); 
    break;
  case MOTOR_HOME2_PIN:
    printf("home\n"); 
    break;
  case MOTOR_COLLISION2_PIN:
    printf("collision\n"); 
    break;
  default:
    break;
  } 
}
void displaySignalsInHomeSturct_port2(void)
{
   uint16_t     signal_pin = 0;
  
  signal_pin = motor_Home_Sig_Sturct[2].gpio_sig1_pin;
  printf("gpio_sig1_pin:  "); 
  switch (signal_pin)
  {
  case MOTOR_POS3_PIN:
    printf("uplimt\n"); 
    break;
  case MOTOR_NEG3_PIN:
    printf("lowlimt\n"); 
    break;
  case MOTOR_INDEX3_PIN:
    printf("index\n"); 
    break;
  case MOTOR_HOME3_PIN:
    printf("home\n"); 
    break;
  case MOTOR_COLLISION3_PIN:
    printf("collision\n"); 
    break;
  default:
    break;
  }
  
  signal_pin = motor_Home_Sig_Sturct[2].gpio_sig2_pin;
  printf("gpio_sig2_pin:  "); 
  switch (signal_pin)
  {
  case MOTOR_POS3_PIN:
    printf("uplimt\n"); 
    break;
  case MOTOR_NEG3_PIN:
    printf("lowlimt\n"); 
    break;
  case MOTOR_INDEX3_PIN:
    printf("index\n"); 
    break;
  case MOTOR_HOME3_PIN:
    printf("home\n"); 
    break;
  case MOTOR_COLLISION3_PIN:
    printf("collision\n"); 
    break;
  default:
    break;
  }  
}

uint8_t chekLimis(float input,float lowLim,float upLim)
{
  uint8_t checkPass = 1;
  
  if(input < lowLim ){
    checkPass = 0;
    #ifdef UART_DEBUG_STP
      printf(" %f is smaller than %f.\n",input ,lowLim);	
		#endif 
    return checkPass;
  }
  
  if(input > upLim ){
    checkPass = 0;
    #ifdef UART_DEBUG_STP
      printf(" %f is greater than %f.\n",input ,upLim);	
		#endif 
    return checkPass;
  }

  return checkPass;
  
}

void common_FillReplyArray(uint8_t reply)
{
    uint8_t i=0,sum = 0;
    len_reply = 6;
    TX_BUFF[ i ++] =  0X55;
    TX_BUFF[ i ++ ] = 0XAA;

    TX_BUFF[ i ] = (uint8_t)( (len_reply & 0XFF00) >>8 );
    sum += TX_BUFF[ i ];
    i++;
    TX_BUFF[ i ] = (uint8_t)(len_reply & 0X00FF);
    sum += TX_BUFF[ i ];
    i++;
    TX_BUFF[i] = comd_buff[COMMAND_OFFSET];
    sum += TX_BUFF[ i ];
    i++;
    TX_BUFF[i] = reply;
    sum += TX_BUFF[ i ];
    i++;  
    TX_BUFF[i++] = sum;
    TX_BUFF[i] = 0X0C;
}
void common_Reply(uint8_t *pbuff, uint16_t *len)
{
	 uint16_t i = 0;
  //����
  for(i = 0; i < *len + 2 ; i ++)
    HAL_UART_Transmit( &UartHandle,&pbuff[i] ,1,1000);
  //DMA transmitte 
    HAL_UART_Transmit_DMA (&Uart3Handle,(uint8_t *)pbuff,*len + 2);

  #ifdef UART_DEBUG_STP  
  printf("\n");     
  for(i = 0; i < *len + 2 ; i ++)
  {
     printf("0x%02x,",pbuff[i]);        
  }
  printf("\n");    
  #endif  
}

//for PLMT HMPS, if new home value or new actual value is beyond
// the upper/lower limits ,just change the mimiState.state 
void positionLim_statusCheck(uint8_t port)
{
  // home is compared with up/low
  float alueActual = state_motor_struct[port].state_struct.miniState.valueActual;
  float lower        = ee_conFile[port].lowerLimitation;
  float upper        = ee_conFile[port].upperLimitation ;  
  if( ( alueActual - upper ) > ee_conFile[port].resolution){
    state_motor_struct[port].state_struct.miniState.state |= STATE_UPPER_VALUE_OR_NOT; 
    #ifdef UART_DEBUG_STP
      printf("Port  %d is at upLimts.\n ",(int)port);
    #endif   
  }
  if( ( alueActual - lower ) < ee_conFile[port].resolution){
    state_motor_struct[port].state_struct.miniState.state |= STATE_lOWER_VALUE_OR_NOT; 
    #ifdef UART_DEBUG_STP
      printf("Port  %d is at lowLimts.\n ",(int)port);
    #endif    
  }
}


uint8_t getPortsParce(uint8_t* pbuff, uint8_t offset)
{
  return (uint8_t)(pbuff[offset]>>4);
}
uint8_t checkPortsAvailable(uint8_t port, uint8_t MaxPOrts)
{
  if( ( port > MaxPOrts) ||(port ==0))
   { return 0; }
  else
   { return 1; }
}
uint8_t checkPortsAvailable_0_permission(uint8_t port, uint8_t MaxPOrts)
{
  if( ( port > MaxPOrts))
   { return 0; }
  else
   { return 1; }
}
#ifdef UART_DEBUG_STP  
void displayStateMachine(uint8_t motorId)
{
  printf("\n");  
  printf("motor %d's stateMachine is ",motorId );
  if( STEP_STOP == (STEP_STOP & step_motor[motorId].this_state->stateMachine))
    { printf(" STEP_STOP | " );}
  if(STEP_FINDINGHOME == (STEP_FINDINGHOME & step_motor[motorId].this_state->stateMachine))
    { printf("STEP_FINDINGHOME |" );}  
  if(STEP_HOME == (STEP_HOME & step_motor[motorId].this_state->stateMachine))
    { printf("STEP_HOME |" );}  
  if(STEP_MOVE2_POSITION == (STEP_MOVE2_POSITION & step_motor[motorId].this_state->stateMachine))
    { printf(" STEP_MOVE2_POSITION | " );}
  if(STEP_STEPPING == (STEP_STEPPING & step_motor[motorId].this_state->stateMachine))
    { printf(" STEP_STEPPING | " );}
  if(STEP_STEPPING_WITH_SPEED == (STEP_STEPPING_WITH_SPEED & step_motor[motorId].this_state->stateMachine))
    { printf(" STEP_STEPPING_WITH_SPEED | " );}
  if(STEP_STEP_SCAN == (STEP_STEP_SCAN & step_motor[motorId].this_state->stateMachine))
    { printf(" STEP_STEP_SCAN | " );}
  if(STEP_STEP_CONTINUE_SCAN == (STEP_STEP_CONTINUE_SCAN & step_motor[motorId].this_state->stateMachine))
    { printf(" STEP_STEP_CONTINUE_SCAN | " );}
  if(STEP_STEP_SCAN_TIME == (STEP_STEP_SCAN_TIME & step_motor[motorId].this_state->stateMachine))
    { printf(" STEP_SCAN_TIME | " );}
  if(STEP_STEP_SCAN_ENAB == (STEP_STEP_SCAN_ENAB & step_motor[motorId].this_state->stateMachine))
    { printf("STEP_SCAN_ENAB |" );}

  if(STEP_DIRECTION_FIRST == (STEP_DIRECTION_FIRST & step_motor[motorId].this_state->stateMachine))
    { printf("STEP_DIRECTION_FIRST |" );}
  if(STEP_DIRECTION_SECOND == (STEP_DIRECTION_SECOND & step_motor[motorId].this_state->stateMachine))
    { printf("STEP_DIRECTION_SECOND |" );}
  if(STEP_WAIT_SIG1_DISAPPEAR == (STEP_WAIT_SIG1_DISAPPEAR & step_motor[motorId].this_state->stateMachine))
    { printf("STEP_WAIT_SIG1_DISAPPEAR |" );}
  if(STEP_WAITING_SIG1 == (STEP_WAITING_SIG1 & step_motor[motorId].this_state->stateMachine))
    { printf("STEP_WAITING_SIG1 |" );}
  if(STEP_WAITING_SIG2 == (STEP_WAITING_SIG2 & step_motor[motorId].this_state->stateMachine))
    { printf("STEP_WAITING_SIG2 |" );}    
  if(STEP_PRE == (STEP_PRE & step_motor[motorId].this_state->stateMachine))
    { printf("STEP_PRE |" );} 
  printf("\n"); 

}
#endif  

uint8_t clearErrors(uint8_t port)
{

  state_motor_struct[port].state_struct.miniState.state &= STATE_ROTATION_OR_NOT;
  #ifdef UART_DEBUG_STP
  printf("state of motor %d is  0x%x. \n ",port,state_motor_struct[port].state_struct.miniState.state);
  #endif  
	return 0;
}      

//If homevalue is changed by (RECF) command, then the actual value should be changed simultaneously. 
uint8_t homeValueControl_permenant(uint8_t port,float threhold)
{
  float dif_home_Confile_status = 0;
  dif_home_Confile_status =  state_motor_struct[port].state_struct.homeUsed - ee_conFile[port].home ;
  
  if( (dif_home_Confile_status >= threhold)||(dif_home_Confile_status <= -threhold)){    
    state_motor_struct[port].state_struct.homeUsed =  ee_conFile[port].home;
    state_motor_struct[port].state_struct.miniState.valueActual += dif_home_Confile_status; 
    #ifdef UART_DEBUG_STP
      printf("Dif is  %f \n ",dif_home_Confile_status);
    #endif 
    positionLim_statusCheck(port);

    return 1; 
  }
  else{
    state_motor_struct[port].state_struct.homeUsed =  ee_conFile[port].home;
    positionLim_statusCheck(port);

    return 0;
  }
}

uint8_t homeValueControl_temporary(uint8_t port,float f_newHome)
{
  float f_tempDifference =  f_newHome -  state_motor_struct[port].state_struct.homeUsed;
  state_motor_struct[port].state_struct.homeUsed = f_newHome;
  state_motor_struct[port].state_struct.miniState.valueActual += f_tempDifference;
  positionLim_statusCheck(port); 
  return 0;
}
void displayActual(void)
{
   int capture_count;
       /* printf("value 0 is  %f \n ",state_motor_struct[0].state_struct.miniState.valueActual);
        printf("value 1  %f \n ",state_motor_struct[1].state_struct.miniState.valueActual);
        printf("value 2  %f \n ",state_motor_struct[2].state_struct.miniState.valueActual);
        */
        printf("value 0 is  %f \n ",step_motor[0].this_state->miniState.valueActual);
        printf("value 1  %f \n ",step_motor[1].this_state->miniState.valueActual);
        printf("value 2  %f \n ",step_motor[2].this_state->miniState.valueActual);

	      capture_count = (int)__HAL_TIM_GET_COUNTER(&TIM_EncoderHandle[0]) + (Encoder_Overflow_Count[0] * ENCODER_TIM_PERIOD);       
        printf("capture_count[0] is %d \n",capture_count);

	      capture_count = (int)__HAL_TIM_GET_COUNTER(&TIM_EncoderHandle[1]) + (Encoder_Overflow_Count[1] * ENCODER_TIM_PERIOD);       
        printf("capture_count[1] is %d \n",capture_count);

         capture_count = (int)__HAL_TIM_GET_COUNTER(&TIM_EncoderHandle[2]) + (Encoder_Overflow_Count[2] * ENCODER_TIM_PERIOD);       
        printf("capture_count[2] is %d \n",capture_count);

}
void displayTestActual(void)
{
    printf("valueActual_test 0:  %f \n ",state_motor_struct[0].state_struct.f_valueActual_test);
    printf("valueActual_test 1:  %f \n ",state_motor_struct[1].state_struct.f_valueActual_test);
    printf("valueActual_test 2:  %f \n ",state_motor_struct[2].state_struct.f_valueActual_test);
}

void commandReply_ADD(void)
{
  uint8_t ports       = getPortsParce(comd_buff,SUBCOMMAND_OFFSET); 
  getHomeMode_fill_HOME_STRUCT(ports - 1);
  if( HOME_LIMT_LIMT != motor_Home_Sig_Sturct[ports - 1].homeMode){
    common_FillReplyArray((uint8_t)REPLY_NOT_LIMT_LIMT); 
    common_Reply(TX_BUFF,(uint16_t*)(&len_reply));
    #ifdef UART_DEBUG_STP
      printf("not limt_limt \n ");
    #endif 
    return;  
  }
  if(0 == checkPortsAvailable(ports, MOTOR_IN_USE)) {
    common_FillReplyArray((uint8_t)REPLY_CHNANEL_FAIL); 
    common_Reply(TX_BUFF,(uint16_t*)(&len_reply));
    #ifdef UART_DEBUG_STP
      printf("WRONG PORT. \n ");
    #endif 
    return;
  }
  if( STEP_STOP == step_motor[ports-1].this_state->stateMachine ){
    step_motor[ports-1].this_state->stateMachine  |= STEP_PRE;
    common_FillReplyArray((uint8_t)REPLY_SUCCESS); 
  }else{
    common_FillReplyArray((uint8_t)REPLY_BUSY); 
    common_Reply(TX_BUFF,(uint16_t*)(&len_reply));
    #ifdef UART_DEBUG_STP
      printf("busy.\n"); 
    #endif
    return;
  }
  #ifdef UART_DEBUG_STP
      printf("ADD: on port      %d.\n ", ports - 1);
  #endif   
  common_Reply(TX_BUFF,(uint16_t*)(&len_reply));
}
/*********************************************END OF FILE**********************/
