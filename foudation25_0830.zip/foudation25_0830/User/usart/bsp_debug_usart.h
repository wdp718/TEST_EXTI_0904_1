#ifndef __DEBUG_USART_H
#define	__DEBUG_USART_H

#include "stm32h7xx.h"
#include <stdio.h>


//���Ŷ���
/*******************************************************/
#define DEBUG_USART                             USART1
#define DEBUG_USART_CLK_ENABLE()                __USART1_CLK_ENABLE();

#define DEBUG_USART_RX_GPIO_PORT                GPIOB
#define DEBUG_USART_RX_GPIO_CLK_ENABLE()        __HAL_RCC_GPIOB_CLK_ENABLE()
#define DEBUG_USART_RX_PIN                      GPIO_PIN_6
#define DEBUG_USART_RX_AF                       GPIO_AF7_USART1

#define DEBUG_USART_TX_GPIO_PORT                GPIOB
#define DEBUG_USART_TX_GPIO_CLK_ENABLE()        __HAL_RCC_GPIOB_CLK_ENABLE()
#define DEBUG_USART_TX_PIN                      GPIO_PIN_7
#define DEBUG_USART_TX_AF                       GPIO_AF7_USART1

//����DMA�Ĺ��ܣ���������֮·��
/*******************************************************/
//TX DMA
#define LEN_DEBUG_TX_DMA                  50
#define SENDBUFF_SIZE                     LEN_DEBUG_TX_DMA				//���͵�������
#define DEBUG_USART_DMA_STREAM_TX         DMA2_Stream7
//end MDA
#define DEBUG_USART_IRQHandler                  USART1_IRQHandler
#define DEBUG_USART_IRQ                 		USART1_IRQn
/************************************************************/
#define DEBUG_USART_DMA_CLK_ENABLE()      		 __DMA2_CLK_ENABLE()	
#define DEBUG_USART_DMA_REQUEST                DMA_REQUEST_USART1_TX
#define DEBUG_USART_DMA_STREAM            		 DMA2_Stream6
//���ڲ�����
#define DEBUG_USART_BAUDRATE                    115200
// һ�η��͵�������
#define  USART_RBUFF_SIZE            256 


//UART3����ض���
#define RS232_USART                             USART3
#define RS232_USART_CLK_ENABLE()                __USART3_CLK_ENABLE();

#define RCC_PERIPHCLK_UARTx               		RCC_PERIPHCLK_USART3
#define RCC_UARTxCLKSOURCE_SYSCLK         		RCC_USART234578CLKSOURCE_D2PCLK1

/*
#define RS232_USART_RX_GPIO_PORT                GPIOB
#define RS232_USART_RX_GPIO_CLK_ENABLE()        __HAL_RCC_GPIOB_CLK_ENABLE()
#define RS232_USART_RX_PIN                      GPIO_PIN_11
#define RS232_USART_RX_AF                       GPIO_AF7_USART3


#define RS232_USART_TX_GPIO_PORT                GPIOB
#define RS232_USART_TX_GPIO_CLK_ENABLE()        __HAL_RCC_GPIOB_CLK_ENABLE()
#define RS232_USART_TX_PIN                      GPIO_PIN_10
#define RS232_USART_TX_AF                       GPIO_AF7_USART3
*/
#define RS232_USART_RX_GPIO_PORT                GPIOD
#define RS232_USART_RX_GPIO_CLK_ENABLE()        __HAL_RCC_GPIOD_CLK_ENABLE()
#define RS232_USART_RX_PIN                      GPIO_PIN_9
#define RS232_USART_RX_AF                       GPIO_AF7_USART3


#define RS232_USART_TX_GPIO_PORT                GPIOD
#define RS232_USART_TX_GPIO_CLK_ENABLE()        __HAL_RCC_GPIOD_CLK_ENABLE()
#define RS232_USART_TX_PIN                      GPIO_PIN_8
#define RS232_USART_TX_AF                       GPIO_AF7_USART3



#define RS232_USART_IRQHandler                  USART3_IRQHandler
#define RS232_USART_IRQ                 		USART3_IRQn

#define RS232_USART_BAUDRATE                    115200


#define UART3_USART_IRQHandler                  USART1_IRQHandler
#define UART3_USART_IRQ                 		USART1_IRQn
//////////////////////////////////////////////////////////////////////
#define UART_DEBUG_STP 1


void Usart_SendString(uint8_t *str);
void RS232_USART_Config(void);
extern UART_HandleTypeDef Uart3Handle;


//uint16_t  DEBUG_TX_DMA[LEN_DEBUG_TX_DMA];

void Usart_SendString(uint8_t *str);
void DEBUG_USART_Config(void);
void USART_DMA_Config(void);

void Uart_DMA_Rx_Data(void);

void UART_IdelCallback(void);
//int fputc(int ch, FILE *f);
extern UART_HandleTypeDef UartHandle;
void DEBUG_USART_DMA_Config(void);
void USART_TX_DMA_Config(void);
void USART_TXRX_DMA_Config(void);


void Usart3_SendString(uint8_t *str);
void USART3_TXRX_DMA_Config(void);
void UART3_IdelCallback(void);
void  Uart3_DMA_Rx_Data(void );       /* �ͷ�һ���ź�������ʾ�����ѽ��� */


void commandParse(void);
#define  COMMAND_OFFSET      0X04  //command�ڻ����е�λ�ã��������0x04
#define  SUBCOMMAND_OFFSET   0X05  //command�ڻ����е�λ�ã��������0x04
#define  SUBCOMMAND_WRITE    0X01  //
#define  SUBCOMMAND_READ     0X00  //

#define  COMMAND_DRCF     0X10              		
#define  COMMAND_REBT     0X11   
#define  COMMAND_RECF     0X12 //���¶�ȡ����ReConfiguration  RECF(<port-id>)�������Ӷ�ȡ�����ļ���ʼ���п�������
#define  COMMAND_RDST     0X13
#define  COMMAND_WAIT     0X14
#define  COMMAND_ENAB     0X15


#define  COMMAND_HOME     0X16
#define  COMMAND_FDHM     0X17
#define  COMMAND_MVPS     0X18
#define  COMMAND_STEP     0X19
#define  COMMAND_SPED     0X1A
#define  COMMAND_STOP     0X1B
#define  COMMAND_REPR     0X1C
#define  COMMAND_CLER     0X1D
#define  COMMAND_CLPS     0X1E
#define  COMMAND_HMPS     0X1F
#define  COMMAND_ACPS     0X20

#define  COMMAND_PLMT     0X21//�޸���λֵposition limit  PLMT<port-id>(,<lower>,<upper>,<permanent>)
#define  COMMAND_VLMT     0X22//�޸��ٶ���speed limit  VLMT<port-id>(,<lower>,<upper>,<permanent>)

#define  COMMAND_SSCN     0X23
#define  COMMAND_CSCN     0X24

//20221009 ADD, for home_limt_limt operation.
#define  COMMAND_ADD      0X25
#define  COMMAND_SUB      0X26


#define  COMMAND_SSCN_MODE_ENAB 0x08
#define  COMMAND_SSCN_SLAV_EXST 0x04

#define  COMMAND_CSCN_PULSE 0x02

#define  REPLY_SUCCESS          0X55 
#define  REPLY_FAIL             0X01
#define  REPLY_FAIL_SUM         0X02
#define  REPLY_FAIL_TAIL        0X03
#define  REPLY_FAIL_TIME_IS_0   0X04
#define  REPLY_CHNANEL_FAIL     0X05
#define  REPLY_NOT_HOMEAPP_FAIL 0X06 
#define  REPLY_SPEED_FAIL       0X07 //added 202206
#define  REPLY_BUSY             0X08 //added 202206
#define  REPLY_DIRECTION_WRONG  0X10 //added 20220916
#define  REPLY_NOT_LIMT_LIMT    0X11 //added 20221009

void commandReply_DriverConFileReadWrite(void);
void commandReply_REboot(void);
void commondReply_RECF(void);
void commandReply_RDST(void);
void commandReply_WAIT(void);
void commandReply_ENAB(void);
void commandReply_HOME(void);
unsigned char getHomeMode_fill_HOME_STRUCT(uint8_t port);
void commandReply_FDHM(void);

void commandReply_MVPS(void);
void commandReply_STEP(void);
void commandReply_SPED(void);

void commandReply_STOP(void);
void commandReply_REPR(void);

void commandReply_CLPS(void);
void commandReply_HMPS(void);

void commandReply_PLMT(void);
void commandReply_VLMT(void);
void commandReply_CLER(void);

void commandReply_SSCN(void);
void commandReply_CSCN(void);
void commandReply_ACPS(void);


void common_FillReplyArray(uint8_t reply);
void common_Reply( uint8_t *pbuff, uint16_t *len);

void displayStateMachine(uint8_t motorId);

uint8_t getPortsParce(uint8_t* pbuff, uint8_t offset);
uint8_t checkPortsAvailable(uint8_t port, uint8_t MaxPOrts);

uint8_t checkPortsAvailable_0_permission(uint8_t port, uint8_t MaxPOrts);
uint8_t homeValueControl_permenant(uint8_t port,float threhold);
uint8_t homeValueControl_temporary(uint8_t port,float f_newHome);

uint8_t chekLimis(float input,float lowLim,float upLim);
void positionLim_statusCheck(uint8_t port);
uint8_t clearErrors(uint8_t port);
void disPlayHOME_SIGNALS_STRUCT(uint8_t port);

void displaySignalsInHomeSturct_port0(void);
void displaySignalsInHomeSturct_port1(void);
void displaySignalsInHomeSturct_port2(void);

void displayActual(void);
void displayTestActual(void);

void setDirectionForFindingHome(uint8_t motorId);



#endif /* __USART1_H */
